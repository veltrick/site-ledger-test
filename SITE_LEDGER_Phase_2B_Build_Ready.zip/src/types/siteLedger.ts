export const DEFAULT_SITE_ID = 'SITE-MAIN';

export type AppLanguage = 'en' | 'bn';

export type NavDestination =
  | 'dashboard'
  | 'workers'
  | 'attendance'
  | 'spreadsheet'
  | 'payments'
  | 'expenses'
  | 'reports'
  | 'sites'
  | 'settings';

export type WorkCategory =
  | 'MASON'
  | 'HELPER'
  | 'STEEL_FIXER'
  | 'ELECTRICIAN'
  | 'CARPENTER'
  | 'PLUMBER';

export type UserRole = 'ADMIN' | 'MANAGER' | 'ACCOUNTANT';

export type DutyType =
  | 'HALF_DUTY'
  | 'FULL_DUTY'
  | 'ONE_AND_HALF_DUTY'
  | 'DOUBLE_DUTY'
  | 'TWO_AND_HALF_DUTY'
  | 'TRIPLE_DUTY'
  | 'ABSENT'
  | 'LEAVE';

export type PayrollPeriodStatus = 'OPEN' | 'FINALIZED';

export type WorkerPayrollStatus =
  | 'PAID'
  | 'PARTIAL'
  | 'UNPAID'
  | 'OVERPAID'
  | 'NO_ATTENDANCE';

export type PaymentType = 'SALARY' | 'ADVANCE' | 'REVERSAL';

export type SiteStatus = 'ACTIVE' | 'PAUSED' | 'COMPLETED' | 'ARCHIVED';

export type ExpensePaymentMethod = 'CASH' | 'BANK' | 'MOBILE_BANKING';

export interface Site {
  id: string;
  siteName: string;
  siteCode: string;
  address: string;
  clientName: string;
  siteManager: string;
  startDateIso: string;
  status: SiteStatus;
  notes: string;
}

export interface WorkerSiteHistory {
  historyId: string;
  workerId: string;
  fromSiteId: string;
  toSiteId: string;
  transferDateIso: string;
  transferredByRole: UserRole;
  note: string;
  previousLocalCode: string;
  newLocalCode: string;
}

export interface DutyMultiplierConfig {
  halfDutyMultiplier: number;
  fullDutyMultiplier: number;
  oneAndHalfDutyMultiplier: number;
  doubleDutyMultiplier: number;
  twoAndHalfDutyMultiplier: number;
  tripleDutyMultiplier: number;
  absentMultiplier: number;
  leaveMultiplier: number;
}

export interface Worker {
  id: string;
  siteId: string;
  localWorkerCode: string;
  fullNameEn: string;
  fullNameBn: string;
  phoneNumber: string;
  category: WorkCategory;
  joiningDateIso: string;
  leavingDateIso: string | null;
  dailyWage: number;
  dailyFoodAllowance: number;
  isActive: boolean;
  avatarUrl: string | null;
  photoPath: string | null;
}

export interface DailyAttendanceRecord {
  dateIso: string;
  workerId: string;
  siteId: string;
  dutyType: DutyType;
  dailyWageSnapshot: number;
  multiplierSnapshot: number;
  earnedAmount: number;
  note: string;
  updatedAtIso: string;
  updatedByRole: UserRole;
}

export interface AttendanceAuditEntry {
  auditId: string;
  dateIso: string;
  workerId: string;
  siteId: string;
  previousDutyType: DutyType | null;
  newDutyType: DutyType;
  previousEarned: number | null;
  newEarned: number;
  changedByRole: UserRole;
  changedAtIso: string;
  reason: string;
}

export interface PaymentLedgerEntry {
  id: string;
  siteId: string;
  workerId: string;
  dateIso: string; // actual disbursement date
  applicablePeriod: string; // "YYYY-MM" salary period
  paymentType: PaymentType;
  paidAmount: number;
  referenceNo: string;
  noteEn: string;
  noteBn: string;
  recordedByRole: UserRole;
  createdAtIso: string;
  isVoided: boolean;
}

export interface AdvanceRecord {
  id: string;
  siteId: string;
  workerId: string;
  advanceDateIso: string;
  amount: number;
  referenceNo: string;
  note: string;
  recordedByRole: UserRole;
  createdAtIso: string;
  isVoided: boolean;
}

export interface PaymentAllocation {
  allocationId: string;
  siteId: string;
  sourceType: 'PAYMENT' | 'ADVANCE';
  sourceId: string;
  workerId: string;
  payrollPeriod: string; // "YYYY-MM"
  allocatedAmount: number;
  allocatedAtIso: string;
  allocatedByRole: UserRole;
  note: string;
  isVoided: boolean;
}

export interface PayrollPeriodRecord {
  siteId: string;
  periodIso: string; // "YYYY-MM"
  status: PayrollPeriodStatus;
  finalizedAtIso: string | null;
  finalizedByRole: UserRole | null;
  reopenedAtIso: string | null;
  reopenedByRole: UserRole | null;
  notes: string;
}

export interface PayrollAuditEntry {
  auditId: string;
  siteId: string;
  periodIso: string;
  action: 'FINALIZED' | 'REOPENED';
  changedByRole: UserRole;
  changedAtIso: string;
  reason: string;
}

export interface PaymentAuditEntry {
  auditId: string;
  siteId: string;
  transactionId: string;
  workerId: string;
  action: 'CREATED' | 'VOIDED' | 'ADVANCE_CREATED' | 'ALLOCATED';
  previousAmount: number | null;
  newAmount: number;
  changedByRole: UserRole;
  changedAtIso: string;
  reason: string;
}

export interface ExpenseCategory {
  id: string;
  nameEn: string;
  nameBn: string;
  isSystemDefault: boolean;
}

export interface SiteExpense {
  id: string;
  siteId: string;
  expenseDateIso: string;
  categoryId: string;
  title: string;
  amount: number;
  vendorName: string;
  paymentMethod: ExpensePaymentMethod;
  referenceNo: string;
  notes: string;
  receiptPath: string | null;
  receiptDataUrl: string | null;
  recordedByRole: UserRole;
  createdAtIso: string;
  isVoided: boolean;
}

export interface ExpenseAuditEntry {
  auditId: string;
  expenseId: string;
  siteId: string;
  action: 'CREATED' | 'UPDATED' | 'VOIDED';
  previousAmount: number | null;
  newAmount: number;
  changedByRole: UserRole;
  changedAtIso: string;
  reason: string;
}

export interface UserSiteAccount {
  userId: string;
  displayName: string;
  role: UserRole;
  assignedSiteIds: string[];
  canManageAllSites: boolean;
}

export interface WorkerMonthlySummary {
  worker: Worker;
  siteId: string;
  siteName: string;
  year: number;
  month: number;
  periodIso: string;
  totalCalendarDays: number;
  halfDutyCount: number;
  fullDutyCount: number;
  oneAndHalfDutyCount: number;
  doubleDutyCount: number;
  twoAndHalfDutyCount: number;
  tripleDutyCount: number;
  absentCount: number;
  leaveCount: number;
  totalDutyUnits: number;
  totalEarnedAmount: number;
  totalPaidAmount: number;
  advanceAllocatedAmount: number;
  outstandingBalance: number;
  payrollStatus: WorkerPayrollStatus;
  periodLockStatus: PayrollPeriodStatus;
}

export interface CurrentMonthProjection {
  earnedToDate: number;
  paidToDate: number;
  remainingBalance: number;
  dutyUnitsToDate: number;
  estimatedMonthEndSalary: number;
  asOfDay: number;
  totalCalendarDays: number;
}

export interface MasterSpreadsheetTotals {
  totalWorkers: number;
  totalDutyUnits: number;
  totalEarnedSalary: number;
  totalPaidSalary: number;
  totalOutstandingSalary: number;
}

export interface SiteFinancialSummary {
  site: Site;
  activeWorkersCount: number;
  totalWorkersCount: number;
  totalEarnedPayroll: number;
  totalPaidPayroll: number;
  totalGeneralExpenses: number;
  totalOutstandingPayroll: number;
}

export interface AllSitesOverviewSummary {
  activeSiteCount: number;
  totalWorkersCount: number;
  combinedEarnedPayroll: number;
  combinedPaidPayroll: number;
  combinedGeneralExpenses: number;
  combinedOutstandingPayroll: number;
  perSiteSummaries: SiteFinancialSummary[];
}

export interface MonthlyExpenseBreakdown {
  laborCost: number;
  foodAllowances: number;
  siteMaterials: number;
}

export interface BackupRecordCounts {
  sites: number;
  workers: number;
  attendanceRecords: number;
  payments: number;
  advances: number;
  allocations: number;
  expenses: number;
  workerPhotos: number;
  receiptImages: number;
}

export interface BackupHistoryRecord {
  id: string;
  fileName: string;
  createdAtIso: string;
  schemaVersion: number;
  appVersion: string;
  checksumSha256: string;
  fileSizeBytes: number;
  counts: BackupRecordCounts;
  verifiedStatus: 'VERIFIED' | 'WARNING' | 'CORRUPTED' | 'FILE_MISSING';
  fileExists: boolean;
}

export interface BackupProgress {
  isRunning: boolean;
  stageLabel: string;
  progressPercent: number;
}

export interface BackupManifest {
  backupId: string;
  appId: string;
  appVersion: string;
  schemaVersion: number;
  createdAtIso: string;
  databaseEntry: string;
  databaseSha256: string;
  checksumSha256: string;
  workerPhotoChecksums: Record<string, string>;
  receiptImageChecksums: Record<string, string>;
  counts: BackupRecordCounts;
}

export interface BackupValidationResult {
  isValid: boolean;
  fileName: string;
  createdAtIso: string;
  schemaVersion: number;
  appVersion: string;
  checksumSha256: string;
  fileSizeBytes: number;
  counts: BackupRecordCounts;
  checksumsMatched: boolean;
  integrityCheckPassed: boolean;
  isOlderThanCurrentData: boolean;
  errors: string[];
  warnings: string[];
}

export interface SyncEvent {
  eventId: string;
  entityType: string;
  entityId: string;
  siteId: string;
  action: string;
  updatedAtIso: string;
  deviceId: string;
  syncStatus: 'LOCAL_ONLY' | 'PENDING_SYNC' | 'SYNCED';
}
