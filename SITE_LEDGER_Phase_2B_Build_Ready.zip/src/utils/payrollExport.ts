import {
  AppLanguage,
  DailyAttendanceRecord,
  MasterSpreadsheetTotals,
  WorkerMonthlySummary,
} from '../types/siteLedger';

function xmlEscape(val: string): string {
  return val
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function pdfEscape(val: string): string {
  const ascii = val.replace(/[^\x20-\x7E]/g, ' ').replace(/\s+/g, ' ').trim();
  return ascii.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}

function xmlRow(cells: string[]): string {
  return `<Row>${cells.map((c) => `<Cell><Data ss:Type="String">${xmlEscape(c)}</Data></Cell>`).join('')}</Row>\n`;
}

export function buildSpreadsheetExcelXml(
  language: AppLanguage,
  periodIso: string,
  rows: WorkerMonthlySummary[],
  totals: MasterSpreadsheetTotals,
  siteHeaderLabel = 'All Sites',
  includeSiteColumn = true,
  generatedAt = new Date().toISOString().slice(0, 16).replace('T', ' ')
): string {
  let sb = '<?xml version="1.0"?>\n';
  sb += '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">\n';
  sb += `<Worksheet ss:Name="Payroll_${periodIso}">\n<Table>\n`;
  sb += xmlRow([`SITE LEDGER — ${siteHeaderLabel}`, `Payroll Month: ${periodIso}`, `Generated: ${generatedAt}`]);
  sb += xmlRow([
    ...(includeSiteColumn ? ['Site'] : []),
    'Worker ID',
    'Worker Name',
    'Category',
    'Half (0.5)',
    'Full (1.0)',
    '1.5 Duty',
    'Double (2.0)',
    '2.5 Duty',
    'Triple (3.0)',
    'Absent',
    'Leave',
    'Duty Units',
    'Earned (BDT)',
    'Paid (BDT)',
    'Advance Applied (BDT)',
    'Outstanding (BDT)',
    'Status',
  ]);

  for (const r of rows) {
    const name = language === 'bn' ? `${r.worker.fullNameBn} (${r.worker.fullNameEn})` : r.worker.fullNameEn;
    sb += xmlRow([
      ...(includeSiteColumn ? [r.siteName || r.siteId] : []),
      r.worker.localWorkerCode || r.worker.id,
      name,
      r.worker.category,
      String(r.halfDutyCount),
      String(r.fullDutyCount),
      String(r.oneAndHalfDutyCount),
      String(r.doubleDutyCount),
      String(r.twoAndHalfDutyCount),
      String(r.tripleDutyCount),
      String(r.absentCount),
      String(r.leaveCount),
      r.totalDutyUnits.toFixed(1),
      String(r.totalEarnedAmount),
      String(r.totalPaidAmount),
      String(r.advanceAllocatedAmount),
      String(r.outstandingBalance),
      r.payrollStatus,
    ]);
  }

  sb += xmlRow([
    ...(includeSiteColumn ? ['ALL'] : []),
    'TOTAL',
    `${totals.totalWorkers} rows`,
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    totals.totalDutyUnits.toFixed(1),
    String(totals.totalEarnedSalary),
    String(totals.totalPaidSalary),
    '',
    String(totals.totalOutstandingSalary),
    '',
  ]);
  sb += '</Table>\n</Worksheet>\n</Workbook>';
  return sb;
}

function buildSimplePdfBytes(lines: string[], landscape = false): Uint8Array {
  const pageW = landscape ? 842 : 595;
  const pageH = landscape ? 595 : 842;
  const linesPerPage = landscape ? 30 : 44;
  const pages: string[][] = [];
  for (let i = 0; i < lines.length; i += linesPerPage) {
    pages.push(lines.slice(i, i + linesPerPage));
  }
  if (pages.length === 0) pages.push(['SITE LEDGER']);

  const objects: string[] = [];
  objects.push('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
  objects.push('');
  objects.push('3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n');

  const pageObjIds: number[] = [];
  let nextId = 4;

  for (const pageLines of pages) {
    const contentId = nextId++;
    const pageId = nextId++;
    pageObjIds.push(pageId);

    let stream = 'BT\n/F1 10 Tf\n';
    let y = pageH - 42;
    pageLines.forEach((line, idx) => {
      if (idx === 0) {
        stream += `/F1 13 Tf\n1 0 0 1 32 ${y} Tm (${pdfEscape(line)}) Tj\n/F1 9 Tf\n`;
      } else {
        stream += `1 0 0 1 32 ${y} Tm (${pdfEscape(line)}) Tj\n`;
      }
      y -= 16;
    });
    stream += 'ET\n';

    objects.push(
      `${contentId} 0 obj\n<< /Length ${stream.length} >>\nstream\n${stream}endstream\nendobj\n`
    );
    objects.push(
      `${pageId} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageW} ${pageH}] /Resources << /Font << /F1 3 0 R >> >> /Contents ${contentId} 0 R >>\nendobj\n`
    );
  }

  objects[1] = `2 0 obj\n<< /Type /Pages /Kids [${pageObjIds.map((id) => `${id} 0 R`).join(' ')}] /Count ${pageObjIds.length} >>\nendobj\n`;

  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [0];
  for (const obj of objects) {
    offsets.push(pdf.length);
    pdf += obj;
  }
  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objects.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  return new TextEncoder().encode(pdf);
}

export function buildAllWorkersPayrollPdfBytes(
  periodIso: string,
  rows: WorkerMonthlySummary[],
  totals: MasterSpreadsheetTotals,
  siteHeaderLabel = 'All Sites',
  includeSiteColumn = true,
  generatedAt = new Date().toISOString().slice(0, 16).replace('T', ' ')
): Uint8Array {
  const lines: string[] = [
    `SITE LEDGER (${siteHeaderLabel}) - Payroll (${periodIso})`,
    `Generated: ${generatedAt}`,
    includeSiteColumn
      ? 'Site          ID      Name             H   F 1.5   D 2.5   T   A   L   Units   Earned     Paid  Balance'
      : 'ID       Name                Cat         H   F 1.5   D 2.5   T   A   L   Units   Earned     Paid  Balance',
  ];
  for (const r of rows) {
    const code = (r.worker.localWorkerCode || r.worker.id).padEnd(7);
    const line = includeSiteColumn
      ? [
          (r.siteName || r.siteId).slice(0, 12).padEnd(13),
          code,
          r.worker.fullNameEn.slice(0, 16).padEnd(17),
          String(r.halfDutyCount).padStart(2),
          String(r.fullDutyCount).padStart(3),
          String(r.oneAndHalfDutyCount).padStart(3),
          String(r.doubleDutyCount).padStart(3),
          String(r.twoAndHalfDutyCount).padStart(3),
          String(r.tripleDutyCount).padStart(3),
          String(r.absentCount).padStart(3),
          String(r.leaveCount).padStart(3),
          r.totalDutyUnits.toFixed(1).padStart(7),
          String(r.totalEarnedAmount).padStart(8),
          String(r.totalPaidAmount).padStart(8),
          String(r.outstandingBalance).padStart(8),
        ].join(' ')
      : [
          code,
          r.worker.fullNameEn.slice(0, 18).padEnd(19),
          r.worker.category.slice(0, 10).padEnd(11),
          String(r.halfDutyCount).padStart(2),
          String(r.fullDutyCount).padStart(3),
          String(r.oneAndHalfDutyCount).padStart(3),
          String(r.doubleDutyCount).padStart(3),
          String(r.twoAndHalfDutyCount).padStart(3),
          String(r.tripleDutyCount).padStart(3),
          String(r.absentCount).padStart(3),
          String(r.leaveCount).padStart(3),
          r.totalDutyUnits.toFixed(1).padStart(7),
          String(r.totalEarnedAmount).padStart(8),
          String(r.totalPaidAmount).padStart(8),
          String(r.outstandingBalance).padStart(8),
        ].join(' ');
    lines.push(line);
  }
  lines.push(
    `TOTAL (${totals.totalWorkers} rows) | Units: ${totals.totalDutyUnits.toFixed(1)} | Earned: BDT ${totals.totalEarnedSalary} | Paid: BDT ${totals.totalPaidSalary} | Balance: BDT ${totals.totalOutstandingSalary}`
  );
  return buildSimplePdfBytes(lines, true);
}

export function buildIndividualWorkerPdfBytes(
  summary: WorkerMonthlySummary,
  dayRecords: DailyAttendanceRecord[],
  generatedAt = new Date().toISOString().slice(0, 16).replace('T', ' ')
): Uint8Array {
  const siteLbl = summary.siteName || summary.siteId;
  const lines: string[] = [
    `SITE LEDGER (${siteLbl}) - Worker Salary Report`,
    `Payroll Month: ${summary.periodIso} | Generated: ${generatedAt}`,
    `Worker: ${summary.worker.fullNameEn} (${summary.worker.localWorkerCode || summary.worker.id}) | Category: ${summary.worker.category} | Wage: BDT ${summary.worker.dailyWage}/day`,
    `Duty Counts -> Half: ${summary.halfDutyCount}, Full: ${summary.fullDutyCount}, 1.5x: ${summary.oneAndHalfDutyCount}, Double: ${summary.doubleDutyCount}, 2.5x: ${summary.twoAndHalfDutyCount}, Triple: ${summary.tripleDutyCount}, Absent: ${summary.absentCount}, Leave: ${summary.leaveCount}`,
    `Total Duty Units: ${summary.totalDutyUnits.toFixed(1)}`,
    `Total Earned Salary: BDT ${summary.totalEarnedAmount}`,
    `Total Paid (Incl. Advances Applied BDT ${summary.advanceAllocatedAmount}): BDT ${summary.totalPaidAmount}`,
    `Outstanding Balance: BDT ${summary.outstandingBalance} | Status: ${summary.payrollStatus} | Lock: ${summary.periodLockStatus}`,
    '--- Daily Attendance Records ---',
  ];
  for (const rec of [...dayRecords].sort((a, b) => a.dateIso.localeCompare(b.dateIso))) {
    lines.push(
      `${rec.dateIso}  ${rec.dutyType.padEnd(11)} (${rec.multiplierSnapshot}x)  Wage: BDT ${rec.dailyWageSnapshot} -> Earned: BDT ${rec.earnedAmount}  ${rec.note}`
    );
  }
  return buildSimplePdfBytes(lines, false);
}

export function buildPrintableAttendanceHtml(
  language: AppLanguage,
  periodIso: string,
  rows: WorkerMonthlySummary[],
  totals: MasterSpreadsheetTotals,
  siteHeaderLabel = 'All Sites',
  includeSiteColumn = true,
  generatedAt = new Date().toISOString().slice(0, 16).replace('T', ' ')
): string {
  const tableRows = rows
    .map((r) => {
      const name = language === 'bn' ? r.worker.fullNameBn : r.worker.fullNameEn;
      const siteCell = includeSiteColumn ? `<td>${xmlEscape(r.siteName || r.siteId)}</td>` : '';
      return `<tr>${siteCell}<td>${xmlEscape(r.worker.localWorkerCode || r.worker.id)}</td><td>${xmlEscape(name)}</td><td>${r.halfDutyCount}</td><td>${r.fullDutyCount}</td><td>${r.oneAndHalfDutyCount}</td><td>${r.doubleDutyCount}</td><td>${r.twoAndHalfDutyCount}</td><td>${r.tripleDutyCount}</td><td>${r.absentCount}</td><td>${r.leaveCount}</td><td>${r.totalDutyUnits.toFixed(1)}</td><td>৳${r.totalEarnedAmount}</td><td>৳${r.totalPaidAmount}</td><td>৳${r.outstandingBalance}</td></tr>`;
    })
    .join('\n');

  return `<!doctype html>
<html>
<head><meta charset="utf-8"><title>Site Ledger Attendance ${periodIso}</title>
<style>
  body { font-family: system-ui, sans-serif; padding: 24px; color: #0f172a; }
  h2 { margin: 0 0 4px; color: #1e3a8a; }
  p { margin: 0 0 16px; color: #475569; font-size: 13px; }
  table { border-collapse: collapse; width: 100%; font-size: 12px; }
  th, td { border: 1px solid #cbd5e1; padding: 6px 8px; text-align: left; }
  th { background: #eff6ff; font-weight: 700; }
  tfoot td { background: #f1f5f9; font-weight: 700; }
</style>
</head>
<body>
  <h2>SITE LEDGER (${xmlEscape(siteHeaderLabel)}) — Monthly Attendance & Payroll (${periodIso})</h2>
  <p>Generated: ${xmlEscape(generatedAt)} | Total Rows: ${totals.totalWorkers}</p>
  <table>
    <thead><tr>${includeSiteColumn ? '<th>Site</th>' : ''}<th>ID</th><th>Worker Name</th><th>H</th><th>F</th><th>1.5</th><th>D</th><th>2.5</th><th>T</th><th>A</th><th>L</th><th>Units</th><th>Earned</th><th>Paid</th><th>Balance</th></tr></thead>
    <tbody>${tableRows}</tbody>
    <tfoot><tr><td colspan="${includeSiteColumn ? 11 : 10}">TOTALS</td><td>${totals.totalDutyUnits.toFixed(1)}</td><td>৳${totals.totalEarnedSalary}</td><td>৳${totals.totalPaidSalary}</td><td>৳${totals.totalOutstandingSalary}</td></tr></tfoot>
  </table>
</body>
</html>`;
}

export function triggerBlobDownload(
  filename: string,
  content: BlobPart | Uint8Array,
  mimeType: string
): void {
  const part: BlobPart =
    content instanceof Uint8Array ? Uint8Array.from(content) : content;
  const blob = new Blob([part], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
