import {
  AdvanceRecord,
  AllSitesOverviewSummary,
  CurrentMonthProjection,
  DailyAttendanceRecord,
  DutyMultiplierConfig,
  DutyType,
  MasterSpreadsheetTotals,
  PaymentAllocation,
  PaymentLedgerEntry,
  PayrollPeriodRecord,
  PayrollPeriodStatus,
  Site,
  SiteExpense,
  SiteFinancialSummary,
  Worker,
  WorkerMonthlySummary,
  WorkerPayrollStatus,
} from '../types/siteLedger';

export const DEFAULT_DUTY_MULTIPLIERS: DutyMultiplierConfig = {
  halfDutyMultiplier: 0.5,
  fullDutyMultiplier: 1.0,
  oneAndHalfDutyMultiplier: 1.5,
  doubleDutyMultiplier: 2.0,
  twoAndHalfDutyMultiplier: 2.5,
  tripleDutyMultiplier: 3.0,
  absentMultiplier: 0.0,
  leaveMultiplier: 0.0,
};

export function getMultiplierForDuty(
  config: DutyMultiplierConfig,
  dutyType: DutyType
): number {
  switch (dutyType) {
    case 'HALF_DUTY':
      return config.halfDutyMultiplier;
    case 'FULL_DUTY':
      return config.fullDutyMultiplier;
    case 'ONE_AND_HALF_DUTY':
      return config.oneAndHalfDutyMultiplier;
    case 'DOUBLE_DUTY':
      return config.doubleDutyMultiplier;
    case 'TWO_AND_HALF_DUTY':
      return config.twoAndHalfDutyMultiplier;
    case 'TRIPLE_DUTY':
      return config.tripleDutyMultiplier;
    case 'ABSENT':
      return config.absentMultiplier;
    case 'LEAVE':
      return config.leaveMultiplier;
  }
}

export function toMultiplierHundredths(multiplier: number): number {
  return Math.max(0, Math.round(multiplier * 100));
}

export function formatPeriodIso(year: number, month: number): string {
  return `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}`;
}

export function calculateDailyEarnedTaka(
  dailyWage: number,
  multiplier: number
): number {
  if (dailyWage <= 0) return 0;
  const hundredths = toMultiplierHundredths(multiplier);
  return Math.trunc((dailyWage * hundredths + 50) / 100);
}

export function sumDutyUnits(records: DailyAttendanceRecord[]): number {
  const totalHundredths = records.reduce(
    (sum, r) => sum + toMultiplierHundredths(r.multiplierSnapshot),
    0
  );
  return totalHundredths / 100;
}

export function daysInMonth(year: number, month: number): number {
  if ([1, 3, 5, 7, 8, 10, 12].includes(month)) return 31;
  if ([4, 6, 9, 11].includes(month)) return 30;
  if (month === 2) {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 29 : 28;
  }
  return 30;
}

export function formatMonthPrefix(year: number, month: number): string {
  return `${formatPeriodIso(year, month)}-`;
}

export function isPeriodFinalized(
  periodIso: string,
  periodRecords: PayrollPeriodRecord[],
  siteId?: string
): boolean {
  return (
    periodRecords.find(
      (p) => p.periodIso === periodIso && (siteId === undefined || p.siteId === siteId)
    )?.status === 'FINALIZED'
  );
}

export function isLocalWorkerCodeDuplicate(
  siteId: string,
  localWorkerCode: string,
  excludeWorkerId: string | null,
  workers: Worker[]
): boolean {
  const normalized = localWorkerCode.trim().toLowerCase();
  if (!normalized) return false;
  return workers.some(
    (w) =>
      w.siteId === siteId &&
      w.id !== excludeWorkerId &&
      w.localWorkerCode.trim().toLowerCase() === normalized
  );
}

export function computeWorkerMonthlySummary(
  worker: Worker,
  year: number,
  month: number,
  allAttendance: DailyAttendanceRecord[],
  allAllocations: PaymentAllocation[],
  periodRecords: PayrollPeriodRecord[] = [],
  siteIdFilter: string | null = worker.siteId,
  sitesById: Record<string, Site> = {}
): WorkerMonthlySummary {
  const periodIso = formatPeriodIso(year, month);
  const monthPrefix = `${periodIso}-`;
  const monthAttendance = allAttendance.filter(
    (r) =>
      r.workerId === worker.id &&
      r.dateIso.startsWith(monthPrefix) &&
      (siteIdFilter === null || r.siteId === siteIdFilter)
  );
  const monthAllocations = allAllocations.filter(
    (a) =>
      !a.isVoided &&
      a.workerId === worker.id &&
      a.payrollPeriod === periodIso &&
      (siteIdFilter === null || a.siteId === siteIdFilter)
  );

  let halfDutyCount = 0;
  let fullDutyCount = 0;
  let oneAndHalfDutyCount = 0;
  let doubleDutyCount = 0;
  let twoAndHalfDutyCount = 0;
  let tripleDutyCount = 0;
  let absentCount = 0;
  let leaveCount = 0;
  let totalEarnedAmount = 0;

  for (const r of monthAttendance) {
    if (r.dutyType === 'HALF_DUTY') halfDutyCount++;
    else if (r.dutyType === 'FULL_DUTY') fullDutyCount++;
    else if (r.dutyType === 'ONE_AND_HALF_DUTY') oneAndHalfDutyCount++;
    else if (r.dutyType === 'DOUBLE_DUTY') doubleDutyCount++;
    else if (r.dutyType === 'TWO_AND_HALF_DUTY') twoAndHalfDutyCount++;
    else if (r.dutyType === 'TRIPLE_DUTY') tripleDutyCount++;
    else if (r.dutyType === 'ABSENT') absentCount++;
    else if (r.dutyType === 'LEAVE') leaveCount++;
    totalEarnedAmount += r.earnedAmount;
  }

  const totalPaidAmount = monthAllocations.reduce(
    (sum, a) => sum + a.allocatedAmount,
    0
  );
  const advanceAllocatedAmount = monthAllocations
    .filter((a) => a.sourceType === 'ADVANCE')
    .reduce((sum, a) => sum + a.allocatedAmount, 0);
  const totalDutyUnits = sumDutyUnits(monthAttendance);
  const outstandingBalance = totalEarnedAmount - totalPaidAmount;

  const workingCount =
    halfDutyCount +
    fullDutyCount +
    oneAndHalfDutyCount +
    doubleDutyCount +
    twoAndHalfDutyCount +
    tripleDutyCount;
  let payrollStatus: WorkerPayrollStatus;
  if (workingCount === 0 && totalPaidAmount === 0) {
    payrollStatus = 'NO_ATTENDANCE';
  } else if (outstandingBalance < 0) {
    payrollStatus = 'OVERPAID';
  } else if (outstandingBalance === 0 && totalEarnedAmount > 0) {
    payrollStatus = 'PAID';
  } else if (totalPaidAmount > 0 && outstandingBalance > 0) {
    payrollStatus = 'PARTIAL';
  } else {
    payrollStatus = 'UNPAID';
  }

  const effectiveSiteId = siteIdFilter ?? worker.siteId;
  const periodLockStatus: PayrollPeriodStatus = isPeriodFinalized(
    periodIso,
    periodRecords,
    effectiveSiteId
  )
    ? 'FINALIZED'
    : 'OPEN';

  return {
    worker,
    siteId: effectiveSiteId,
    siteName: sitesById[effectiveSiteId]?.siteName ?? effectiveSiteId,
    year,
    month,
    periodIso,
    totalCalendarDays: daysInMonth(year, month),
    halfDutyCount,
    fullDutyCount,
    oneAndHalfDutyCount,
    doubleDutyCount,
    twoAndHalfDutyCount,
    tripleDutyCount,
    absentCount,
    leaveCount,
    totalDutyUnits,
    totalEarnedAmount,
    totalPaidAmount,
    advanceAllocatedAmount,
    outstandingBalance,
    payrollStatus,
    periodLockStatus,
  };
}

export function computeSpreadsheetRows(params: {
  year: number;
  month: number;
  selectedSiteId: string;
  allSitesMode: boolean;
  sites: Site[];
  workers: Worker[];
  allAttendance: DailyAttendanceRecord[];
  allAllocations: PaymentAllocation[];
  periodRecords: PayrollPeriodRecord[];
  allowedSiteIds?: Set<string>;
  includeInactive?: boolean;
}): WorkerMonthlySummary[] {
  const {
    year,
    month,
    selectedSiteId,
    allSitesMode,
    sites,
    workers,
    allAttendance,
    allAllocations,
    periodRecords,
    allowedSiteIds,
    includeInactive = false,
  } = params;
  const periodIso = formatPeriodIso(year, month);
  const monthPrefix = `${periodIso}-`;
  const sitesById = Object.fromEntries(sites.map((s) => [s.id, s]));

  const targetSites = allSitesMode
    ? sites.filter((s) => !allowedSiteIds || allowedSiteIds.has(s.id))
    : sites.filter((s) => s.id === selectedSiteId);

  const rows: WorkerMonthlySummary[] = [];
  for (const site of targetSites) {
    const activityWorkerIds = new Set<string>();
    for (const w of workers) {
      if (w.siteId === site.id && (includeInactive || w.isActive)) {
        activityWorkerIds.add(w.id);
      }
    }
    for (const a of allAttendance) {
      if (a.siteId === site.id && a.dateIso.startsWith(monthPrefix)) {
        activityWorkerIds.add(a.workerId);
      }
    }
    for (const al of allAllocations) {
      if (!al.isVoided && al.siteId === site.id && al.payrollPeriod === periodIso) {
        activityWorkerIds.add(al.workerId);
      }
    }

    for (const worker of workers) {
      if (!activityWorkerIds.has(worker.id)) continue;
      if (!includeInactive && !worker.isActive) {
        const hasMonthActivity =
          allAttendance.some(
            (a) => a.workerId === worker.id && a.siteId === site.id && a.dateIso.startsWith(monthPrefix)
          ) ||
          allAllocations.some(
            (al) => !al.isVoided && al.workerId === worker.id && al.siteId === site.id && al.payrollPeriod === periodIso
          );
        if (!hasMonthActivity) continue;
      }
      rows.push(
        computeWorkerMonthlySummary(
          worker,
          year,
          month,
          allAttendance,
          allAllocations,
          periodRecords,
          site.id,
          sitesById
        )
      );
    }
  }
  return rows;
}

export function computeSiteFinancialSummary(
  site: Site,
  workers: Worker[],
  attendance: DailyAttendanceRecord[],
  allocations: PaymentAllocation[],
  expenses: SiteExpense[],
  periodIsoFilter: string | null = null
): SiteFinancialSummary {
  const siteWorkers = workers.filter((w) => w.siteId === site.id);
  const monthPrefix = periodIsoFilter ? `${periodIsoFilter}-` : null;

  const earnedPayroll = attendance
    .filter((a) => a.siteId === site.id && (!monthPrefix || a.dateIso.startsWith(monthPrefix)))
    .reduce((sum, a) => sum + a.earnedAmount, 0);

  const paidPayroll = allocations
    .filter((a) => !a.isVoided && a.siteId === site.id && (!periodIsoFilter || a.payrollPeriod === periodIsoFilter))
    .reduce((sum, a) => sum + a.allocatedAmount, 0);

  const generalExpenses = expenses
    .filter((e) => !e.isVoided && e.siteId === site.id && (!monthPrefix || e.expenseDateIso.startsWith(monthPrefix)))
    .reduce((sum, e) => sum + e.amount, 0);

  return {
    site,
    activeWorkersCount: siteWorkers.filter((w) => w.isActive).length,
    totalWorkersCount: siteWorkers.length,
    totalEarnedPayroll: earnedPayroll,
    totalPaidPayroll: paidPayroll,
    totalGeneralExpenses: generalExpenses,
    totalOutstandingPayroll: earnedPayroll - paidPayroll,
  };
}

export function computeAllSitesOverview(
  sites: Site[],
  workers: Worker[],
  attendance: DailyAttendanceRecord[],
  allocations: PaymentAllocation[],
  expenses: SiteExpense[],
  periodIsoFilter: string | null = null,
  allowedSiteIds?: Set<string>
): AllSitesOverviewSummary {
  const visibleSites = sites.filter((s) => !allowedSiteIds || allowedSiteIds.has(s.id));
  const perSiteSummaries = visibleSites.map((s) =>
    computeSiteFinancialSummary(s, workers, attendance, allocations, expenses, periodIsoFilter)
  );
  return {
    activeSiteCount: visibleSites.filter((s) => s.status === 'ACTIVE').length,
    totalWorkersCount: perSiteSummaries.reduce((sum, s) => sum + s.totalWorkersCount, 0),
    combinedEarnedPayroll: perSiteSummaries.reduce((sum, s) => sum + s.totalEarnedPayroll, 0),
    combinedPaidPayroll: perSiteSummaries.reduce((sum, s) => sum + s.totalPaidPayroll, 0),
    combinedGeneralExpenses: perSiteSummaries.reduce((sum, s) => sum + s.totalGeneralExpenses, 0),
    combinedOutstandingPayroll: perSiteSummaries.reduce((sum, s) => sum + s.totalOutstandingPayroll, 0),
    perSiteSummaries,
  };
}

export function computeCurrentMonthProjection(
  summary: WorkerMonthlySummary,
  asOfDay: number
): CurrentMonthProjection {
  const clampedDay = Math.min(Math.max(asOfDay, 1), summary.totalCalendarDays);
  const remainingDays = Math.max(0, summary.totalCalendarDays - clampedDay);
  const estimatedAdditional =
    summary.totalEarnedAmount > 0
      ? Math.trunc((summary.totalEarnedAmount * remainingDays) / clampedDay)
      : 0;
  return {
    earnedToDate: summary.totalEarnedAmount,
    paidToDate: summary.totalPaidAmount,
    remainingBalance: summary.outstandingBalance,
    dutyUnitsToDate: summary.totalDutyUnits,
    estimatedMonthEndSalary: summary.totalEarnedAmount + estimatedAdditional,
    asOfDay: clampedDay,
    totalCalendarDays: summary.totalCalendarDays,
  };
}

export function computeSpreadsheetTotals(
  rows: WorkerMonthlySummary[]
): MasterSpreadsheetTotals {
  const totalHundredths = rows.reduce(
    (sum, r) => sum + toMultiplierHundredths(r.totalDutyUnits),
    0
  );
  const earned = rows.reduce((sum, r) => sum + r.totalEarnedAmount, 0);
  const paid = rows.reduce((sum, r) => sum + r.totalPaidAmount, 0);
  return {
    totalWorkers: rows.length,
    totalDutyUnits: totalHundredths / 100,
    totalEarnedSalary: earned,
    totalPaidSalary: paid,
    totalOutstandingSalary: earned - paid,
  };
}

export function computeWorkerOverallBalances(
  workerId: string,
  allAttendance: DailyAttendanceRecord[],
  allAllocations: PaymentAllocation[],
  siteIdFilter: string | null = null
): { totalEarned: number; totalPaid: number; outstanding: number } {
  const totalEarned = allAttendance
    .filter((r) => r.workerId === workerId && (siteIdFilter === null || r.siteId === siteIdFilter))
    .reduce((sum, r) => sum + r.earnedAmount, 0);
  const totalPaid = allAllocations
    .filter((a) => !a.isVoided && a.workerId === workerId && (siteIdFilter === null || a.siteId === siteIdFilter))
    .reduce((sum, a) => sum + a.allocatedAmount, 0);
  return {
    totalEarned,
    totalPaid,
    outstanding: totalEarned - totalPaid,
  };
}

export function computeUnallocatedAdvanceBalance(
  workerId: string,
  advances: AdvanceRecord[],
  allocations: PaymentAllocation[],
  siteIdFilter: string | null = null
): number {
  const totalAdv = advances
    .filter((a) => !a.isVoided && a.workerId === workerId && (siteIdFilter === null || a.siteId === siteIdFilter))
    .reduce((sum, a) => sum + a.amount, 0);
  const totalAllocated = allocations
    .filter(
      (al) =>
        !al.isVoided &&
        al.workerId === workerId &&
        al.sourceType === 'ADVANCE' &&
        (siteIdFilter === null || al.siteId === siteIdFilter)
    )
    .reduce((sum, al) => sum + al.allocatedAmount, 0);
  return Math.max(0, totalAdv - totalAllocated);
}

export function computeAdvanceRemaining(
  advance: AdvanceRecord,
  allocations: PaymentAllocation[]
): number {
  if (advance.isVoided) return 0;
  const allocated = allocations
    .filter(
      (al) => !al.isVoided && al.sourceType === 'ADVANCE' && al.sourceId === advance.id
    )
    .reduce((sum, al) => sum + al.allocatedAmount, 0);
  return Math.max(0, advance.amount - allocated);
}

export function collectWorkerPayrollPeriods(
  workerId: string,
  allAttendance: DailyAttendanceRecord[],
  allAllocations: PaymentAllocation[],
  allPayments: PaymentLedgerEntry[],
  currentPeriodIso = '2026-11'
): Array<{ year: number; month: number; periodIso: string }> {
  const periodSet = new Set<string>([currentPeriodIso]);
  for (const r of allAttendance) {
    if (r.workerId === workerId && r.dateIso.length >= 7) {
      periodSet.add(r.dateIso.slice(0, 7));
    }
  }
  for (const a of allAllocations) {
    if (!a.isVoided && a.workerId === workerId && a.payrollPeriod.length === 7) {
      periodSet.add(a.payrollPeriod);
    }
  }
  for (const p of allPayments) {
    if (!p.isVoided && p.workerId === workerId && p.applicablePeriod.length === 7) {
      periodSet.add(p.applicablePeriod);
    }
  }

  return Array.from(periodSet)
    .map((p) => {
      const [yStr, mStr] = p.split('-');
      const year = Number(yStr);
      const month = Number(mStr);
      if (!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) {
        return null;
      }
      return { year, month, periodIso: p };
    })
    .filter((item): item is { year: number; month: number; periodIso: string } => item !== null)
    .sort((a, b) => (a.year !== b.year ? b.year - a.year : b.month - a.month));
}
