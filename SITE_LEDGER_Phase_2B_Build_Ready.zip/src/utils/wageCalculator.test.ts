import assert from 'node:assert/strict';
import test from 'node:test';
import { DUTY_TYPE_LABELS } from '../data/bilingualStrings.ts';
import {
  AdvanceRecord,
  DailyAttendanceRecord,
  DEFAULT_SITE_ID,
  DutyMultiplierConfig,
  PaymentAllocation,
  PaymentLedgerEntry,
  PayrollPeriodRecord,
  Worker,
} from '../types/siteLedger.ts';
import {
  buildAllWorkersPayrollPdfBytes,
  buildIndividualWorkerPdfBytes,
  buildPrintableAttendanceHtml,
  buildSpreadsheetExcelXml,
} from './payrollExport.ts';
import {
  calculateDailyEarnedTaka,
  collectWorkerPayrollPeriods,
  computeAdvanceRemaining,
  computeCurrentMonthProjection,
  computeSpreadsheetTotals,
  computeUnallocatedAdvanceBalance,
  computeWorkerMonthlySummary,
  computeWorkerOverallBalances,
  DEFAULT_DUTY_MULTIPLIERS,
  getMultiplierForDuty,
  isPeriodFinalized,
} from './wageCalculator.ts';

const worker300: Worker = {
  id: 'SL-201',
  siteId: DEFAULT_SITE_ID,
  localWorkerCode: 'SL-201',
  fullNameEn: 'Test Worker',
  fullNameBn: 'টেস্ট কর্মী',
  phoneNumber: '01700-000201',
  category: 'HELPER',
  joiningDateIso: '2026-08-01',
  leavingDateIso: null,
  dailyWage: 300,
  dailyFoodAllowance: 0,
  isActive: true,
  avatarUrl: null,
  photoPath: 'worker_photos/worker_SL-201.jpg',
};

test('1. Daily wage ৳300 calculates exact integer Taka for all 8 official duty types', () => {
  assert.equal(getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'HALF_DUTY'), 0.5);
  assert.equal(getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'FULL_DUTY'), 1.0);
  assert.equal(getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'ONE_AND_HALF_DUTY'), 1.5);
  assert.equal(getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'DOUBLE_DUTY'), 2.0);
  assert.equal(getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'TWO_AND_HALF_DUTY'), 2.5);
  assert.equal(getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'TRIPLE_DUTY'), 3.0);
  assert.equal(getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'ABSENT'), 0.0);
  assert.equal(getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'LEAVE'), 0.0);

  assert.equal(
    calculateDailyEarnedTaka(300, getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'HALF_DUTY')),
    150
  );
  assert.equal(
    calculateDailyEarnedTaka(300, getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'FULL_DUTY')),
    300
  );
  assert.equal(
    calculateDailyEarnedTaka(
      300,
      getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'ONE_AND_HALF_DUTY')
    ),
    450
  );
  assert.equal(
    calculateDailyEarnedTaka(300, getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'DOUBLE_DUTY')),
    600
  );
  assert.equal(
    calculateDailyEarnedTaka(
      300,
      getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'TWO_AND_HALF_DUTY')
    ),
    750
  );
  assert.equal(
    calculateDailyEarnedTaka(300, getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'TRIPLE_DUTY')),
    900
  );
  assert.equal(
    calculateDailyEarnedTaka(300, getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'ABSENT')),
    0
  );
  assert.equal(
    calculateDailyEarnedTaka(300, getMultiplierForDuty(DEFAULT_DUTY_MULTIPLIERS, 'LEAVE')),
    0
  );
});

test('2. Monthly summary: 1 Half + 2 Full + 1 Triple = 5.5 units, ৳1,650 earned, explicit allocation balance', () => {
  const attendance: DailyAttendanceRecord[] = [
    {
      dateIso: '2026-11-01',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'HALF_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 0.5,
      earnedAmount: 150,
      note: '',
      updatedAtIso: '2026-11-01T17:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-02',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'FULL_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 1.0,
      earnedAmount: 300,
      note: '',
      updatedAtIso: '2026-11-02T17:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-03',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'FULL_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 1.0,
      earnedAmount: 300,
      note: '',
      updatedAtIso: '2026-11-03T17:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-04',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'TRIPLE_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 3.0,
      earnedAmount: 900,
      note: '',
      updatedAtIso: '2026-11-04T20:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-05',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'ABSENT',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 0.0,
      earnedAmount: 0,
      note: '',
      updatedAtIso: '2026-11-05T17:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-06',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'LEAVE',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 0.0,
      earnedAmount: 0,
      note: '',
      updatedAtIso: '2026-11-06T10:00:00',
      updatedByRole: 'ADMIN',
    },
  ];

  const allocations: PaymentAllocation[] = [
    {
      allocationId: 'ALLOC-1',
      siteId: DEFAULT_SITE_ID,
      sourceType: 'PAYMENT',
      sourceId: 'TXN-TEST-1',
      workerId: worker300.id,
      payrollPeriod: '2026-11',
      allocatedAmount: 650,
      allocatedAtIso: '2026-11-04T20:30:00',
      allocatedByRole: 'ACCOUNTANT',
      note: 'Partial payment',
      isVoided: false,
    },
  ];

  const futureWorker = { ...worker300, dailyWage: 500 };

  const summary = computeWorkerMonthlySummary(futureWorker, 2026, 11, attendance, allocations);
  assert.equal(summary.totalCalendarDays, 30);
  assert.equal(summary.halfDutyCount, 1);
  assert.equal(summary.fullDutyCount, 2);
  assert.equal(summary.tripleDutyCount, 1);
  assert.equal(summary.absentCount, 1);
  assert.equal(summary.leaveCount, 1);
  assert.equal(summary.totalDutyUnits, 5.5);
  assert.equal(summary.totalEarnedAmount, 1650);
  assert.equal(summary.totalPaidAmount, 650);
  assert.equal(summary.outstandingBalance, 1000);
  assert.equal(summary.payrollStatus, 'PARTIAL');
});

test('3. Multi-month isolation, cross-month payment period allocation & chronological sorting', () => {
  const attendance: DailyAttendanceRecord[] = [
    {
      dateIso: '2026-09-25',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'FULL_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 1.0,
      earnedAmount: 300,
      note: 'Sep work',
      updatedAtIso: '2026-09-25T17:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-10-12',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'TRIPLE_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 3.0,
      earnedAmount: 900,
      note: 'Oct work',
      updatedAtIso: '2026-10-12T20:00:00',
      updatedByRole: 'ADMIN',
    },
  ];

  // Paid on 2026-11-02 (November) BUT explicitly allocated to 2026-10 salary period
  const payments: PaymentLedgerEntry[] = [
    {
      id: 'TXN-OCT-SET',
      siteId: DEFAULT_SITE_ID,
      workerId: worker300.id,
      dateIso: '2026-11-02',
      applicablePeriod: '2026-10',
      paymentType: 'SALARY',
      paidAmount: 900,
      referenceNo: 'CASH-OCT',
      noteEn: 'Oct settlement paid in Nov',
      noteBn: 'অক্টোবর পরিশোধ',
      recordedByRole: 'ACCOUNTANT',
      createdAtIso: '2026-11-02T17:00:00',
      isVoided: false,
    },
  ];
  const allocations: PaymentAllocation[] = [
    {
      allocationId: 'ALLOC-OCT',
      siteId: DEFAULT_SITE_ID,
      sourceType: 'PAYMENT',
      sourceId: 'TXN-OCT-SET',
      workerId: worker300.id,
      payrollPeriod: '2026-10',
      allocatedAmount: 900,
      allocatedAtIso: '2026-11-02T17:00:00',
      allocatedByRole: 'ACCOUNTANT',
      note: 'Oct settlement',
      isVoided: false,
    },
  ];

  const periods = collectWorkerPayrollPeriods(worker300.id, attendance, allocations, payments, '2026-11');
  assert.deepEqual(
    periods.map((p) => p.periodIso),
    ['2026-11', '2026-10', '2026-09']
  );

  const octSummary = computeWorkerMonthlySummary(worker300, 2026, 10, attendance, allocations);
  const novSummary = computeWorkerMonthlySummary(worker300, 2026, 11, attendance, allocations);
  assert.equal(octSummary.totalEarnedAmount, 900);
  assert.equal(octSummary.totalPaidAmount, 900);
  assert.equal(octSummary.outstandingBalance, 0);
  assert.equal(octSummary.payrollStatus, 'PAID');
  // November earned & paid are NOT polluted by the Nov 2 cash disbursement for Oct
  assert.equal(novSummary.totalEarnedAmount, 0);
  assert.equal(novSummary.totalPaidAmount, 0);
  assert.equal(novSummary.payrollStatus, 'NO_ATTENDANCE');
});

test('4. Advances never silently deduct salary until explicit PaymentAllocation is recorded', () => {
  const attendance: DailyAttendanceRecord[] = [
    {
      dateIso: '2026-10-20',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'FULL_DUTY',
      dailyWageSnapshot: 1000,
      multiplierSnapshot: 1.0,
      earnedAmount: 1000,
      note: '',
      updatedAtIso: '2026-10-20T17:00:00',
      updatedByRole: 'ADMIN',
    },
  ];
  const advances: AdvanceRecord[] = [
    {
      id: 'ADV-TEST-1',
      siteId: DEFAULT_SITE_ID,
      workerId: worker300.id,
      advanceDateIso: '2026-10-21',
      amount: 1000,
      referenceNo: 'ADV-01',
      note: 'Cash advance',
      recordedByRole: 'ADMIN',
      createdAtIso: '2026-10-21T12:00:00',
      isVoided: false,
    },
  ];

  // Before explicit allocation: balance MUST remain ৳1,000 owed, unallocated advance = ৳1,000
  const beforeAlloc = computeWorkerMonthlySummary(worker300, 2026, 10, attendance, []);
  assert.equal(beforeAlloc.totalPaidAmount, 0);
  assert.equal(beforeAlloc.outstandingBalance, 1000);
  assert.equal(computeUnallocatedAdvanceBalance(worker300.id, advances, []), 1000);

  // Explicitly allocate ৳600 from ADV-TEST-1 to 2026-10
  const allocations: PaymentAllocation[] = [
    {
      allocationId: 'ALLOC-ADV-1',
      siteId: DEFAULT_SITE_ID,
      sourceType: 'ADVANCE',
      sourceId: 'ADV-TEST-1',
      workerId: worker300.id,
      payrollPeriod: '2026-10',
      allocatedAmount: 600,
      allocatedAtIso: '2026-10-31T18:00:00',
      allocatedByRole: 'ACCOUNTANT',
      note: 'Partial advance recovery',
      isVoided: false,
    },
  ];

  const afterAlloc = computeWorkerMonthlySummary(worker300, 2026, 10, attendance, allocations);
  assert.equal(afterAlloc.totalPaidAmount, 600);
  assert.equal(afterAlloc.advanceAllocatedAmount, 600);
  assert.equal(afterAlloc.outstandingBalance, 400);
  assert.equal(computeAdvanceRemaining(advances[0], allocations), 400);
  assert.equal(computeUnallocatedAdvanceBalance(worker300.id, advances, allocations), 400);
});

test('5. Current month projection estimates month-end without altering earned-to-date', () => {
  const attendance: DailyAttendanceRecord[] = [
    {
      dateIso: '2026-11-01',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'FULL_DUTY',
      dailyWageSnapshot: 600,
      multiplierSnapshot: 1.0,
      earnedAmount: 600,
      note: '',
      updatedAtIso: '2026-11-01T17:00:00',
      updatedByRole: 'ADMIN',
    },
  ];
  const novSummary = computeWorkerMonthlySummary(worker300, 2026, 11, attendance, []);
  const projection = computeCurrentMonthProjection(novSummary, 15);
  assert.equal(projection.earnedToDate, 600);
  assert.equal(projection.remainingBalance, 600);
  assert.equal(projection.asOfDay, 15);
  assert.equal(projection.totalCalendarDays, 30);
  assert.equal(projection.estimatedMonthEndSalary, 1200);
});

test('6. Changing Settings multipliers preserves saved attendance snapshots & photoPath', () => {
  const customConfig: DutyMultiplierConfig = {
    ...DEFAULT_DUTY_MULTIPLIERS,
    tripleDutyMultiplier: 2.5,
  };
  const savedRecord: DailyAttendanceRecord = {
    dateIso: '2026-11-10',
    workerId: worker300.id,
    siteId: DEFAULT_SITE_ID,
    dutyType: 'TRIPLE_DUTY',
    dailyWageSnapshot: 300,
    multiplierSnapshot: 3.0,
    earnedAmount: 900,
    note: '',
    updatedAtIso: '2026-11-10T18:00:00',
    updatedByRole: 'ADMIN',
  };

  const balances = computeWorkerOverallBalances(worker300.id, [savedRecord], []);
  assert.equal(balances.totalEarned, 900);
  assert.equal(worker300.photoPath, 'worker_photos/worker_SL-201.jpg');
  assert.equal(
    calculateDailyEarnedTaka(300, getMultiplierForDuty(customConfig, 'TRIPLE_DUTY')),
    750
  );
});

test('7. Unrecorded dates never auto-marked absent and editing updates summary accurately', () => {
  const initial: DailyAttendanceRecord[] = [
    {
      dateIso: '2026-11-15',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'FULL_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 1.0,
      earnedAmount: 300,
      note: '',
      updatedAtIso: '2026-11-15T17:00:00',
      updatedByRole: 'ADMIN',
    },
  ];
  const before = computeWorkerMonthlySummary(worker300, 2026, 11, initial, []);
  assert.equal(before.absentCount, 0);
  assert.equal(before.totalDutyUnits, 1.0);
  assert.equal(before.totalEarnedAmount, 300);

  const edited: DailyAttendanceRecord[] = [
    {
      ...initial[0],
      dutyType: 'TRIPLE_DUTY',
      multiplierSnapshot: 3.0,
      earnedAmount: 900,
    },
  ];
  const after = computeWorkerMonthlySummary(worker300, 2026, 11, edited, []);
  assert.equal(after.tripleDutyCount, 1);
  assert.equal(after.fullDutyCount, 0);
  assert.equal(after.totalDutyUnits, 3.0);
  assert.equal(after.totalEarnedAmount, 900);
});

test('8. Master Spreadsheet 500-worker dataset parity matches sum of individual worker profiles', () => {
  const workers500: Worker[] = Array.from({ length: 500 }, (_, i) => ({
    ...worker300,
    id: `SL-${String(i + 1).padStart(4, '0')}`,
    localWorkerCode: `SL-${String(i + 1).padStart(4, '0')}`,
    fullNameEn: `Worker ${i + 1}`,
    dailyWage: 500,
  }));
  const records500: DailyAttendanceRecord[] = workers500.map((w, idx) => ({
    dateIso: '2026-11-15',
    workerId: w.id,
    siteId: DEFAULT_SITE_ID,
    dutyType: idx % 2 === 0 ? 'FULL_DUTY' : 'HALF_DUTY',
    dailyWageSnapshot: 500,
    multiplierSnapshot: idx % 2 === 0 ? 1.0 : 0.5,
    earnedAmount: idx % 2 === 0 ? 500 : 250,
    note: '',
    updatedAtIso: '2026-11-15T17:00:00',
    updatedByRole: 'ADMIN',
  }));
  const allocs500: PaymentAllocation[] = workers500.slice(0, 100).map((w) => ({
    allocationId: `A-${w.id}`,
    siteId: DEFAULT_SITE_ID,
    sourceType: 'PAYMENT',
    sourceId: `P-${w.id}`,
    workerId: w.id,
    payrollPeriod: '2026-11',
    allocatedAmount: 200,
    allocatedAtIso: '2026-11-15T18:00:00',
    allocatedByRole: 'ACCOUNTANT',
    note: '',
    isVoided: false,
  }));

  const rows = workers500.map((w) =>
    computeWorkerMonthlySummary(w, 2026, 11, records500, allocs500)
  );
  const totals = computeSpreadsheetTotals(rows);
  // 250 * 500 + 250 * 250 = 187,500
  assert.equal(totals.totalWorkers, 500);
  assert.equal(totals.totalDutyUnits, 375.0);
  assert.equal(totals.totalEarnedSalary, 187500);
  assert.equal(totals.totalPaidSalary, 20000);
  assert.equal(totals.totalOutstandingSalary, 167500);
});

test('9. Payroll period lock check & voided allocation reversal exclusion', () => {
  const periods: PayrollPeriodRecord[] = [
    {
      siteId: DEFAULT_SITE_ID,
      periodIso: '2026-09',
      status: 'FINALIZED',
      finalizedAtIso: '2026-10-02T10:00:00',
      finalizedByRole: 'ADMIN',
      reopenedAtIso: null,
      reopenedByRole: null,
      notes: 'Closed',
    },
    {
      siteId: DEFAULT_SITE_ID,
      periodIso: '2026-11',
      status: 'OPEN',
      finalizedAtIso: null,
      finalizedByRole: null,
      reopenedAtIso: null,
      reopenedByRole: null,
      notes: 'Active',
    },
  ];
  assert.equal(isPeriodFinalized('2026-09', periods, DEFAULT_SITE_ID), true);
  assert.equal(isPeriodFinalized('2026-11', periods, DEFAULT_SITE_ID), false);

  const allocationsWithVoid: PaymentAllocation[] = [
    {
      allocationId: 'A-KEEP',
      siteId: DEFAULT_SITE_ID,
      sourceType: 'PAYMENT',
      sourceId: 'TXN-1',
      workerId: worker300.id,
      payrollPeriod: '2026-11',
      allocatedAmount: 300,
      allocatedAtIso: '2026-11-15T10:00:00',
      allocatedByRole: 'ACCOUNTANT',
      note: 'Valid',
      isVoided: false,
    },
    {
      allocationId: 'A-VOID',
      siteId: DEFAULT_SITE_ID,
      sourceType: 'PAYMENT',
      sourceId: 'TXN-2',
      workerId: worker300.id,
      payrollPeriod: '2026-11',
      allocatedAmount: 500,
      allocatedAtIso: '2026-11-15T11:00:00',
      allocatedByRole: 'ACCOUNTANT',
      note: 'Duplicate entry',
      isVoided: true,
    },
  ];
  const summary = computeWorkerMonthlySummary(worker300, 2026, 11, [], allocationsWithVoid, periods);
  assert.equal(summary.totalPaidAmount, 300);
  assert.equal(summary.periodLockStatus, 'OPEN');
});

test('10. Offline Excel XML, Individual & All-Worker PDF, and Printable HTML exports are valid', () => {
  const summary = computeWorkerMonthlySummary(worker300, 2026, 11, [], []);
  const totals = computeSpreadsheetTotals([summary]);

  const excel = buildSpreadsheetExcelXml('en', '2026-11', [summary], totals, 'Main Site', false, '2026-11-15 10:00');
  assert.ok(excel.includes('<Workbook'));
  assert.ok(excel.includes('Payroll_2026-11'));
  assert.ok(excel.includes(worker300.id));

  const allPdf = new TextDecoder().decode(
    buildAllWorkersPayrollPdfBytes('2026-11', [summary], totals, 'Main Site', false, '2026-11-15 10:00')
  );
  assert.ok(allPdf.startsWith('%PDF-1.4'));
  assert.ok(allPdf.includes('SL-201'));
  assert.ok(allPdf.includes('%%EOF'));

  const workerPdf = new TextDecoder().decode(
    buildIndividualWorkerPdfBytes(summary, [], '2026-11-15 10:00')
  );
  assert.ok(workerPdf.startsWith('%PDF-1.4'));
  assert.ok(workerPdf.includes('Worker Salary Report'));

  const html = buildPrintableAttendanceHtml('en', '2026-11', [summary], totals, 'Main Site', false, '2026-11-15 10:00');
  assert.ok(html.includes('<!doctype html>'));
  assert.ok(html.includes('TOTALS'));
  assert.ok(html.includes('<th>1.5</th>'));
  assert.ok(html.includes('<th>2.5</th>'));
  assert.ok(excel.includes('One and Half') || excel.includes('1.5 Duty'));
  assert.ok(excel.includes('2.5 Duty'));
});

test('11. Expanded 8-duty monthly counts, mixed 1.5x/2.0x/2.5x spreadsheet parity, and exact EN/BN labels', () => {
  const attendance: DailyAttendanceRecord[] = [
    {
      dateIso: '2026-11-01',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'HALF_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 0.5,
      earnedAmount: 150,
      note: '',
      updatedAtIso: '2026-11-01T17:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-02',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'FULL_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 1.0,
      earnedAmount: 300,
      note: '',
      updatedAtIso: '2026-11-02T17:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-03',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'ONE_AND_HALF_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 1.5,
      earnedAmount: 450,
      note: '',
      updatedAtIso: '2026-11-03T18:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-04',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'DOUBLE_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 2.0,
      earnedAmount: 600,
      note: '',
      updatedAtIso: '2026-11-04T19:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-05',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'TWO_AND_HALF_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 2.5,
      earnedAmount: 750,
      note: '',
      updatedAtIso: '2026-11-05T20:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-06',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'TRIPLE_DUTY',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 3.0,
      earnedAmount: 900,
      note: '',
      updatedAtIso: '2026-11-06T21:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-07',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'ABSENT',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 0.0,
      earnedAmount: 0,
      note: '',
      updatedAtIso: '2026-11-07T17:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-08',
      workerId: worker300.id,
      siteId: DEFAULT_SITE_ID,
      dutyType: 'LEAVE',
      dailyWageSnapshot: 300,
      multiplierSnapshot: 0.0,
      earnedAmount: 0,
      note: '',
      updatedAtIso: '2026-11-08T10:00:00',
      updatedByRole: 'ADMIN',
    },
  ];

  const summary = computeWorkerMonthlySummary(worker300, 2026, 11, attendance, []);
  assert.equal(summary.halfDutyCount, 1);
  assert.equal(summary.fullDutyCount, 1);
  assert.equal(summary.oneAndHalfDutyCount, 1);
  assert.equal(summary.doubleDutyCount, 1);
  assert.equal(summary.twoAndHalfDutyCount, 1);
  assert.equal(summary.tripleDutyCount, 1);
  assert.equal(summary.absentCount, 1);
  assert.equal(summary.leaveCount, 1);
  assert.equal(summary.totalDutyUnits, 10.5);
  assert.equal(summary.totalEarnedAmount, 3150);

  const totals = computeSpreadsheetTotals([summary]);
  assert.equal(totals.totalDutyUnits, 10.5);
  assert.equal(totals.totalEarnedSalary, 3150);

  // Verify official EN & BN labels
  assert.deepEqual(DUTY_TYPE_LABELS.HALF_DUTY, { shortCode: 'H', en: 'Half Duty', bn: 'হাফ হাজিরা' });
  assert.deepEqual(DUTY_TYPE_LABELS.FULL_DUTY, { shortCode: 'F', en: 'Full Duty', bn: 'এক হাজিরা' });
  assert.deepEqual(DUTY_TYPE_LABELS.ONE_AND_HALF_DUTY, {
    shortCode: '1.5',
    en: 'One and Half Duty',
    bn: 'দেড় হাজিরা',
  });
  assert.deepEqual(DUTY_TYPE_LABELS.DOUBLE_DUTY, { shortCode: 'D', en: 'Double Duty', bn: 'দুই হাজিরা' });
  assert.deepEqual(DUTY_TYPE_LABELS.TWO_AND_HALF_DUTY, {
    shortCode: '2.5',
    en: 'Two and Half Duty',
    bn: 'আড়াই হাজিরা',
  });
  assert.deepEqual(DUTY_TYPE_LABELS.TRIPLE_DUTY, { shortCode: 'T', en: 'Triple Duty', bn: 'তিন হাজিরা' });
  assert.deepEqual(DUTY_TYPE_LABELS.ABSENT, { shortCode: 'A', en: 'Absent', bn: 'অনুপস্থিত' });
  assert.deepEqual(DUTY_TYPE_LABELS.LEAVE, { shortCode: 'L', en: 'Leave', bn: 'ছুটি' });
});
