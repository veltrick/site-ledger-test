import { useEffect, useMemo, useRef, useState } from 'react';
import { Code2, Download, RotateCcw } from 'lucide-react';
import { AndroidAppPreview } from './components/android/AndroidAppPreview';
import { ArchitectureView } from './components/studio/ArchitectureView';
import { CodeExplorerView } from './components/studio/CodeExplorerView';
import {
  ANDROID_PROJECT_FILES,
  SCREEN_TO_KOTLIN_FILE,
} from './data/androidProjectFiles';
import { BILINGUAL_STRINGS } from './data/bilingualStrings';
import {
  AVAILABLE_DATES,
  DEFAULT_EXPENSE_CATEGORIES,
  INITIAL_ADVANCES,
  INITIAL_ALLOCATIONS,
  INITIAL_ATTENDANCE,
  INITIAL_ATTENDANCE_AUDITS,
  INITIAL_EXPENSES,
  INITIAL_EXPENSE_AUDITS,
  INITIAL_PAYMENTS,
  INITIAL_PAYMENT_AUDITS,
  INITIAL_PAYROLL_AUDITS,
  INITIAL_PAYROLL_PERIODS,
  INITIAL_SITES,
  INITIAL_TRANSFERS,
  INITIAL_USER_SITE_ACCOUNTS,
  INITIAL_WORKERS,
} from './data/sampleData';
import {
  AdvanceRecord,
  AppLanguage,
  AttendanceAuditEntry,
  BackupHistoryRecord,
  BackupProgress,
  BackupValidationResult,
  DailyAttendanceRecord,
  DEFAULT_SITE_ID,
  DutyMultiplierConfig,
  DutyType,
  ExpenseAuditEntry,
  ExpenseCategory,
  NavDestination,
  PaymentAllocation,
  PaymentAuditEntry,
  PaymentLedgerEntry,
  PayrollAuditEntry,
  PayrollPeriodRecord,
  Site,
  SiteExpense,
  SyncEvent,
  UserRole,
  UserSiteAccount,
  WorkCategory,
  Worker,
  WorkerSiteHistory,
} from './types/siteLedger';
import {
  BACKUP_SCHEMA_VERSION,
  createBackupPackage,
  executeAtomicRestore,
  inspectAndVerifyBackupZip,
  normalizeRestoredState,
  SiteLedgerPersistState,
} from './utils/backupManager';
import { triggerBlobDownload } from './utils/payrollExport';
import {
  DEFAULT_DUTY_MULTIPLIERS,
  calculateDailyEarnedTaka,
  computeAdvanceRemaining,
  getMultiplierForDuty,
  isLocalWorkerCodeDuplicate,
  isPeriodFinalized,
} from './utils/wageCalculator';
import { buildZipBlob } from './utils/zipBuilder';

type WorkspaceView = 'preview' | 'code' | 'architecture';

const STORAGE_KEY_V6 = 'site_ledger_offline_store_v6';
const STORAGE_KEY_V5 = 'site_ledger_offline_store_v5';
const STORAGE_KEY_V4 = 'site_ledger_offline_store_v4';
const STORAGE_KEY_V3 = 'site_ledger_offline_store_v3';

interface StagedRestorePayload {
  validation: BackupValidationResult;
  zipBytes: Uint8Array;
  fileName: string;
}

function buildDefaultState(): SiteLedgerPersistState {
  return {
    schemaVersion: BACKUP_SCHEMA_VERSION,
    language: 'en',
    activeRole: 'ADMIN',
    selectedSiteId: DEFAULT_SITE_ID,
    selectedDateIso: AVAILABLE_DATES[0].iso,
    sites: INITIAL_SITES,
    workers: INITIAL_WORKERS,
    workerTransfers: INITIAL_TRANSFERS,
    attendance: INITIAL_ATTENDANCE,
    attendanceAudits: INITIAL_ATTENDANCE_AUDITS,
    payments: INITIAL_PAYMENTS,
    advances: INITIAL_ADVANCES,
    allocations: INITIAL_ALLOCATIONS,
    paymentAudits: INITIAL_PAYMENT_AUDITS,
    payrollPeriods: INITIAL_PAYROLL_PERIODS,
    payrollAudits: INITIAL_PAYROLL_AUDITS,
    dutyMultipliersBySite: {
      [DEFAULT_SITE_ID]: DEFAULT_DUTY_MULTIPLIERS,
      'SITE-BANANI': DEFAULT_DUTY_MULTIPLIERS,
    },
    expenseCategories: DEFAULT_EXPENSE_CATEGORIES,
    expenses: INITIAL_EXPENSES,
    expenseAudits: INITIAL_EXPENSE_AUDITS,
    userSiteAccounts: INITIAL_USER_SITE_ACCOUNTS,
    backupHistory: [],
    syncEvents: [],
  };
}

function mergeDutyConfig(saved?: Partial<DutyMultiplierConfig> | null): DutyMultiplierConfig {
  return {
    ...DEFAULT_DUTY_MULTIPLIERS,
    ...(saved ?? {}),
  };
}

function loadPersistedState(): SiteLedgerPersistState | null {
  try {
    const rawV6 = localStorage.getItem(STORAGE_KEY_V6);
    if (rawV6) {
      const parsed = JSON.parse(rawV6) as Partial<SiteLedgerPersistState>;
      if (Array.isArray(parsed.workers) && Array.isArray(parsed.attendance)) {
        const normalized = normalizeRestoredState(parsed);
        return {
          ...normalized,
          expenseCategories:
            normalized.expenseCategories.length > 0
              ? normalized.expenseCategories
              : DEFAULT_EXPENSE_CATEGORIES,
          userSiteAccounts:
            normalized.userSiteAccounts.length > 0
              ? normalized.userSiteAccounts
              : INITIAL_USER_SITE_ACCOUNTS,
        };
      }
    }

    // Non-destructive upgrade from v5 / v4 / v3 localStorage stores onto SITE-MAIN
    const legacyRaw =
      localStorage.getItem(STORAGE_KEY_V5) ??
      localStorage.getItem(STORAGE_KEY_V4) ??
      localStorage.getItem(STORAGE_KEY_V3);
    if (!legacyRaw) return null;

    const legacy = JSON.parse(legacyRaw) as {
      language?: AppLanguage;
      activeRole?: UserRole;
      dutyConfig?: Partial<DutyMultiplierConfig>;
      workers?: Worker[];
      attendanceRecords?: DailyAttendanceRecord[];
      attendanceAudits?: AttendanceAuditEntry[];
      payments?: PaymentLedgerEntry[];
      advances?: AdvanceRecord[];
      allocations?: PaymentAllocation[];
      paymentAudits?: PaymentAuditEntry[];
      payrollPeriods?: PayrollPeriodRecord[];
      payrollAudits?: PayrollAuditEntry[];
    };

    if (!Array.isArray(legacy.workers) || !Array.isArray(legacy.attendanceRecords)) {
      return null;
    }

    const migratedPayments: PaymentLedgerEntry[] = (legacy.payments ?? []).map((p) => ({
      ...p,
      siteId: p.siteId || DEFAULT_SITE_ID,
      applicablePeriod: p.applicablePeriod ?? p.dateIso.slice(0, 7),
      paymentType: p.paymentType ?? 'SALARY',
    }));

    const migratedAllocations: PaymentAllocation[] =
      legacy.allocations && legacy.allocations.length > 0
        ? legacy.allocations.map((a) => ({ ...a, siteId: a.siteId || DEFAULT_SITE_ID }))
        : migratedPayments
            .filter((p) => !p.isVoided)
            .map((p) => ({
              allocationId: `MIG-${p.id}`,
              siteId: p.siteId || DEFAULT_SITE_ID,
              sourceType: 'PAYMENT' as const,
              sourceId: p.id,
              workerId: p.workerId,
              payrollPeriod: p.applicablePeriod,
              allocatedAmount: p.paidAmount,
              allocatedAtIso: p.createdAtIso,
              allocatedByRole: p.recordedByRole,
              note: p.noteEn,
              isVoided: false,
            }));

    const upgraded = normalizeRestoredState({
      language: legacy.language ?? 'en',
      activeRole: legacy.activeRole ?? 'ADMIN',
      selectedSiteId: DEFAULT_SITE_ID,
      sites: INITIAL_SITES,
      workers: legacy.workers,
      attendance: legacy.attendanceRecords,
      attendanceAudits: legacy.attendanceAudits ?? [],
      payments: migratedPayments,
      advances: legacy.advances ?? INITIAL_ADVANCES,
      allocations: migratedAllocations,
      paymentAudits: legacy.paymentAudits ?? [],
      payrollPeriods: legacy.payrollPeriods ?? INITIAL_PAYROLL_PERIODS,
      payrollAudits: legacy.payrollAudits ?? [],
      dutyMultipliersBySite: {
        [DEFAULT_SITE_ID]: mergeDutyConfig(legacy.dutyConfig),
        'SITE-BANANI': DEFAULT_DUTY_MULTIPLIERS,
      },
      expenseCategories: DEFAULT_EXPENSE_CATEGORIES,
      expenses: INITIAL_EXPENSES,
      userSiteAccounts: INITIAL_USER_SITE_ACCOUNTS,
    });

    return upgraded;
  } catch {
    return null;
  }
}

export default function App() {
  const initialState = useMemo(() => loadPersistedState() ?? buildDefaultState(), []);
  const processedTokens = useRef<Set<string>>(new Set());

  const [workspaceView, setWorkspaceView] = useState<WorkspaceView>('preview');
  const [language, setLanguage] = useState<AppLanguage>(initialState.language);
  const [activeRole, setActiveRole] = useState<UserRole>(initialState.activeRole);
  const [sites, setSites] = useState<Site[]>(initialState.sites);
  const [selectedSiteId, setSelectedSiteId] = useState<string>(initialState.selectedSiteId);
  const [destination, setDestination] = useState<NavDestination>('dashboard');
  const [selectedDate, setSelectedDate] = useState<string>(initialState.selectedDateIso);

  const [dutyMultipliersBySite, setDutyMultipliersBySite] = useState<
    Record<string, DutyMultiplierConfig>
  >(initialState.dutyMultipliersBySite);
  const [workers, setWorkers] = useState<Worker[]>(initialState.workers);
  const [workerTransfers, setWorkerTransfers] = useState<WorkerSiteHistory[]>(
    initialState.workerTransfers
  );
  const [attendanceRecords, setAttendanceRecords] = useState<DailyAttendanceRecord[]>(
    initialState.attendance
  );
  const [attendanceAudits, setAttendanceAudits] = useState<AttendanceAuditEntry[]>(
    initialState.attendanceAudits
  );
  const [payments, setPayments] = useState<PaymentLedgerEntry[]>(initialState.payments);
  const [advances, setAdvances] = useState<AdvanceRecord[]>(initialState.advances);
  const [allocations, setAllocations] = useState<PaymentAllocation[]>(initialState.allocations);
  const [paymentAudits, setPaymentAudits] = useState<PaymentAuditEntry[]>(
    initialState.paymentAudits
  );
  const [payrollPeriods, setPayrollPeriods] = useState<PayrollPeriodRecord[]>(
    initialState.payrollPeriods
  );
  const [payrollAudits, setPayrollAudits] = useState<PayrollAuditEntry[]>(
    initialState.payrollAudits
  );
  const [expenseCategories, setExpenseCategories] = useState<ExpenseCategory[]>(
    initialState.expenseCategories
  );
  const [expenses, setExpenses] = useState<SiteExpense[]>(initialState.expenses);
  const [expenseAudits, setExpenseAudits] = useState<ExpenseAuditEntry[]>(
    initialState.expenseAudits
  );
  const [userSiteAccounts, setUserSiteAccounts] = useState<UserSiteAccount[]>(
    initialState.userSiteAccounts
  );
  const [backupHistory, setBackupHistory] = useState<BackupHistoryRecord[]>(
    initialState.backupHistory
  );
  const [syncEvents, setSyncEvents] = useState<SyncEvent[]>(initialState.syncEvents);

  const [backupProgress, setBackupProgress] = useState<BackupProgress>({
    isRunning: false,
    stageLabel: '',
    progressPercent: 0,
  });
  const [stagedRestore, setStagedRestore] = useState<StagedRestorePayload | null>(null);
  const [backupFeedback, setBackupFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);
  const [codeFocusPath, setCodeFocusPath] = useState<string>(SCREEN_TO_KOTLIN_FILE.dashboard);

  const currentPersistState = useMemo<SiteLedgerPersistState>(
    () => ({
      schemaVersion: BACKUP_SCHEMA_VERSION,
      language,
      activeRole,
      selectedSiteId,
      selectedDateIso: selectedDate,
      sites,
      workers,
      workerTransfers,
      attendance: attendanceRecords,
      attendanceAudits,
      payments,
      advances,
      allocations,
      paymentAudits,
      payrollPeriods,
      payrollAudits,
      dutyMultipliersBySite,
      expenseCategories,
      expenses,
      expenseAudits,
      userSiteAccounts,
      backupHistory,
      syncEvents,
    }),
    [
      language,
      activeRole,
      selectedSiteId,
      selectedDate,
      sites,
      workers,
      workerTransfers,
      attendanceRecords,
      attendanceAudits,
      payments,
      advances,
      allocations,
      paymentAudits,
      payrollPeriods,
      payrollAudits,
      dutyMultipliersBySite,
      expenseCategories,
      expenses,
      expenseAudits,
      userSiteAccounts,
      backupHistory,
      syncEvents,
    ]
  );

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_V6, JSON.stringify(currentPersistState));
    } catch {
      // Ignore storage quota errors cleanly
    }
  }, [currentPersistState]);

  const activeSite = useMemo(
    () => sites.find((s) => s.id === selectedSiteId) ?? sites[0] ?? INITIAL_SITES[0],
    [sites, selectedSiteId]
  );

  const activeDutyConfig = useMemo(
    () => mergeDutyConfig(dutyMultipliersBySite[activeSite.id]),
    [dutyMultipliersBySite, activeSite.id]
  );

  const allowedSiteIds = useMemo(() => {
    if (activeRole === 'ADMIN') {
      return new Set(sites.map((s) => s.id));
    }
    const account = userSiteAccounts.find((u) => u.role === activeRole);
    if (!account) return new Set(sites.map((s) => s.id));
    if (account.canManageAllSites) return new Set(sites.map((s) => s.id));
    return new Set(account.assignedSiteIds);
  }, [activeRole, userSiteAccounts, sites]);

  const hasActiveSiteAccess = activeRole === 'ADMIN' || allowedSiteIds.has(activeSite.id);
  const strings = BILINGUAL_STRINGS[language];

  const recordSyncEvent = (entityType: string, entityId: string, siteId: string, action: string) => {
    const evt: SyncEvent = {
      eventId: `SYNC-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      entityType,
      entityId,
      siteId,
      action,
      updatedAtIso: new Date().toISOString().slice(0, 19),
      deviceId: 'LOCAL-ANDROID-PREVIEW',
      syncStatus: 'LOCAL_ONLY',
    };
    setSyncEvents((prev) => [evt, ...prev].slice(0, 200));
  };

  const handleSelectRole = (nextRole: UserRole) => {
    setActiveRole(nextRole);
    const nextAllowed =
      nextRole === 'ADMIN'
        ? new Set(sites.map((s) => s.id))
        : new Set(
            userSiteAccounts.find((u) => u.role === nextRole)?.assignedSiteIds ??
              sites.map((s) => s.id)
          );
    if (!nextAllowed.has(selectedSiteId) && nextAllowed.size > 0) {
      const firstAllowed = sites.find((s) => nextAllowed.has(s.id));
      if (firstAllowed) setSelectedSiteId(firstAllowed.id);
    }
  };

  const handleAddWorker = (input: {
    fullName: string;
    localWorkerCode: string;
    phoneNumber: string;
    category: WorkCategory;
    joiningDateIso: string;
    dailyWage: number;
    foodAllowance: number;
    isActive: boolean;
    avatarUrl: string | null;
    photoPath: string | null;
  }) => {
    if (activeRole === 'ACCOUNTANT' || !hasActiveSiteAccess) return;
    if (isLocalWorkerCodeDuplicate(activeSite.id, input.localWorkerCode, null, workers)) return;

    const cleanCode = input.localWorkerCode.trim();
    const globallyUniqueId = workers.some((w) => w.id === cleanCode)
      ? `${activeSite.siteCode}-${cleanCode}-${Date.now().toString(36).slice(-4).toUpperCase()}`
      : cleanCode;

    const created: Worker = {
      id: globallyUniqueId,
      siteId: activeSite.id,
      localWorkerCode: cleanCode,
      fullNameEn: input.fullName,
      fullNameBn: input.fullName,
      phoneNumber: input.phoneNumber,
      category: input.category,
      joiningDateIso: input.joiningDateIso,
      leavingDateIso: null,
      dailyWage: input.dailyWage,
      dailyFoodAllowance: input.foodAllowance,
      isActive: input.isActive,
      avatarUrl: input.avatarUrl,
      photoPath: input.photoPath,
    };
    setWorkers((prev) => [created, ...prev]);
    recordSyncEvent('WORKER', created.id, activeSite.id, 'CREATED');
  };

  const handleEditWorker = (updated: Worker) => {
    if (activeRole === 'ACCOUNTANT' || !hasActiveSiteAccess) return;
    if (isLocalWorkerCodeDuplicate(updated.siteId, updated.localWorkerCode, updated.id, workers)) {
      return;
    }
    setWorkers((prev) => prev.map((w) => (w.id === updated.id ? updated : w)));
    recordSyncEvent('WORKER', updated.id, updated.siteId, 'UPDATED');
  };

  const handleTransferWorker = (input: {
    workerId: string;
    toSiteId: string;
    newLocalCode: string;
    transferDateIso: string;
    note: string;
  }) => {
    if (activeRole !== 'ADMIN') return;
    const worker = workers.find((w) => w.id === input.workerId);
    if (!worker || worker.siteId === input.toSiteId) return;
    if (isLocalWorkerCodeDuplicate(input.toSiteId, input.newLocalCode, worker.id, workers)) {
      return;
    }

    const transferRecord: WorkerSiteHistory = {
      historyId: `TRF-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      workerId: worker.id,
      fromSiteId: worker.siteId,
      toSiteId: input.toSiteId,
      transferDateIso: input.transferDateIso,
      transferredByRole: activeRole,
      note: input.note || 'Site transfer',
      previousLocalCode: worker.localWorkerCode,
      newLocalCode: input.newLocalCode.trim(),
    };

    // Important: only move the worker's current active assignment & local code;
    // historical attendance, payments, advances & allocations keep their original siteId!
    setWorkers((prev) =>
      prev.map((w) =>
        w.id === worker.id
          ? { ...w, siteId: input.toSiteId, localWorkerCode: input.newLocalCode.trim() }
          : w
      )
    );
    setWorkerTransfers((prev) => [transferRecord, ...prev]);
    recordSyncEvent('WORKER_TRANSFER', worker.id, input.toSiteId, 'TRANSFERRED');
  };

  const handleRecordAttendance = (input: {
    dateIso: string;
    worker: Worker;
    dutyType: DutyType;
    note: string;
    editReason?: string;
  }) => {
    if (activeRole === 'ACCOUNTANT' || !hasActiveSiteAccess) return;
    const periodIso = input.dateIso.slice(0, 7);
    const workerSiteId = input.worker.siteId;
    if (isPeriodFinalized(periodIso, payrollPeriods, workerSiteId)) return;

    const nowIso = new Date().toISOString().slice(0, 19);
    const existing = attendanceRecords.find(
      (r) =>
        r.dateIso === input.dateIso &&
        r.workerId === input.worker.id &&
        r.siteId === workerSiteId
    );
    const wageBase = existing?.dailyWageSnapshot ?? input.worker.dailyWage;
    const siteCfg = mergeDutyConfig(dutyMultipliersBySite[workerSiteId]);
    const multiplier = getMultiplierForDuty(siteCfg, input.dutyType);
    const earned = calculateDailyEarnedTaka(wageBase, multiplier);

    const nextRecord: DailyAttendanceRecord = {
      dateIso: input.dateIso,
      workerId: input.worker.id,
      siteId: workerSiteId,
      dutyType: input.dutyType,
      dailyWageSnapshot: wageBase,
      multiplierSnapshot: multiplier,
      earnedAmount: earned,
      note: input.note,
      updatedAtIso: nowIso,
      updatedByRole: activeRole,
    };

    setAttendanceRecords((prev) => [
      ...prev.filter(
        (r) =>
          !(
            r.dateIso === input.dateIso &&
            r.workerId === input.worker.id &&
            r.siteId === workerSiteId
          )
      ),
      nextRecord,
    ]);

    const auditEntry: AttendanceAuditEntry = {
      auditId: `AUD-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      dateIso: input.dateIso,
      workerId: input.worker.id,
      siteId: workerSiteId,
      previousDutyType: existing?.dutyType ?? null,
      newDutyType: input.dutyType,
      previousEarned: existing?.earnedAmount ?? null,
      newEarned: earned,
      changedByRole: activeRole,
      changedAtIso: nowIso,
      reason: input.editReason ?? (existing ? 'Attendance updated' : 'Initial record'),
    };
    setAttendanceAudits((prev) => [auditEntry, ...prev]);
    recordSyncEvent('ATTENDANCE', `${input.worker.id}:${input.dateIso}`, workerSiteId, 'UPSERT');
  };

  const handleRecordPayment = (input: {
    workerId: string;
    dateIso: string;
    applicablePeriod: string;
    paidAmount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => {
    if (activeRole === 'MANAGER' || !hasActiveSiteAccess) return;
    if (input.paidAmount <= 0) return;
    const targetWorker = workers.find((w) => w.id === input.workerId);
    const txSiteId = targetWorker?.siteId ?? activeSite.id;
    if (isPeriodFinalized(input.applicablePeriod, payrollPeriods, txSiteId)) return;
    if (processedTokens.current.has(input.submissionToken)) return;
    processedTokens.current.add(input.submissionToken);

    const nowIso = new Date().toISOString().slice(0, 19);
    const txId = `TXN-${510 + payments.length + 1}`;
    const amountInt = Math.trunc(input.paidAmount);
    const entry: PaymentLedgerEntry = {
      id: txId,
      siteId: txSiteId,
      workerId: input.workerId,
      dateIso: input.dateIso,
      applicablePeriod: input.applicablePeriod,
      paymentType: 'SALARY',
      paidAmount: amountInt,
      referenceNo: input.referenceNo,
      noteEn: input.note,
      noteBn: input.note,
      recordedByRole: activeRole,
      createdAtIso: nowIso,
      isVoided: false,
    };
    const allocation: PaymentAllocation = {
      allocationId: `ALLOC-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      siteId: txSiteId,
      sourceType: 'PAYMENT',
      sourceId: txId,
      workerId: input.workerId,
      payrollPeriod: input.applicablePeriod,
      allocatedAmount: amountInt,
      allocatedAtIso: nowIso,
      allocatedByRole: activeRole,
      note: input.note,
      isVoided: false,
    };

    setPayments((prev) => [entry, ...prev]);
    setAllocations((prev) => [allocation, ...prev]);
    setPaymentAudits((prev) => [
      {
        auditId: `PAUD-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        siteId: txSiteId,
        transactionId: txId,
        workerId: input.workerId,
        action: 'CREATED',
        previousAmount: null,
        newAmount: amountInt,
        changedByRole: activeRole,
        changedAtIso: nowIso,
        reason: `${input.applicablePeriod} · ${input.note}`,
      },
      ...prev,
    ]);
    recordSyncEvent('PAYMENT', txId, txSiteId, 'CREATED');
  };

  const handleRecordAdvance = (input: {
    workerId: string;
    advanceDateIso: string;
    amount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => {
    if (activeRole === 'MANAGER' || !hasActiveSiteAccess) return;
    if (input.amount <= 0) return;
    if (processedTokens.current.has(input.submissionToken)) return;
    processedTokens.current.add(input.submissionToken);

    const targetWorker = workers.find((w) => w.id === input.workerId);
    const advSiteId = targetWorker?.siteId ?? activeSite.id;
    const nowIso = new Date().toISOString().slice(0, 19);
    const advId = `ADV-${200 + advances.length + 1}`;
    const adv: AdvanceRecord = {
      id: advId,
      siteId: advSiteId,
      workerId: input.workerId,
      advanceDateIso: input.advanceDateIso,
      amount: Math.trunc(input.amount),
      referenceNo: input.referenceNo,
      note: input.note,
      recordedByRole: activeRole,
      createdAtIso: nowIso,
      isVoided: false,
    };
    setAdvances((prev) => [adv, ...prev]);
    setPaymentAudits((prev) => [
      {
        auditId: `PAUD-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        siteId: advSiteId,
        transactionId: advId,
        workerId: input.workerId,
        action: 'ADVANCE_CREATED',
        previousAmount: null,
        newAmount: adv.amount,
        changedByRole: activeRole,
        changedAtIso: nowIso,
        reason: input.note || 'Advance issued (unallocated)',
      },
      ...prev,
    ]);
    recordSyncEvent('ADVANCE', advId, advSiteId, 'CREATED');
  };

  const handleAllocateAdvance = (input: {
    advanceId: string;
    targetPeriod: string;
    amountToAllocate: number;
    note: string;
  }) => {
    if (activeRole === 'MANAGER' || !hasActiveSiteAccess) return;
    if (input.amountToAllocate <= 0) return;

    const targetAdv = advances.find((a) => a.id === input.advanceId && !a.isVoided);
    if (!targetAdv) return;
    if (isPeriodFinalized(input.targetPeriod, payrollPeriods, targetAdv.siteId)) return;

    const remaining = computeAdvanceRemaining(targetAdv, allocations);
    if (input.amountToAllocate > remaining) return;

    const nowIso = new Date().toISOString().slice(0, 19);
    const allocAmount = Math.trunc(input.amountToAllocate);
    const allocation: PaymentAllocation = {
      allocationId: `ALLOC-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      siteId: targetAdv.siteId,
      sourceType: 'ADVANCE',
      sourceId: targetAdv.id,
      workerId: targetAdv.workerId,
      payrollPeriod: input.targetPeriod,
      allocatedAmount: allocAmount,
      allocatedAtIso: nowIso,
      allocatedByRole: activeRole,
      note: input.note || `Allocated from ${targetAdv.id}`,
      isVoided: false,
    };
    setAllocations((prev) => [allocation, ...prev]);
    setPaymentAudits((prev) => [
      {
        auditId: `PAUD-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        siteId: targetAdv.siteId,
        transactionId: targetAdv.id,
        workerId: targetAdv.workerId,
        action: 'ALLOCATED',
        previousAmount: remaining,
        newAmount: allocAmount,
        changedByRole: activeRole,
        changedAtIso: nowIso,
        reason: `${input.targetPeriod} · ${input.note || 'Manual advance allocation'}`,
      },
      ...prev,
    ]);
    recordSyncEvent('ALLOCATION', allocation.allocationId, targetAdv.siteId, 'CREATED');
  };

  const handleVoidPayment = (transactionId: string, reason: string) => {
    if (activeRole === 'MANAGER' || !hasActiveSiteAccess) return;
    const target = payments.find((p) => p.id === transactionId && !p.isVoided);
    if (!target) return;
    if (isPeriodFinalized(target.applicablePeriod, payrollPeriods, target.siteId)) return;

    const nowIso = new Date().toISOString().slice(0, 19);
    setPayments((prev) =>
      prev.map((p) => (p.id === transactionId ? { ...p, isVoided: true } : p))
    );
    setAllocations((prev) =>
      prev.map((al) =>
        al.sourceType === 'PAYMENT' && al.sourceId === transactionId
          ? { ...al, isVoided: true }
          : al
      )
    );
    setPaymentAudits((prev) => [
      {
        auditId: `PAUD-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        siteId: target.siteId,
        transactionId,
        workerId: target.workerId,
        action: 'VOIDED',
        previousAmount: target.paidAmount,
        newAmount: 0,
        changedByRole: activeRole,
        changedAtIso: nowIso,
        reason,
      },
      ...prev,
    ]);
    recordSyncEvent('PAYMENT', transactionId, target.siteId, 'VOIDED');
  };

  const handleFinalizePeriod = (periodIso: string, reason: string) => {
    if (activeRole !== 'ADMIN') return;
    const nowIso = new Date().toISOString().slice(0, 19);
    setPayrollPeriods((prev) => {
      const existing = prev.find((p) => p.siteId === activeSite.id && p.periodIso === periodIso);
      if (existing) {
        return prev.map((p) =>
          p.siteId === activeSite.id && p.periodIso === periodIso
            ? {
                ...p,
                status: 'FINALIZED',
                finalizedAtIso: nowIso,
                finalizedByRole: 'ADMIN',
                notes: reason || p.notes,
              }
            : p
        );
      }
      return [
        ...prev,
        {
          siteId: activeSite.id,
          periodIso,
          status: 'FINALIZED',
          finalizedAtIso: nowIso,
          finalizedByRole: 'ADMIN',
          reopenedAtIso: null,
          reopenedByRole: null,
          notes: reason,
        },
      ];
    });
    setPayrollAudits((prev) => [
      {
        auditId: `PAYAUD-${Date.now()}`,
        siteId: activeSite.id,
        periodIso,
        action: 'FINALIZED',
        changedByRole: 'ADMIN',
        changedAtIso: nowIso,
        reason: reason || 'Payroll finalized',
      },
      ...prev,
    ]);
    recordSyncEvent('PAYROLL_PERIOD', periodIso, activeSite.id, 'FINALIZED');
  };

  const handleReopenPeriod = (periodIso: string, reason: string) => {
    if (activeRole !== 'ADMIN') return;
    const nowIso = new Date().toISOString().slice(0, 19);
    setPayrollPeriods((prev) =>
      prev.map((p) =>
        p.siteId === activeSite.id && p.periodIso === periodIso
          ? {
              ...p,
              status: 'OPEN',
              reopenedAtIso: nowIso,
              reopenedByRole: 'ADMIN',
              notes: reason || p.notes,
            }
          : p
      )
    );
    setPayrollAudits((prev) => [
      {
        auditId: `PAYAUD-${Date.now()}`,
        siteId: activeSite.id,
        periodIso,
        action: 'REOPENED',
        changedByRole: 'ADMIN',
        changedAtIso: nowIso,
        reason: reason || 'Payroll reopened',
      },
      ...prev,
    ]);
    recordSyncEvent('PAYROLL_PERIOD', periodIso, activeSite.id, 'REOPENED');
  };

  const handleSaveExpense = (expense: SiteExpense) => {
    if (!hasActiveSiteAccess) return;
    const existing = expenses.find((e) => e.id === expense.id);
    const nowIso = new Date().toISOString().slice(0, 19);
    if (existing) {
      setExpenses((prev) => prev.map((e) => (e.id === expense.id ? expense : e)));
    } else {
      setExpenses((prev) => [expense, ...prev]);
    }
    setExpenseAudits((prev) => [
      {
        auditId: `EXPAUD-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        expenseId: expense.id,
        siteId: expense.siteId,
        action: existing ? 'UPDATED' : 'CREATED',
        previousAmount: existing ? existing.amount : null,
        newAmount: expense.amount,
        changedByRole: activeRole,
        changedAtIso: nowIso,
        reason: existing ? 'Updated expense entry' : 'Recorded general site expense',
      },
      ...prev,
    ]);
    recordSyncEvent('EXPENSE', expense.id, expense.siteId, existing ? 'UPDATED' : 'CREATED');
  };

  const handleVoidExpense = (expenseId: string, reason: string) => {
    if (activeRole === 'MANAGER' || !hasActiveSiteAccess) return;
    const target = expenses.find((e) => e.id === expenseId && !e.isVoided);
    if (!target) return;
    const nowIso = new Date().toISOString().slice(0, 19);
    setExpenses((prev) =>
      prev.map((e) => (e.id === expenseId ? { ...e, isVoided: true } : e))
    );
    setExpenseAudits((prev) => [
      {
        auditId: `EXPAUD-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        expenseId,
        siteId: target.siteId,
        action: 'VOIDED',
        previousAmount: target.amount,
        newAmount: 0,
        changedByRole: activeRole,
        changedAtIso: nowIso,
        reason: reason || 'Voided / reversed expense',
      },
      ...prev,
    ]);
    recordSyncEvent('EXPENSE', expenseId, target.siteId, 'VOIDED');
  };

  const handleAddCategory = (nameEn: string, nameBn: string) => {
    if (activeRole !== 'ADMIN') return;
    const cleanEn = nameEn.trim();
    if (!cleanEn) return;
    const newCat: ExpenseCategory = {
      id: `CAT-CUSTOM-${Date.now().toString(36).toUpperCase()}`,
      nameEn: cleanEn,
      nameBn: nameBn.trim() || cleanEn,
      isSystemDefault: false,
    };
    setExpenseCategories((prev) => [...prev, newCat]);
  };

  const handleSaveSite = (site: Site) => {
    if (activeRole !== 'ADMIN') return;
    const existing = sites.find((s) => s.id === site.id);
    if (existing) {
      setSites((prev) => prev.map((s) => (s.id === site.id ? site : s)));
    } else {
      setSites((prev) => [...prev, site]);
      setDutyMultipliersBySite((prev) => ({
        ...prev,
        [site.id]: DEFAULT_DUTY_MULTIPLIERS,
      }));
      setUserSiteAccounts((prev) =>
        prev.map((acc) =>
          acc.role === 'ADMIN'
            ? { ...acc, assignedSiteIds: Array.from(new Set([...acc.assignedSiteIds, site.id])) }
            : acc
        )
      );
    }
    recordSyncEvent('SITE', site.id, site.id, existing ? 'UPDATED' : 'CREATED');
  };

  const handleArchiveSite = (siteId: string) => {
    if (activeRole !== 'ADMIN' || sites.length <= 1) return;
    setSites((prev) =>
      prev.map((s) => (s.id === siteId ? { ...s, status: 'ARCHIVED' } : s))
    );
    recordSyncEvent('SITE', siteId, siteId, 'ARCHIVED');
  };

  const handleUpdateRoleSiteAssignments = (role: UserRole, nextAssignedSiteIds: string[]) => {
    if (activeRole !== 'ADMIN' || role === 'ADMIN') return;
    setUserSiteAccounts((prev) =>
      prev.map((u) => (u.role === role ? { ...u, assignedSiteIds: nextAssignedSiteIds } : u))
    );
  };

  const handleSaveDutyConfig = (nextConfig: DutyMultiplierConfig) => {
    if (activeRole !== 'ADMIN') return;
    setDutyMultipliersBySite((prev) => ({
      ...prev,
      [activeSite.id]: nextConfig,
    }));
  };

  const applyRestoredPersistState = (next: SiteLedgerPersistState) => {
    processedTokens.current.clear();
    setLanguage(next.language);
    setActiveRole(next.activeRole);
    setSites(next.sites);
    setSelectedSiteId(next.selectedSiteId || next.sites[0]?.id || DEFAULT_SITE_ID);
    setSelectedDate(next.selectedDateIso || AVAILABLE_DATES[0].iso);
    setWorkers(next.workers);
    setWorkerTransfers(next.workerTransfers);
    setAttendanceRecords(next.attendance);
    setAttendanceAudits(next.attendanceAudits);
    setPayments(next.payments);
    setAdvances(next.advances);
    setAllocations(next.allocations);
    setPaymentAudits(next.paymentAudits);
    setPayrollPeriods(next.payrollPeriods);
    setPayrollAudits(next.payrollAudits);
    setDutyMultipliersBySite(
      Object.keys(next.dutyMultipliersBySite).length > 0
        ? next.dutyMultipliersBySite
        : { [DEFAULT_SITE_ID]: DEFAULT_DUTY_MULTIPLIERS }
    );
    setExpenseCategories(
      next.expenseCategories.length > 0 ? next.expenseCategories : DEFAULT_EXPENSE_CATEGORIES
    );
    setExpenses(next.expenses);
    setExpenseAudits(next.expenseAudits);
    setUserSiteAccounts(
      next.userSiteAccounts.length > 0 ? next.userSiteAccounts : INITIAL_USER_SITE_ACCOUNTS
    );
    setBackupHistory(next.backupHistory);
    setSyncEvents(next.syncEvents);
  };

  const handleCreateFullBackup = () => {
    try {
      setBackupProgress({ isRunning: true, stageLabel: 'Bundling SQLite snapshot & photos...', progressPercent: 45 });
      const pkg = createBackupPackage(currentPersistState);
      triggerBlobDownload(pkg.fileName, pkg.zipBytes, 'application/zip');

      setBackupHistory((prev) => [pkg.historyRecord, ...prev]);
      setBackupProgress({ isRunning: false, stageLabel: 'Completed', progressPercent: 100 });
      setBackupFeedback({
        type: 'success',
        message: `${pkg.fileName} created (${(pkg.zipBytes.length / 1024).toFixed(1)} KB, SHA-256 verified).`,
      });
    } catch (err) {
      setBackupProgress({ isRunning: false, stageLabel: '', progressPercent: 0 });
      setBackupFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Backup creation failed.',
      });
    }
  };

  const handleInspectBackupFile = async (file: File, openRestorePrompt: boolean) => {
    try {
      setBackupProgress({ isRunning: true, stageLabel: 'Verifying SHA-256 checksums...', progressPercent: 60 });
      const buffer = await file.arrayBuffer();
      const zipBytes = new Uint8Array(buffer);
      const { validation } = inspectAndVerifyBackupZip(zipBytes, file.name, currentPersistState);
      setBackupProgress({ isRunning: false, stageLabel: '', progressPercent: 100 });

      if (!validation.isValid) {
        setStagedRestore(null);
        setBackupFeedback({
          type: 'error',
          message: `Backup rejected: ${validation.errors.join(' · ')}`,
        });
        return;
      }

      if (openRestorePrompt) {
        setStagedRestore({ validation, zipBytes, fileName: file.name });
        setBackupFeedback(null);
      } else {
        setBackupFeedback({
          type: 'success',
          message: `Verified ${file.name}: ${validation.counts.sites} sites, ${validation.counts.workers} workers, ${validation.counts.workerPhotos} photos, ${validation.counts.receiptImages} receipts. SHA-256 OK.`,
        });
      }
    } catch (err) {
      setBackupProgress({ isRunning: false, stageLabel: '', progressPercent: 0 });
      setBackupFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Unable to read backup archive.',
      });
    }
  };

  const handleConfirmRestore = () => {
    if (!stagedRestore) return;
    setBackupProgress({ isRunning: true, stageLabel: 'Creating safety backup & restoring atomically...', progressPercent: 80 });
    const result = executeAtomicRestore({
      zipBytes: stagedRestore.zipBytes,
      fileName: stagedRestore.fileName,
      currentState: currentPersistState,
      applyState: (restoredState) => {
        applyRestoredPersistState(restoredState);
      },
      saveSafetyBackup: (safetyZip, safetyName) => {
        // Trigger local download of safety pre-restore archive & keep checksum record
        triggerBlobDownload(safetyName, safetyZip, 'application/zip');
      },
    });
    setBackupProgress({ isRunning: false, stageLabel: '', progressPercent: 100 });
    setStagedRestore(null);

    if (result.success) {
      setBackupFeedback({
        type: 'success',
        message: `Restored ${stagedRestore.fileName} cleanly. Safety archive downloaded: ${result.safetyBackupFileName}.`,
      });
    } else {
      setBackupFeedback({
        type: 'error',
        message: result.validation.errors.join(' · ') || 'Restore aborted safely.',
      });
    }
  };

  const handleResetSampleData = () => {
    const defaults = buildDefaultState();
    applyRestoredPersistState(defaults);
    setStagedRestore(null);
    setBackupFeedback(null);
    try {
      localStorage.removeItem(STORAGE_KEY_V6);
      localStorage.removeItem(STORAGE_KEY_V5);
      localStorage.removeItem(STORAGE_KEY_V4);
      localStorage.removeItem(STORAGE_KEY_V3);
    } catch {
      // Ignore
    }
  };

  const handleDownloadAndroidZip = () => {
    const zipBlob = buildZipBlob(
      ANDROID_PROJECT_FILES.map((file) => ({
        path: `SiteLedger/${file.path}`,
        content: file.content,
      }))
    );
    triggerBlobDownload('site-ledger-android-kotlin.zip', zipBlob, 'application/zip');
  };

  const activeKotlinFile = useMemo(() => {
    const path = SCREEN_TO_KOTLIN_FILE[destination];
    return ANDROID_PROJECT_FILES.find((f) => f.path === path);
  }, [destination]);

  const screenJumpItems: { dest: NavDestination; label: string }[] = [
    { dest: 'dashboard', label: `1. ${strings.navDashboard}` },
    { dest: 'workers', label: `2. ${strings.navWorkers}` },
    { dest: 'attendance', label: `3. ${strings.navAttendance}` },
    { dest: 'spreadsheet', label: `4. ${strings.navSpreadsheet}` },
    { dest: 'payments', label: `5. ${strings.navPayments}` },
    { dest: 'expenses', label: `6. ${strings.navExpenses}` },
    { dest: 'reports', label: `7. ${strings.navReports}` },
    { dest: 'sites', label: `8. ${strings.navSites}` },
    { dest: 'settings', label: `9. ${strings.navSettings}` },
  ];

  const todayPresentCount = attendanceRecords.filter(
    (r) =>
      r.siteId === activeSite.id &&
      r.dateIso === '2026-11-15' &&
      r.dutyType !== 'ABSENT' &&
      r.dutyType !== 'LEAVE'
  ).length;
  const workersWithPhotosCount = workers.filter((w) => Boolean(w.photoPath)).length;

  return (
    <div className="min-h-screen bg-[#F4F6F9] text-slate-900">
      {/* Top Bar Contract: Brand wordmark — Nav links — 1 Primary Action */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-4 py-3.5 sm:px-6">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setWorkspaceView('preview');
            }}
            className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            SITE LEDGER
          </a>

          <nav className="hidden items-center gap-6 text-sm font-medium text-slate-600 md:flex">
            <button
              type="button"
              onClick={() => setWorkspaceView('preview')}
              className={`border-b-2 py-1 transition-colors whitespace-nowrap shrink-0 ${
                workspaceView === 'preview'
                  ? 'border-blue-700 text-blue-800'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Interactive Preview
            </button>
            <button
              type="button"
              onClick={() => {
                setCodeFocusPath(SCREEN_TO_KOTLIN_FILE[destination]);
                setWorkspaceView('code');
              }}
              className={`border-b-2 py-1 transition-colors whitespace-nowrap shrink-0 ${
                workspaceView === 'code'
                  ? 'border-blue-700 text-blue-800'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Kotlin Source
            </button>
            <button
              type="button"
              onClick={() => setWorkspaceView('architecture')}
              className={`border-b-2 py-1 transition-colors whitespace-nowrap shrink-0 ${
                workspaceView === 'architecture'
                  ? 'border-blue-700 text-blue-800'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Architecture
            </button>
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handleDownloadAndroidZip}
              className="flex min-h-[40px] items-center gap-2 rounded-xl bg-blue-700 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-800 whitespace-nowrap shrink-0"
            >
              <Download className="h-4 w-4 shrink-0" />
              <span>Download Android Project</span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile View Switcher (visible only < md) */}
      <div className="border-b border-slate-200 bg-white px-4 py-2 md:hidden">
        <div className="grid grid-cols-3 gap-1 rounded-xl bg-slate-100 p-1">
          {(['preview', 'code', 'architecture'] as WorkspaceView[]).map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setWorkspaceView(tab)}
              className={`rounded-lg px-2 py-1.5 text-xs font-semibold capitalize transition-colors whitespace-nowrap ${
                workspaceView === tab
                  ? 'bg-white text-blue-800 shadow-xs'
                  : 'text-slate-600'
              }`}
            >
              {tab === 'preview' ? 'Preview' : tab === 'code' ? 'Kotlin' : 'Structure'}
            </button>
          ))}
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:py-8">
        {workspaceView === 'preview' && (
          <div className="grid grid-cols-1 items-start gap-8 lg:grid-cols-[412px_1fr]">
            {/* Left Anchor: Live Interactive Material 3 Android Phone Preview */}
            <div className="flex justify-center lg:justify-start">
              <AndroidAppPreview
                strings={strings}
                language={language}
                destination={destination}
                activeRole={activeRole}
                activeSite={activeSite}
                sites={sites}
                allowedSiteIds={allowedSiteIds}
                dutyConfig={activeDutyConfig}
                onNavigate={setDestination}
                onSelectSite={setSelectedSiteId}
                onSelectLanguage={setLanguage}
                onSelectRole={handleSelectRole}
                onSaveDutyConfig={handleSaveDutyConfig}
                workers={workers}
                workerTransfers={workerTransfers}
                attendanceRecords={attendanceRecords}
                attendanceAudits={attendanceAudits}
                payments={payments}
                advances={advances}
                allocations={allocations}
                paymentAudits={paymentAudits}
                payrollPeriods={payrollPeriods}
                expenseCategories={expenseCategories}
                expenses={expenses}
                userSiteAccounts={userSiteAccounts}
                backupHistory={backupHistory}
                backupProgress={backupProgress}
                pendingRestore={stagedRestore?.validation ?? null}
                backupFeedback={backupFeedback}
                selectedDate={selectedDate}
                onSelectDate={setSelectedDate}
                onAddWorker={handleAddWorker}
                onEditWorker={handleEditWorker}
                onTransferWorker={handleTransferWorker}
                onRecordAttendance={handleRecordAttendance}
                onRecordPayment={handleRecordPayment}
                onRecordAdvance={handleRecordAdvance}
                onAllocateAdvance={handleAllocateAdvance}
                onVoidPayment={handleVoidPayment}
                onFinalizePeriod={handleFinalizePeriod}
                onReopenPeriod={handleReopenPeriod}
                onSaveExpense={handleSaveExpense}
                onVoidExpense={handleVoidExpense}
                onAddCategory={handleAddCategory}
                onSaveSite={handleSaveSite}
                onArchiveSite={handleArchiveSite}
                onUpdateRoleSiteAssignments={handleUpdateRoleSiteAssignments}
                onCreateFullBackup={handleCreateFullBackup}
                onInspectBackupFile={handleInspectBackupFile}
                onConfirmRestore={handleConfirmRestore}
                onDismissPendingRestore={() => setStagedRestore(null)}
                onClearBackupFeedback={() => setBackupFeedback(null)}
                onResetSampleData={handleResetSampleData}
              />
            </div>

            {/* Right Column: Contextual Test Bench & Matching Compose Source */}
            <div className="space-y-6">
              <section className="rounded-2xl border border-slate-200 bg-white p-6">
                <div className="flex flex-col justify-between gap-4 border-b border-slate-100 pb-5 sm:flex-row sm:items-center">
                  <div>
                    <h1 className="text-xl font-bold tracking-tight text-slate-900">
                      SITE LEDGER — Native Android Preview
                    </h1>
                    <p className="mt-1 text-sm text-slate-600">
                      Kotlin · Jetpack Compose · Material 3 · SQLite v6 Multi-Site, Expenses &amp; Offline ZIP Backups
                    </p>
                  </div>

                  <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => setLanguage('en')}
                      className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                        language === 'en'
                          ? 'bg-white text-blue-800 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      English
                    </button>
                    <button
                      type="button"
                      onClick={() => setLanguage('bn')}
                      className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                        language === 'bn'
                          ? 'bg-white text-blue-800 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      বাংলা
                    </button>
                  </div>
                </div>

                <div className="mt-5">
                  <div className="mb-2.5 text-xs font-semibold text-slate-500">
                    Jump to Android Screen
                  </div>
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {screenJumpItems.map((item) => {
                      const active = destination === item.dest;
                      return (
                        <button
                          key={item.dest}
                          type="button"
                          onClick={() => setDestination(item.dest)}
                          className={`min-h-[42px] rounded-xl border px-3 py-2 text-left text-xs font-semibold transition-colors whitespace-nowrap ${
                            active
                              ? 'border-blue-700 bg-blue-50 text-blue-800'
                              : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          {item.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="mt-5 grid grid-cols-4 gap-3 border-t border-slate-100 pt-5">
                  <div>
                    <div className="text-xs text-slate-500">Sites</div>
                    <div className="mt-0.5 text-lg font-bold text-slate-900 tabular-nums">
                      {sites.length}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">All Workers</div>
                    <div className="mt-0.5 text-lg font-bold text-slate-900 tabular-nums">
                      {workers.length}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">Saved Photos</div>
                    <div className="mt-0.5 text-lg font-bold text-blue-700 tabular-nums">
                      {workersWithPhotosCount}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">Active Site Today</div>
                    <div className="mt-0.5 text-lg font-bold text-emerald-700 tabular-nums">
                      {todayPresentCount}
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 text-xs text-slate-500">
                  <span>
                    Sites, worker transfers, site expenses, receipts, backups &amp; 8-duty payroll
                    persist offline.
                  </span>
                  <button
                    type="button"
                    onClick={handleResetSampleData}
                    className="flex items-center gap-1.5 font-semibold text-blue-700 hover:text-blue-800 whitespace-nowrap"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Reset Sample Data</span>
                  </button>
                </div>
              </section>

              {/* Matching Jetpack Compose Kotlin Source Snippet */}
              {activeKotlinFile && (
                <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
                  <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-5 py-3.5">
                    <div className="flex min-w-0 items-center gap-2">
                      <Code2 className="h-4 w-4 shrink-0 text-blue-700" />
                      <span className="truncate font-mono text-xs font-semibold text-slate-800">
                        {activeKotlinFile.path}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setCodeFocusPath(activeKotlinFile.path);
                        setWorkspaceView('code');
                      }}
                      className="text-xs font-semibold text-blue-700 hover:underline whitespace-nowrap shrink-0"
                    >
                      Open Full Explorer
                    </button>
                  </div>
                  <pre className="thin-scroll max-h-[340px] overflow-auto bg-slate-950 p-4 font-mono text-xs leading-relaxed text-slate-200">
                    <code>{activeKotlinFile.content}</code>
                  </pre>
                </section>
              )}
            </div>
          </div>
        )}

        {workspaceView === 'code' && (
          <CodeExplorerView initialSelectedPath={codeFocusPath} />
        )}

        {workspaceView === 'architecture' && <ArchitectureView />}
      </main>
    </div>
  );
}
