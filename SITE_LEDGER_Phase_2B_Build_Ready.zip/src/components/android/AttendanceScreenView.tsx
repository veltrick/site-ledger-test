import { useMemo, useState } from 'react';
import { Calendar, Check, Info, Lock, Search, X } from 'lucide-react';
import { BilingualUiStrings, DUTY_TYPE_LABELS } from '../../data/bilingualStrings';
import { AVAILABLE_DATES } from '../../data/sampleData';
import {
  AppLanguage,
  DailyAttendanceRecord,
  DutyMultiplierConfig,
  DutyType,
  PayrollPeriodRecord,
  Site,
  UserRole,
  Worker,
} from '../../types/siteLedger';
import {
  calculateDailyEarnedTaka,
  getMultiplierForDuty,
  isPeriodFinalized,
  sumDutyUnits,
} from '../../utils/wageCalculator';
import { WorkerAvatarView } from './WorkerAvatarView';

interface AttendanceScreenViewProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  activeSite: Site;
  selectedDate: string;
  onSelectDate: (dateIso: string) => void;
  workers: Worker[];
  activeRole: UserRole;
  dutyConfig: DutyMultiplierConfig;
  attendanceRecords: DailyAttendanceRecord[];
  payrollPeriods: PayrollPeriodRecord[];
  onRecordAttendance: (input: {
    dateIso: string;
    worker: Worker;
    dutyType: DutyType;
    note: string;
    editReason?: string;
  }) => void;
}

const DUTY_BUTTONS: {
  type: DutyType;
  activeClass: string;
}[] = [
  { type: 'HALF_DUTY', activeClass: 'border-amber-600 bg-amber-600 text-white' },
  { type: 'FULL_DUTY', activeClass: 'border-emerald-700 bg-emerald-700 text-white' },
  { type: 'ONE_AND_HALF_DUTY', activeClass: 'border-teal-700 bg-teal-700 text-white' },
  { type: 'DOUBLE_DUTY', activeClass: 'border-indigo-700 bg-indigo-700 text-white' },
  { type: 'TWO_AND_HALF_DUTY', activeClass: 'border-purple-700 bg-purple-700 text-white' },
  { type: 'TRIPLE_DUTY', activeClass: 'border-blue-700 bg-blue-700 text-white' },
  { type: 'ABSENT', activeClass: 'border-rose-700 bg-rose-700 text-white' },
  { type: 'LEAVE', activeClass: 'border-slate-600 bg-slate-600 text-white' },
];

export function AttendanceScreenView({
  strings,
  language,
  activeSite,
  selectedDate,
  onSelectDate,
  workers,
  activeRole,
  dutyConfig,
  attendanceRecords,
  payrollPeriods,
  onRecordAttendance,
}: AttendanceScreenViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [pendingConfirm, setPendingConfirm] = useState<{
    worker: Worker;
    dutyType: DutyType;
    existing: DailyAttendanceRecord | null;
  } | null>(null);
  const [noteInput, setNoteInput] = useState('');

  const periodLocked = isPeriodFinalized(
    selectedDate.slice(0, 7),
    payrollPeriods,
    activeSite.id
  );
  const canEdit = activeRole !== 'ACCOUNTANT' && !periodLocked;

  const recordsByWorker = useMemo(() => {
    const map = new Map<string, DailyAttendanceRecord>();
    for (const r of attendanceRecords) {
      if (r.dateIso === selectedDate) {
        map.set(r.workerId, r);
      }
    }
    return map;
  }, [attendanceRecords, selectedDate]);

  const dateRecords = useMemo(
    () => attendanceRecords.filter((r) => r.dateIso === selectedDate),
    [attendanceRecords, selectedDate]
  );

  const totalUnits = useMemo(() => sumDutyUnits(dateRecords), [dateRecords]);
  const totalEarned = useMemo(
    () => dateRecords.reduce((sum, r) => sum + r.earnedAmount, 0),
    [dateRecords]
  );

  const filteredWorkers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return workers.filter((w) => {
      if (!w.isActive && !recordsByWorker.has(w.id)) return false;
      if (!q) return true;
      return (
        w.fullNameEn.toLowerCase().includes(q) ||
        w.fullNameBn.toLowerCase().includes(q) ||
        (w.localWorkerCode || w.id).toLowerCase().includes(q) ||
        w.id.toLowerCase().includes(q) ||
        w.phoneNumber.toLowerCase().includes(q)
      );
    });
  }, [workers, searchQuery, recordsByWorker]);

  const openConfirmation = (worker: Worker, dutyType: DutyType) => {
    if (!canEdit) return;
    const existing = recordsByWorker.get(worker.id) ?? null;
    setNoteInput(existing?.note ?? '');
    setPendingConfirm({ worker, dutyType, existing });
  };

  return (
    <div className="space-y-3.5 p-4">
      <div className="flex items-start gap-2.5 rounded-xl border border-blue-200 bg-blue-50/70 px-3 py-2 text-xs text-blue-950">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-blue-700" />
        <span>
          {activeSite.siteCode} · {activeSite.siteName} — {strings.navAttendance}
        </span>
      </div>

      {/* Date Selector */}
      <div>
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
            <Calendar className="h-3.5 w-3.5 text-blue-700" />
            <span>{strings.selectDate}</span>
          </div>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => {
              if (e.target.value) onSelectDate(e.target.value);
            }}
            className="h-8 rounded-lg border border-slate-300 bg-white px-2 text-xs font-semibold text-slate-800 focus:border-blue-600 focus:outline-none"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {AVAILABLE_DATES.map((d) => {
            const active = d.iso === selectedDate;
            return (
              <button
                key={d.iso}
                type="button"
                onClick={() => onSelectDate(d.iso)}
                className={`min-h-[38px] rounded-xl border px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'border-blue-700 bg-blue-700 text-white'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-blue-300'
                }`}
              >
                {language === 'bn' ? d.labelBn : d.labelEn}
              </button>
            );
          })}
        </div>
      </div>

      {periodLocked && (
        <div className="flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2.5 text-xs font-medium text-amber-900">
          <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-700" />
          <span>{strings.payrollLockedWarning}</span>
        </div>
      )}

      {/* Daily Summary */}
      <div className="grid grid-cols-3 gap-2 rounded-2xl border border-slate-200 bg-white p-3 text-center">
        <div>
          <div className="text-[11px] text-slate-500">{strings.navAttendance}</div>
          <div className="mt-0.5 text-base font-bold text-slate-900 tabular-nums">
            {dateRecords.length}/{workers.filter((w) => w.isActive).length}
          </div>
        </div>
        <div className="border-x border-slate-100">
          <div className="text-[11px] text-slate-500">{strings.totalDutyUnits}</div>
          <div className="mt-0.5 text-base font-bold text-blue-700 tabular-nums">
            {totalUnits.toFixed(1)}
          </div>
        </div>
        <div>
          <div className="text-[11px] text-slate-500">{strings.earnedAmountLabel}</div>
          <div className="mt-0.5 text-base font-bold text-emerald-700 tabular-nums">
            ৳{totalEarned.toLocaleString('en-US')}
          </div>
        </div>
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={strings.searchWorkersPlaceholder}
          className="h-10 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
        />
      </div>

      {activeRole === 'ACCOUNTANT' && !periodLocked && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-medium text-amber-900">
          {strings.roleRestrictedAction}
        </div>
      )}

      <div className="space-y-2.5">
        {filteredWorkers.map((worker) => {
          const rec = recordsByWorker.get(worker.id) ?? null;
          const displayName = language === 'bn' ? worker.fullNameBn : worker.fullNameEn;
          const workerCode = worker.localWorkerCode || worker.id;

          return (
            <div
              key={worker.id}
              className="rounded-2xl border border-slate-200 bg-white p-3.5"
            >
              <div className="flex items-center justify-between gap-2.5">
                <div className="flex min-w-0 items-center gap-2.5">
                  <WorkerAvatarView
                    name={displayName}
                    avatarUrl={worker.avatarUrl}
                    sizeClass="h-10 w-10"
                    iconSizeClass="h-4 w-4"
                  />
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold text-slate-900">
                      {displayName}
                    </div>
                    <div className="font-mono text-[11px] text-slate-500">
                      {workerCode} · ৳{worker.dailyWage}
                      {strings.perDaySuffix}
                    </div>
                  </div>
                </div>

                <div className="shrink-0 text-right">
                  {rec ? (
                    <>
                      <div className="text-xs font-bold text-blue-800 tabular-nums">
                        ৳{rec.earnedAmount}
                      </div>
                      <div className="text-[10px] font-semibold text-slate-500 tabular-nums">
                        {rec.multiplierSnapshot}x
                      </div>
                    </>
                  ) : (
                    <span className="text-[11px] font-medium text-slate-400">
                      {strings.notRecordedLabel}
                    </span>
                  )}
                </div>
              </div>

              <div className="mt-2.5 grid grid-cols-4 gap-1.5">
                {DUTY_BUTTONS.map(({ type, activeClass }) => {
                  const selected = rec?.dutyType === type;
                  const meta = DUTY_TYPE_LABELS[type];
                  const mult = getMultiplierForDuty(dutyConfig, type);
                  return (
                    <button
                      key={type}
                      type="button"
                      disabled={!canEdit}
                      onClick={() => openConfirmation(worker, type)}
                      title={language === 'bn' ? meta.bn : meta.en}
                      className={`flex min-h-[42px] flex-col items-center justify-center rounded-xl border px-1 py-1 text-[10px] font-semibold transition-colors disabled:opacity-55 ${
                        selected
                          ? activeClass
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <span className="font-bold">{meta.shortCode}</span>
                      <span className="truncate max-w-full text-[9px] opacity-90">
                        {language === 'bn' ? meta.bn : meta.en}
                      </span>
                      <span className="tabular-nums text-[9px] opacity-80">{mult}x</span>
                    </button>
                  );
                })}
              </div>

              {rec?.note && (
                <div className="mt-2 text-[11px] text-slate-500">
                  {strings.notesLabel}: {rec.note}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {pendingConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                {strings.recordOrEditAttendance}
              </h3>
              <button
                type="button"
                onClick={() => setPendingConfirm(null)}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {(() => {
              const { worker, dutyType, existing } = pendingConfirm;
              const name = language === 'bn' ? worker.fullNameBn : worker.fullNameEn;
              const dutyText =
                language === 'bn'
                  ? DUTY_TYPE_LABELS[dutyType].bn
                  : DUTY_TYPE_LABELS[dutyType].en;
              const wageBase = existing?.dailyWageSnapshot ?? worker.dailyWage;
              const mult = getMultiplierForDuty(dutyConfig, dutyType);
              const earned = calculateDailyEarnedTaka(wageBase, mult);

              return (
                <div className="mt-3 space-y-3">
                  <div className="text-xs text-slate-700">
                    <span className="font-semibold text-slate-900">{name}</span> (
                    {worker.localWorkerCode || worker.id}) · {selectedDate}
                  </div>

                  <div className="grid grid-cols-2 gap-1.5">
                    {DUTY_BUTTONS.map(({ type }) => {
                      const optMeta = DUTY_TYPE_LABELS[type];
                      const optMult = getMultiplierForDuty(dutyConfig, type);
                      const activeOpt = dutyType === type;
                      return (
                        <button
                          key={type}
                          type="button"
                          onClick={() =>
                            setPendingConfirm({
                              worker,
                              dutyType: type,
                              existing,
                            })
                          }
                          className={`flex min-h-[34px] items-center justify-between rounded-xl border px-2 py-1 text-[11px] font-semibold transition-colors ${
                            activeOpt
                              ? 'border-blue-700 bg-blue-700 text-white'
                              : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <span className="truncate">
                            {language === 'bn' ? optMeta.bn : optMeta.en}
                          </span>
                          <span className="ml-1 shrink-0 font-mono text-[10px]">{optMult}x</span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="space-y-1 rounded-xl border border-blue-100 bg-blue-50/70 p-3 text-xs">
                    <div className="flex justify-between gap-2 text-slate-700">
                      <span>{strings.dutyTypeLabel}</span>
                      <span className="font-semibold text-blue-950">{dutyText}</span>
                    </div>
                    <div className="flex justify-between gap-2 text-slate-700 tabular-nums">
                      <span>{strings.dutyMultiplierLabel}</span>
                      <span className="font-semibold text-blue-950">{mult}x</span>
                    </div>
                    <div className="flex justify-between gap-2 text-slate-700 tabular-nums">
                      <span>{strings.savedDailyWageLabel}</span>
                      <span className="font-semibold text-slate-900">৳{wageBase}</span>
                    </div>
                    <div className="flex justify-between gap-2 border-t border-blue-200 pt-1.5 font-bold text-blue-800 tabular-nums">
                      <span>{strings.earnedAmountLabel}</span>
                      <span>
                        ৳{wageBase} × {mult} = ৳{earned}
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600">
                      {strings.notesLabel}
                    </label>
                    <input
                      type="text"
                      value={noteInput}
                      onChange={(e) => setNoteInput(e.target.value)}
                      placeholder="Optional site note..."
                      className="mt-1 h-10 w-full rounded-xl border border-slate-300 px-3 text-sm focus:border-blue-600 focus:outline-none"
                    />
                  </div>

                  {existing && (
                    <div className="rounded-xl border border-amber-200 bg-amber-50 p-2.5 text-xs text-amber-900">
                      {strings.confirmEditAttendanceMsg}
                    </div>
                  )}

                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setPendingConfirm(null)}
                      className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                    >
                      {strings.cancel}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onRecordAttendance({
                          dateIso: selectedDate,
                          worker,
                          dutyType,
                          note: noteInput.trim(),
                          editReason: existing ? 'Updated from Attendance screen' : 'Initial',
                        });
                        setPendingConfirm(null);
                      }}
                      className="flex min-h-[38px] items-center gap-1 rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800"
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>{strings.confirmAction}</span>
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}
