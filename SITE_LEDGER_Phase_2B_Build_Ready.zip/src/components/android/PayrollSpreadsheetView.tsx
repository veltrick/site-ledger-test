import { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Lock,
  LockOpen,
  Printer,
  Search,
} from 'lucide-react';
import {
  BilingualUiStrings,
  PAYROLL_STATUS_LABELS,
  WORK_CATEGORY_LABELS,
} from '../../data/bilingualStrings';
import {
  AppLanguage,
  DailyAttendanceRecord,
  PaymentAllocation,
  PayrollPeriodRecord,
  Site,
  UserRole,
  WorkCategory,
  Worker,
  WorkerMonthlySummary,
} from '../../types/siteLedger';
import {
  buildAllWorkersPayrollPdfBytes,
  buildPrintableAttendanceHtml,
  buildSpreadsheetExcelXml,
  triggerBlobDownload,
} from '../../utils/payrollExport';
import {
  computeSpreadsheetRows,
  computeSpreadsheetTotals,
  formatPeriodIso,
  isPeriodFinalized,
} from '../../utils/wageCalculator';
import { WorkerAvatarView } from './WorkerAvatarView';

type SpreadsheetSort = 'NAME' | 'ID' | 'EARNINGS' | 'PAID' | 'OUTSTANDING';

interface PayrollSpreadsheetViewProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  activeRole: UserRole;
  activeSite: Site;
  sites: Site[];
  allowedSiteIds: Set<string>;
  workers: Worker[];
  attendanceRecords: DailyAttendanceRecord[];
  allocations: PaymentAllocation[];
  payrollPeriods: PayrollPeriodRecord[];
  onWorkerClick: (workerId: string) => void;
  onFinalizePeriod: (periodIso: string, reason: string) => void;
  onReopenPeriod: (periodIso: string, reason: string) => void;
}

const PAGE_SIZE = 50;

export function PayrollSpreadsheetView({
  strings,
  language,
  activeRole,
  activeSite,
  sites,
  allowedSiteIds,
  workers,
  attendanceRecords,
  allocations,
  payrollPeriods,
  onWorkerClick,
  onFinalizePeriod,
  onReopenPeriod,
}: PayrollSpreadsheetViewProps) {
  const [selectedYear, setSelectedYear] = useState(2026);
  const [selectedMonth, setSelectedMonth] = useState(11);
  const [allSitesMode, setAllSitesMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | WorkCategory>('ALL');
  const [sortOption, setSortOption] = useState<SpreadsheetSort>('NAME');
  const [page, setPage] = useState(1);
  const [showLockModal, setShowLockModal] = useState(false);
  const [lockReason, setLockReason] = useState('');
  const [exportNotice, setExportNotice] = useState<string | null>(null);
  const [printPreviewHtml, setPrintPreviewHtml] = useState<string | null>(null);

  const periodIso = formatPeriodIso(selectedYear, selectedMonth);
  const periodLocked = isPeriodFinalized(periodIso, payrollPeriods, activeSite.id);
  const siteHeaderLabel = allSitesMode ? strings.allSitesToggleLabel : activeSite.siteName;

  const allRows: WorkerMonthlySummary[] = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const rawRows = computeSpreadsheetRows({
      year: selectedYear,
      month: selectedMonth,
      selectedSiteId: activeSite.id,
      allSitesMode,
      sites,
      workers,
      allAttendance: attendanceRecords,
      allAllocations: allocations,
      periodRecords: payrollPeriods,
      allowedSiteIds,
    });

    const filtered = rawRows.filter((row) => {
      if (categoryFilter !== 'ALL' && row.worker.category !== categoryFilter) return false;
      if (!q) return true;
      return (
        row.worker.fullNameEn.toLowerCase().includes(q) ||
        row.worker.fullNameBn.toLowerCase().includes(q) ||
        (row.worker.localWorkerCode || row.worker.id).toLowerCase().includes(q) ||
        row.siteName.toLowerCase().includes(q)
      );
    });

    return [...filtered].sort((a, b) => {
      switch (sortOption) {
        case 'ID':
          return (a.worker.localWorkerCode || a.worker.id).localeCompare(
            b.worker.localWorkerCode || b.worker.id
          );
        case 'EARNINGS':
          return b.totalEarnedAmount - a.totalEarnedAmount;
        case 'PAID':
          return b.totalPaidAmount - a.totalPaidAmount;
        case 'OUTSTANDING':
          return b.outstandingBalance - a.outstandingBalance;
        default: {
          const nameA = language === 'bn' ? a.worker.fullNameBn : a.worker.fullNameEn;
          const nameB = language === 'bn' ? b.worker.fullNameBn : b.worker.fullNameEn;
          return nameA.localeCompare(nameB);
        }
      }
    });
  }, [
    workers,
    sites,
    allowedSiteIds,
    activeSite.id,
    allSitesMode,
    selectedYear,
    selectedMonth,
    searchQuery,
    categoryFilter,
    sortOption,
    attendanceRecords,
    allocations,
    payrollPeriods,
    language,
  ]);

  const totals = useMemo(() => computeSpreadsheetTotals(allRows), [allRows]);
  const totalPages = Math.max(1, Math.ceil(allRows.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const visibleRows = useMemo(
    () => allRows.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE),
    [allRows, safePage]
  );

  const handleExportExcel = () => {
    const scopeSlug = allSitesMode ? 'all_sites' : activeSite.siteCode;
    const filename = `site_ledger_payroll_${scopeSlug}_${periodIso}.xls`;
    const xml = buildSpreadsheetExcelXml(
      language,
      periodIso,
      allRows,
      totals,
      siteHeaderLabel,
      allSitesMode
    );
    triggerBlobDownload(filename, xml, 'application/vnd.ms-excel');
    setExportNotice(`${strings.exportSuccessNotice} ${filename}`);
  };

  const handleExportPdf = () => {
    const scopeSlug = allSitesMode ? 'all_sites' : activeSite.siteCode;
    const filename = `site_ledger_payroll_${scopeSlug}_${periodIso}.pdf`;
    const bytes = buildAllWorkersPayrollPdfBytes(
      periodIso,
      allRows,
      totals,
      siteHeaderLabel,
      allSitesMode
    );
    triggerBlobDownload(filename, bytes, 'application/pdf');
    setExportNotice(`${strings.exportSuccessNotice} ${filename}`);
  };

  const handlePrintSheet = () => {
    const html = buildPrintableAttendanceHtml(
      language,
      periodIso,
      allRows,
      totals,
      siteHeaderLabel,
      allSitesMode
    );
    setPrintPreviewHtml(html);
  };

  return (
    <div className="space-y-3 p-3.5">
      {/* Title & Period Lock Action */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-bold tracking-tight text-slate-900">
            {strings.payrollSpreadsheetTitle}
          </h2>
          <div className="mt-0.5 flex items-center gap-1.5 text-[11px] font-semibold">
            <span className="font-mono text-slate-700">
              {allSitesMode ? strings.allSitesToggleLabel : activeSite.siteCode} · {periodIso}
            </span>
            <span aria-hidden="true">·</span>
            <span className={periodLocked ? 'text-amber-700' : 'text-emerald-700'}>
              {periodLocked ? strings.payrollFinalizedBadge : strings.payrollOpenBadge}
            </span>
          </div>
        </div>

        {activeRole === 'ADMIN' && !allSitesMode && (
          <button
            type="button"
            onClick={() => {
              setLockReason('');
              setShowLockModal(true);
            }}
            className={`flex min-h-[36px] items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[11px] font-semibold transition-colors ${
              periodLocked
                ? 'border-amber-300 bg-amber-50 text-amber-900 hover:bg-amber-100'
                : 'border-blue-300 bg-blue-50 text-blue-800 hover:bg-blue-100'
            }`}
          >
            {periodLocked ? (
              <LockOpen className="h-3.5 w-3.5" />
            ) : (
              <Lock className="h-3.5 w-3.5" />
            )}
            <span>
              {periodLocked ? strings.reopenPayrollBtn : strings.finalizePayrollBtn}
            </span>
          </button>
        )}
      </div>

      {/* Active Site vs All Sites Consolidated Toggle */}
      <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-200/70 p-1">
        <button
          type="button"
          onClick={() => {
            setAllSitesMode(false);
            setPage(1);
          }}
          className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors ${
            !allSitesMode
              ? 'bg-white text-blue-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          {strings.activeSiteToggleLabel} ({activeSite.siteCode})
        </button>
        <button
          type="button"
          onClick={() => {
            setAllSitesMode(true);
            setPage(1);
          }}
          className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors ${
            allSitesMode
              ? 'bg-white text-blue-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          {strings.allSitesToggleLabel} ({sites.filter((s) => allowedSiteIds.has(s.id)).length})
        </button>
      </div>

      {/* Filters: Year, Month, Category, Sort */}
      <div className="space-y-2 rounded-2xl border border-slate-200 bg-white p-3">
        <div className="grid grid-cols-3 gap-2">
          <select
            value={selectedYear}
            onChange={(e) => {
              setSelectedYear(Number(e.target.value));
              setPage(1);
            }}
            aria-label={strings.selectYear}
            className="h-9 rounded-lg border border-slate-300 bg-white px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
          >
            {[2025, 2026].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>

          <select
            value={selectedMonth}
            onChange={(e) => {
              setSelectedMonth(Number(e.target.value));
              setPage(1);
            }}
            aria-label={strings.selectMonth}
            className="h-9 rounded-lg border border-slate-300 bg-white px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
          >
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((m) => (
              <option key={m} value={m}>
                {String(m).padStart(2, '0')}
              </option>
            ))}
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value as 'ALL' | WorkCategory);
              setPage(1);
            }}
            aria-label={strings.categoryLabel}
            className="h-9 rounded-lg border border-slate-300 bg-white px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
          >
            <option value="ALL">{strings.allFilter}</option>
            {(Object.keys(WORK_CATEGORY_LABELS) as WorkCategory[]).map((cat) => (
              <option key={cat} value={cat}>
                {language === 'bn'
                  ? WORK_CATEGORY_LABELS[cat].bn
                  : WORK_CATEGORY_LABELS[cat].en}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setPage(1);
              }}
              placeholder={strings.searchWorkersPlaceholder}
              className="h-9 w-full rounded-lg border border-slate-300 bg-white pl-8 pr-2 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
            />
          </div>

          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value as SpreadsheetSort)}
            aria-label={strings.sortLabel}
            className="h-9 rounded-lg border border-slate-300 bg-white px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
          >
            <option value="NAME">{strings.sortByName}</option>
            <option value="ID">{strings.sortById}</option>
            <option value="EARNINGS">{strings.sortByEarnings}</option>
            <option value="PAID">{strings.sortByPaid}</option>
            <option value="OUTSTANDING">{strings.sortByOutstanding}</option>
          </select>
        </div>

        {/* Offline Export Bar */}
        <div className="flex flex-wrap items-center gap-1.5 border-t border-slate-100 pt-2">
          <button
            type="button"
            onClick={handleExportExcel}
            className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[11px] font-semibold text-slate-800 hover:bg-slate-100"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-700" />
            <span>{strings.exportExcelBtn}</span>
          </button>
          <button
            type="button"
            onClick={handleExportPdf}
            className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[11px] font-semibold text-slate-800 hover:bg-slate-100"
          >
            <Download className="h-3.5 w-3.5 text-blue-700" />
            <span>{strings.exportAllPdfBtn}</span>
          </button>
          <button
            type="button"
            onClick={handlePrintSheet}
            className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[11px] font-semibold text-slate-800 hover:bg-slate-100"
          >
            <Printer className="h-3.5 w-3.5 text-slate-700" />
            <span>{strings.printAttendanceBtn}</span>
          </button>
        </div>

        {exportNotice && (
          <div className="flex items-center gap-1.5 text-[11px] font-medium text-emerald-700">
            <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
            <span>{exportNotice}</span>
          </div>
        )}
      </div>

      {/* Horizontally Scrollable Data Grid with Frozen Worker Photo/ID/Name + Site column */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
        <div className="thin-scroll overflow-x-auto">
          <table className="min-w-[1000px] w-full border-collapse text-left text-[11px]">
            <thead>
              <tr className="border-b border-slate-200 bg-blue-50/80 text-slate-800">
                <th className="sticky left-0 z-20 w-[160px] min-w-[160px] border-r border-slate-200 bg-blue-50 px-2.5 py-2.5 font-bold">
                  {strings.workerIdLabel} / {strings.fullNameLabel}
                </th>
                {allSitesMode && (
                  <th className="px-2 py-2.5 font-bold text-blue-900">
                    {strings.siteColumnLabel}
                  </th>
                )}
                <th className="px-2 py-2.5 font-bold">{strings.categoryLabel}</th>
                <th className="px-2 py-2.5 text-right font-bold text-amber-800">H</th>
                <th className="px-2 py-2.5 text-right font-bold text-emerald-800">F</th>
                <th className="px-2 py-2.5 text-right font-bold text-teal-800">1.5</th>
                <th className="px-2 py-2.5 text-right font-bold text-indigo-800">D</th>
                <th className="px-2 py-2.5 text-right font-bold text-purple-800">2.5</th>
                <th className="px-2 py-2.5 text-right font-bold text-blue-800">T</th>
                <th className="px-2 py-2.5 text-right font-bold text-rose-800">A</th>
                <th className="px-2 py-2.5 text-right font-bold text-slate-700">L</th>
                <th className="px-2 py-2.5 text-right font-bold">{strings.dutyUnitsLabel}</th>
                <th className="px-2 py-2.5 text-right font-bold">{strings.totalEarnedAmount}</th>
                <th className="px-2 py-2.5 text-right font-bold">{strings.totalPaidAmount}</th>
                <th className="px-2 py-2.5 text-right font-bold">{strings.remainingBalance}</th>
                <th className="px-2 py-2.5 font-bold">{strings.payrollStatusLabel}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {visibleRows.length === 0 ? (
                <tr>
                  <td
                    colSpan={allSitesMode ? 16 : 15}
                    className="px-4 py-6 text-center text-xs text-slate-500"
                  >
                    {strings.noWorkersFound}
                  </td>
                </tr>
              ) : (
                visibleRows.map((row) => {
                  const name =
                    language === 'bn' ? row.worker.fullNameBn : row.worker.fullNameEn;
                  const cat =
                    language === 'bn'
                      ? WORK_CATEGORY_LABELS[row.worker.category].bn
                      : WORK_CATEGORY_LABELS[row.worker.category].en;
                  const statusLabel =
                    language === 'bn'
                      ? PAYROLL_STATUS_LABELS[row.payrollStatus].bn
                      : PAYROLL_STATUS_LABELS[row.payrollStatus].en;

                  return (
                    <tr key={`${row.siteId}_${row.worker.id}`} className="hover:bg-slate-50/80">
                      <td className="sticky left-0 z-10 w-[160px] min-w-[160px] border-r border-slate-100 bg-white px-2.5 py-2">
                        <button
                          type="button"
                          onClick={() => onWorkerClick(row.worker.id)}
                          className="flex w-full items-center gap-2 text-left group"
                        >
                          <WorkerAvatarView
                            name={name}
                            avatarUrl={row.worker.avatarUrl}
                            sizeClass="h-7 w-7"
                            iconSizeClass="h-3.5 w-3.5"
                          />
                          <div className="min-w-0 flex-1">
                            <div className="font-mono text-[10px] text-slate-500">
                              {row.worker.localWorkerCode || row.worker.id}
                            </div>
                            <div className="truncate font-semibold text-blue-800 group-hover:underline">
                              {name}
                            </div>
                          </div>
                        </button>
                      </td>
                      {allSitesMode && (
                        <td className="px-2 py-2 font-medium text-blue-800 whitespace-nowrap">
                          {row.siteName || row.siteId}
                        </td>
                      )}
                      <td className="px-2 py-2 text-slate-600 whitespace-nowrap">{cat}</td>
                      <td className="px-2 py-2 text-right font-semibold text-amber-700 tabular-nums">
                        {row.halfDutyCount}
                      </td>
                      <td className="px-2 py-2 text-right font-semibold text-emerald-700 tabular-nums">
                        {row.fullDutyCount}
                      </td>
                      <td className="px-2 py-2 text-right font-semibold text-teal-700 tabular-nums">
                        {row.oneAndHalfDutyCount}
                      </td>
                      <td className="px-2 py-2 text-right font-semibold text-indigo-700 tabular-nums">
                        {row.doubleDutyCount}
                      </td>
                      <td className="px-2 py-2 text-right font-semibold text-purple-700 tabular-nums">
                        {row.twoAndHalfDutyCount}
                      </td>
                      <td className="px-2 py-2 text-right font-semibold text-blue-700 tabular-nums">
                        {row.tripleDutyCount}
                      </td>
                      <td className="px-2 py-2 text-right font-semibold text-rose-700 tabular-nums">
                        {row.absentCount}
                      </td>
                      <td className="px-2 py-2 text-right text-slate-600 tabular-nums">
                        {row.leaveCount}
                      </td>
                      <td className="px-2 py-2 text-right font-bold text-slate-900 tabular-nums">
                        {row.totalDutyUnits.toFixed(1)}
                      </td>
                      <td className="px-2 py-2 text-right font-semibold text-slate-900 tabular-nums">
                        ৳{row.totalEarnedAmount.toLocaleString('en-US')}
                      </td>
                      <td className="px-2 py-2 text-right font-semibold text-emerald-700 tabular-nums">
                        ৳{row.totalPaidAmount.toLocaleString('en-US')}
                      </td>
                      <td
                        className={`px-2 py-2 text-right font-bold tabular-nums ${
                          row.outstandingBalance < 0
                            ? 'text-rose-700'
                            : row.outstandingBalance > 0
                              ? 'text-blue-800'
                              : 'text-emerald-700'
                        }`}
                      >
                        ৳{row.outstandingBalance.toLocaleString('en-US')}
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap text-slate-700">
                        {statusLabel}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-blue-700 bg-slate-100 font-bold text-slate-900">
                <td className="sticky left-0 z-10 w-[160px] min-w-[160px] border-r border-slate-200 bg-slate-100 px-2.5 py-2.5 text-blue-900">
                  {strings.totalsRowLabel} ({totals.totalWorkers})
                </td>
                <td className="px-2 py-2.5" colSpan={allSitesMode ? 10 : 9} />
                <td className="px-2 py-2.5 text-right text-blue-900 tabular-nums">
                  {totals.totalDutyUnits.toFixed(1)}
                </td>
                <td className="px-2 py-2.5 text-right tabular-nums">
                  ৳{totals.totalEarnedSalary.toLocaleString('en-US')}
                </td>
                <td className="px-2 py-2.5 text-right text-emerald-800 tabular-nums">
                  ৳{totals.totalPaidSalary.toLocaleString('en-US')}
                </td>
                <td className="px-2 py-2.5 text-right text-blue-900 tabular-nums">
                  ৳{totals.totalOutstandingSalary.toLocaleString('en-US')}
                </td>
                <td className="px-2 py-2.5" />
              </tr>
            </tfoot>
          </table>
        </div>

        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-3 py-2 text-xs">
            <span className="text-slate-600 tabular-nums">
              Page {safePage} / {totalPages} ({allRows.length})
            </span>
            <div className="flex gap-1.5">
              <button
                type="button"
                disabled={safePage <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="rounded-lg border border-slate-300 bg-white px-2.5 py-1 font-semibold disabled:opacity-40"
              >
                Prev
              </button>
              <button
                type="button"
                disabled={safePage >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="rounded-lg border border-slate-300 bg-white px-2.5 py-1 font-semibold disabled:opacity-40"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Finalize / Reopen Payroll Modal */}
      {showLockModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <h3 className="text-sm font-bold text-slate-900">
              {periodLocked ? strings.reopenPayrollBtn : strings.finalizePayrollBtn} ·{' '}
              {activeSite.siteCode} · {periodIso}
            </h3>
            <p className="mt-2 text-xs leading-relaxed text-slate-600">
              {periodLocked ? strings.confirmReopenMsg : strings.confirmFinalizeMsg}
            </p>
            <input
              type="text"
              value={lockReason}
              onChange={(e) => setLockReason(e.target.value)}
              placeholder="Audit reason..."
              className="mt-3 h-9 w-full rounded-xl border border-slate-300 px-3 text-xs focus:border-blue-600 focus:outline-none"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowLockModal(false)}
                className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                {strings.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  if (periodLocked) {
                    onReopenPeriod(periodIso, lockReason.trim() || 'Reopened by Admin');
                  } else {
                    onFinalizePeriod(periodIso, lockReason.trim() || 'Finalized by Admin');
                  }
                  setShowLockModal(false);
                }}
                className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              >
                {strings.confirmAction}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Printable Attendance Sheet Preview Modal */}
      {printPreviewHtml && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="flex max-h-[85vh] w-full max-w-md flex-col rounded-2xl border border-slate-200 bg-white p-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h3 className="text-sm font-bold text-slate-900">
                {strings.printAttendanceBtn} ({periodIso})
              </h3>
              <button
                type="button"
                onClick={() => setPrintPreviewHtml(null)}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800"
              >
                {strings.close}
              </button>
            </div>
            <iframe
              title="Printable Attendance Preview"
              srcDoc={printPreviewHtml}
              className="mt-3 h-72 w-full rounded-xl border border-slate-200 bg-white"
            />
            <div className="mt-3 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  const filename = `site_ledger_attendance_${periodIso}.html`;
                  triggerBlobDownload(filename, printPreviewHtml, 'text/html');
                  setExportNotice(`${strings.exportSuccessNotice} ${filename}`);
                  setPrintPreviewHtml(null);
                }}
                className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              >
                Download Print Sheet (.html)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
