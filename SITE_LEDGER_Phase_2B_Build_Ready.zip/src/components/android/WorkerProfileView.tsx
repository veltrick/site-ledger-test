import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRightLeft,
  Check,
  Download,
  Edit3,
  Lock,
  Plus,
  X,
} from 'lucide-react';
import {
  BilingualUiStrings,
  DUTY_TYPE_LABELS,
  PAYROLL_STATUS_LABELS,
  PERIOD_LOCK_LABELS,
  USER_ROLE_LABELS,
  WORK_CATEGORY_LABELS,
} from '../../data/bilingualStrings';
import {
  AdvanceRecord,
  AppLanguage,
  AttendanceAuditEntry,
  DailyAttendanceRecord,
  DutyMultiplierConfig,
  DutyType,
  PaymentAllocation,
  PaymentAuditEntry,
  PaymentLedgerEntry,
  PayrollPeriodRecord,
  Site,
  UserRole,
  Worker,
  WorkerMonthlySummary,
  WorkerSiteHistory,
} from '../../types/siteLedger';
import { buildIndividualWorkerPdfBytes, triggerBlobDownload } from '../../utils/payrollExport';
import {
  calculateDailyEarnedTaka,
  collectWorkerPayrollPeriods,
  computeAdvanceRemaining,
  computeCurrentMonthProjection,
  computeUnallocatedAdvanceBalance,
  computeWorkerMonthlySummary,
  computeWorkerOverallBalances,
  daysInMonth,
  formatPeriodIso,
  getMultiplierForDuty,
  isLocalWorkerCodeDuplicate,
  isPeriodFinalized,
} from '../../utils/wageCalculator';
import { WorkerAvatarView } from './WorkerAvatarView';

interface WorkerProfileViewProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  worker: Worker;
  allSites: Site[];
  allWorkersAcrossSites: Worker[];
  workerTransfers: WorkerSiteHistory[];
  activeRole: UserRole;
  dutyConfig: DutyMultiplierConfig;
  allAttendance: DailyAttendanceRecord[];
  attendanceAudits: AttendanceAuditEntry[];
  allPayments: PaymentLedgerEntry[];
  advances: AdvanceRecord[];
  allocations: PaymentAllocation[];
  paymentAudits: PaymentAuditEntry[];
  payrollPeriods: PayrollPeriodRecord[];
  onBack: () => void;
  onEditWorkerClick: () => void;
  onTransferWorker: (input: {
    workerId: string;
    toSiteId: string;
    newLocalCode: string;
    transferDateIso: string;
    note: string;
  }) => void;
  onRecordAttendance: (input: {
    dateIso: string;
    worker: Worker;
    dutyType: DutyType;
    note: string;
    editReason?: string;
  }) => void;
  onRecordPayment: (input: {
    workerId: string;
    dateIso: string;
    applicablePeriod: string;
    paidAmount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => void;
  onRecordAdvance: (input: {
    workerId: string;
    advanceDateIso: string;
    amount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => void;
  onAllocateAdvance: (input: {
    advanceId: string;
    targetPeriod: string;
    amountToAllocate: number;
    note: string;
  }) => void;
  onVoidPayment: (transactionId: string, reason: string) => void;
}

type ProfileTab = 'overview' | 'attendance' | 'payroll' | 'payments' | 'personal';

const DUTY_ORDER: DutyType[] = [
  'HALF_DUTY',
  'FULL_DUTY',
  'ONE_AND_HALF_DUTY',
  'DOUBLE_DUTY',
  'TWO_AND_HALF_DUTY',
  'TRIPLE_DUTY',
  'ABSENT',
  'LEAVE',
];

export function WorkerProfileView({
  strings,
  language,
  worker,
  allSites,
  allWorkersAcrossSites,
  workerTransfers,
  activeRole,
  dutyConfig,
  allAttendance,
  attendanceAudits,
  allPayments,
  advances,
  allocations,
  paymentAudits,
  payrollPeriods,
  onBack,
  onEditWorkerClick,
  onTransferWorker,
  onRecordAttendance,
  onRecordPayment,
  onRecordAdvance,
  onAllocateAdvance,
  onVoidPayment,
}: WorkerProfileViewProps) {
  const [activeTab, setActiveTab] = useState<ProfileTab>('overview');
  const [selectedYear, setSelectedYear] = useState(2026);
  const [selectedMonth, setSelectedMonth] = useState(11);
  const [selectedCalendarDate, setSelectedCalendarDate] = useState('2026-11-15');
  const [historyYearFilter, setHistoryYearFilter] = useState<'ALL' | number>('ALL');
  const [breakdownModalSummary, setBreakdownModalSummary] =
    useState<WorkerMonthlySummary | null>(null);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  const [showAttendanceModal, setShowAttendanceModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showAdvanceModal, setShowAdvanceModal] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [allocateTarget, setAllocateTarget] = useState<AdvanceRecord | null>(null);
  const [voidTarget, setVoidTarget] = useState<PaymentLedgerEntry | null>(null);

  const sitesById = useMemo(
    () => Object.fromEntries(allSites.map((s) => [s.id, s])),
    [allSites]
  );
  const currentSite = sitesById[worker.siteId];
  const displayName = language === 'bn' ? worker.fullNameBn : worker.fullNameEn;
  const categoryLabel =
    language === 'bn'
      ? WORK_CATEGORY_LABELS[worker.category].bn
      : WORK_CATEGORY_LABELS[worker.category].en;

  const canEditWorkers = activeRole !== 'ACCOUNTANT';
  const canTransfer = activeRole === 'ADMIN' && allSites.some((s) => s.id !== worker.siteId && s.status !== 'ARCHIVED');
  const canEditAttendance = activeRole !== 'ACCOUNTANT';
  const canEditPayments = activeRole !== 'MANAGER';

  const selectedPeriodIso = formatPeriodIso(selectedYear, selectedMonth);
  const selectedPeriodFinalized = isPeriodFinalized(
    selectedPeriodIso,
    payrollPeriods,
    worker.siteId
  );

  // Aggregate across all sites where the worker has recorded duty/payments (siteIdFilter = null)
  const monthlySummary = useMemo(
    () =>
      computeWorkerMonthlySummary(
        worker,
        selectedYear,
        selectedMonth,
        allAttendance,
        allocations,
        payrollPeriods,
        null,
        sitesById
      ),
    [worker, selectedYear, selectedMonth, allAttendance, allocations, payrollPeriods, sitesById]
  );

  const currentMonthSummary = useMemo(
    () =>
      computeWorkerMonthlySummary(
        worker,
        2026,
        11,
        allAttendance,
        allocations,
        payrollPeriods,
        null,
        sitesById
      ),
    [worker, allAttendance, allocations, payrollPeriods, sitesById]
  );

  const currentProjection = useMemo(
    () => computeCurrentMonthProjection(currentMonthSummary, 15),
    [currentMonthSummary]
  );

  const chronologicalHistory = useMemo(() => {
    const periods = collectWorkerPayrollPeriods(
      worker.id,
      allAttendance,
      allocations,
      allPayments
    ).filter((p) => historyYearFilter === 'ALL' || p.year === historyYearFilter);
    return periods.map((p) =>
      computeWorkerMonthlySummary(
        worker,
        p.year,
        p.month,
        allAttendance,
        allocations,
        payrollPeriods,
        null,
        sitesById
      )
    );
  }, [
    worker,
    allAttendance,
    allocations,
    allPayments,
    payrollPeriods,
    historyYearFilter,
    sitesById,
  ]);

  const overallBalances = useMemo(
    () => computeWorkerOverallBalances(worker.id, allAttendance, allocations, null),
    [worker.id, allAttendance, allocations]
  );

  const unallocatedAdvanceTotal = useMemo(
    () => computeUnallocatedAdvanceBalance(worker.id, advances, allocations, null),
    [worker.id, advances, allocations]
  );

  const workerAttendanceMap = useMemo(() => {
    const map = new Map<string, DailyAttendanceRecord>();
    for (const r of allAttendance) {
      if (r.workerId === worker.id) map.set(r.dateIso, r);
    }
    return map;
  }, [worker.id, allAttendance]);

  const workerAttendanceAudits = useMemo(
    () => attendanceAudits.filter((a) => a.workerId === worker.id),
    [attendanceAudits, worker.id]
  );

  const workerPayments = useMemo(
    () => allPayments.filter((p) => p.workerId === worker.id),
    [allPayments, worker.id]
  );

  const workerAdvances = useMemo(
    () => advances.filter((a) => a.workerId === worker.id),
    [advances, worker.id]
  );

  const workerPaymentAudits = useMemo(
    () => paymentAudits.filter((pa) => pa.workerId === worker.id),
    [paymentAudits, worker.id]
  );

  const transfersForWorker = useMemo(
    () => workerTransfers.filter((t) => t.workerId === worker.id),
    [workerTransfers, worker.id]
  );

  const totalCalendarDays = daysInMonth(selectedYear, selectedMonth);
  const calendarDays = Array.from({ length: totalCalendarDays }, (_, i) => i + 1);
  const selectedDayRecord = workerAttendanceMap.get(selectedCalendarDate) ?? null;
  const selectedDayLocked = isPeriodFinalized(
    selectedCalendarDate.slice(0, 7),
    payrollPeriods,
    selectedDayRecord?.siteId ?? worker.siteId
  );

  const tabs: { id: ProfileTab; label: string }[] = [
    { id: 'overview', label: strings.profileTabOverview },
    { id: 'attendance', label: strings.profileTabAttendance },
    { id: 'payroll', label: strings.profileTabPayrollHistory },
    { id: 'payments', label: strings.profileTabPayments },
    { id: 'personal', label: strings.profileTabPersonal },
  ];

  const handleMonthSelect = (m: number) => {
    setSelectedMonth(m);
    setSelectedCalendarDate(`${selectedYear}-${String(m).padStart(2, '0')}-01`);
  };

  const handleYearSelect = (y: number) => {
    setSelectedYear(y);
    setSelectedCalendarDate(`${y}-${String(selectedMonth).padStart(2, '0')}-01`);
  };

  const getCalendarCellColors = (dutyType: DutyType | undefined, isSelected: boolean) => {
    const ring = isSelected ? 'ring-2 ring-blue-700 border-blue-700' : 'border-slate-200';
    switch (dutyType) {
      case 'HALF_DUTY':
        return `bg-amber-100 text-amber-900 ${ring}`;
      case 'FULL_DUTY':
        return `bg-emerald-100 text-emerald-900 ${ring}`;
      case 'ONE_AND_HALF_DUTY':
        return `bg-teal-100 text-teal-900 ${ring}`;
      case 'DOUBLE_DUTY':
        return `bg-indigo-100 text-indigo-900 ${ring}`;
      case 'TWO_AND_HALF_DUTY':
        return `bg-purple-100 text-purple-900 ${ring}`;
      case 'TRIPLE_DUTY':
        return `bg-blue-100 text-blue-900 ${ring}`;
      case 'ABSENT':
        return `bg-rose-100 text-rose-900 ${ring}`;
      case 'LEAVE':
        return `bg-slate-200 text-slate-700 ${ring}`;
      default:
        return `bg-slate-50 text-slate-500 ${ring}`;
    }
  };

  const handleExportWorkerPdf = (summary: WorkerMonthlySummary) => {
    const dayRecords = allAttendance.filter(
      (r) => r.workerId === worker.id && r.dateIso.startsWith(`${summary.periodIso}-`)
    );
    const bytes = buildIndividualWorkerPdfBytes(summary, dayRecords);
    const filename = `worker_${worker.localWorkerCode || worker.id}_${summary.periodIso}.pdf`;
    triggerBlobDownload(filename, bytes, 'application/pdf');
    setExportNotice(`${strings.exportSuccessNotice} ${filename}`);
  };

  return (
    <div className="space-y-3.5 p-4">
      {/* Header Card */}
      <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onBack}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100"
            aria-label={strings.close}
          >
            <ArrowLeft className="h-4 w-4" />
          </button>

          <WorkerAvatarView
            name={displayName}
            avatarUrl={worker.avatarUrl}
            sizeClass="h-12 w-12"
            iconSizeClass="h-5 w-5"
          />

          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-bold text-slate-900">{displayName}</div>
            <div className="mt-0.5 truncate text-xs text-slate-500">
              <span className="font-mono font-semibold text-slate-700">
                {worker.localWorkerCode || worker.id}
              </span>
              <span aria-hidden="true"> · </span>
              <span>{categoryLabel}</span>
              <span aria-hidden="true"> · </span>
              <span className="tabular-nums">
                ৳{worker.dailyWage}
                {strings.perDaySuffix}
              </span>
            </div>
            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs">
              <span className="font-semibold text-blue-800">
                {currentSite?.siteCode ?? worker.siteId}
              </span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-600">{worker.phoneNumber || '-'}</span>
              <span aria-hidden="true">·</span>
              <span
                className={`font-semibold ${
                  worker.isActive ? 'text-emerald-700' : 'text-rose-700'
                }`}
              >
                {worker.isActive ? strings.activeStatus : strings.inactiveStatus}
              </span>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-1">
            {canTransfer && (
              <button
                type="button"
                onClick={() => setShowTransferModal(true)}
                title={strings.transferWorkerBtn}
                className="flex h-9 w-9 items-center justify-center rounded-xl text-blue-700 hover:bg-blue-50"
              >
                <ArrowRightLeft className="h-4 w-4" />
              </button>
            )}
            {canEditWorkers && (
              <button
                type="button"
                onClick={onEditWorkerClick}
                aria-label={strings.editWorker}
                className="flex h-9 w-9 items-center justify-center rounded-xl text-blue-700 hover:bg-blue-50"
              >
                <Edit3 className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 5 Profile Section Tabs */}
      <div className="thin-scroll flex gap-1 overflow-x-auto rounded-xl bg-slate-200/70 p-1">
        {tabs.map((t) => {
          const active = activeTab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id)}
              className={`shrink-0 rounded-lg px-2.5 py-2 text-[11px] font-semibold transition-colors whitespace-nowrap ${
                active
                  ? 'bg-white text-blue-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Month & Year Selector for Overview & Attendance */}
      {(activeTab === 'overview' || activeTab === 'attendance') && (
        <>
          <div className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-slate-500">
                {strings.selectYear}
              </span>
              <select
                value={selectedYear}
                onChange={(e) => handleYearSelect(Number(e.target.value))}
                className="h-8 rounded-lg border border-slate-200 bg-slate-50 px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
              >
                {[2025, 2026].map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-slate-500">
                {strings.selectMonth}
              </span>
              <select
                value={selectedMonth}
                onChange={(e) => handleMonthSelect(Number(e.target.value))}
                className="h-8 rounded-lg border border-slate-200 bg-slate-50 px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((m) => (
                  <option key={m} value={m}>
                    {String(m).padStart(2, '0')}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {selectedPeriodFinalized && (
            <div className="flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2.5 text-xs text-amber-900">
              <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-700" />
              <span>{strings.payrollLockedWarning}</span>
            </div>
          )}
        </>
      )}

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-3">
          <CurrentMonthProjectionCard
            strings={strings}
            summary={currentMonthSummary}
            projection={currentProjection}
          />

          {monthlySummary.outstandingBalance < 0 && (
            <div className="flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2.5 text-xs text-amber-900">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-700" />
              <span>{strings.overpaymentWarning}</span>
            </div>
          )}

          {monthlySummary.outstandingBalance >= 0 &&
            worker.isActive &&
            monthlySummary.halfDutyCount +
              monthlySummary.fullDutyCount +
              monthlySummary.oneAndHalfDutyCount +
              monthlySummary.doubleDutyCount +
              monthlySummary.twoAndHalfDutyCount +
              monthlySummary.tripleDutyCount ===
              0 && (
              <div className="flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2.5 text-xs text-amber-900">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-700" />
                <span>{strings.noMonthAttendanceWarning}</span>
              </div>
            )}

          <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white px-4 py-1 text-xs">
            <SummaryLine
              label={strings.totalCalendarDays}
              value={String(monthlySummary.totalCalendarDays)}
            />
            <SummaryLine
              label={strings.halfDutyLabel}
              value={String(monthlySummary.halfDutyCount)}
              valueClass="text-amber-700"
            />
            <SummaryLine
              label={strings.fullDutyLabel}
              value={String(monthlySummary.fullDutyCount)}
              valueClass="text-emerald-700"
            />
            <SummaryLine
              label={strings.oneAndHalfDutyLabel}
              value={String(monthlySummary.oneAndHalfDutyCount)}
              valueClass="text-teal-700"
            />
            <SummaryLine
              label={strings.doubleDutyLabel}
              value={String(monthlySummary.doubleDutyCount)}
              valueClass="text-indigo-700"
            />
            <SummaryLine
              label={strings.twoAndHalfDutyLabel}
              value={String(monthlySummary.twoAndHalfDutyCount)}
              valueClass="text-purple-700"
            />
            <SummaryLine
              label={strings.tripleDutyLabel}
              value={String(monthlySummary.tripleDutyCount)}
              valueClass="text-blue-700"
            />
            <SummaryLine
              label={strings.absentLabel}
              value={String(monthlySummary.absentCount)}
              valueClass="text-rose-700"
            />
            <SummaryLine
              label={strings.leaveLabel}
              value={String(monthlySummary.leaveCount)}
              valueClass="text-slate-600"
            />
            <SummaryLine
              label={strings.totalDutyUnits}
              value={monthlySummary.totalDutyUnits.toFixed(1)}
              valueClass="font-bold text-slate-900"
            />
            <SummaryLine
              label={strings.totalEarnedAmount}
              value={`৳${monthlySummary.totalEarnedAmount.toLocaleString('en-US')}`}
              valueClass="font-bold text-slate-900"
            />
            <SummaryLine
              label={strings.totalPaidAmount}
              value={`৳${monthlySummary.totalPaidAmount.toLocaleString('en-US')}`}
              valueClass="font-bold text-emerald-700"
            />
            <SummaryLine
              label={strings.advanceAppliedLabel}
              value={`৳${monthlySummary.advanceAllocatedAmount.toLocaleString('en-US')}`}
              valueClass="font-semibold text-amber-700"
            />
            <SummaryLine
              label={strings.remainingBalance}
              value={`৳${monthlySummary.outstandingBalance.toLocaleString('en-US')}`}
              valueClass="font-bold text-blue-800"
            />
          </div>
        </div>
      )}

      {/* TAB 2: ATTENDANCE CALENDAR & DETAILS */}
      {activeTab === 'attendance' && (
        <div className="space-y-3">
          <div className="rounded-2xl border border-slate-200 bg-white p-3">
            <div className="mb-2 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[10px] font-semibold text-slate-600">
              <span className="text-amber-700">H · {strings.halfDutyLabel}</span>
              <span className="text-emerald-700">F · {strings.fullDutyLabel}</span>
              <span className="text-teal-700">1.5 · {strings.oneAndHalfDutyLabel}</span>
              <span className="text-indigo-700">D · {strings.doubleDutyLabel}</span>
              <span className="text-purple-700">2.5 · {strings.twoAndHalfDutyLabel}</span>
              <span className="text-blue-700">T · {strings.tripleDutyLabel}</span>
              <span className="text-rose-700">A · {strings.absentLabel}</span>
              <span className="text-slate-600">L · {strings.leaveLabel}</span>
              <span className="text-slate-400">- · {strings.notRecordedLabel}</span>
            </div>

            <div className="grid grid-cols-7 gap-1.5">
              {calendarDays.map((day) => {
                const dateIso = `${selectedYear}-${String(selectedMonth).padStart(
                  2,
                  '0'
                )}-${String(day).padStart(2, '0')}`;
                const rec = workerAttendanceMap.get(dateIso);
                const isSelected = dateIso === selectedCalendarDate;
                const code = rec ? DUTY_TYPE_LABELS[rec.dutyType].shortCode : '-';

                return (
                  <button
                    key={dateIso}
                    type="button"
                    onClick={() => setSelectedCalendarDate(dateIso)}
                    className={`flex aspect-square flex-col items-center justify-center rounded-lg border text-[11px] leading-tight transition-colors ${getCalendarCellColors(
                      rec?.dutyType,
                      isSelected
                    )}`}
                  >
                    <span className="font-bold tabular-nums">{day}</span>
                    <span className="text-[10px] font-semibold">{code}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <h3 className="text-xs font-bold text-slate-900">
              {strings.selectedDateDetails}: {selectedCalendarDate}
            </h3>

            {selectedDayRecord ? (
              <div className="mt-2.5 divide-y divide-slate-100 text-xs">
                <SummaryLine
                  label={strings.siteColumnLabel}
                  value={sitesById[selectedDayRecord.siteId]?.siteName ?? selectedDayRecord.siteId}
                  valueClass="font-semibold text-blue-800"
                />
                <SummaryLine
                  label={strings.dutyTypeLabel}
                  value={
                    language === 'bn'
                      ? DUTY_TYPE_LABELS[selectedDayRecord.dutyType].bn
                      : DUTY_TYPE_LABELS[selectedDayRecord.dutyType].en
                  }
                />
                <SummaryLine
                  label={strings.dutyUnitsLabel}
                  value={String(selectedDayRecord.multiplierSnapshot)}
                />
                <SummaryLine
                  label={strings.dailyWageLabel}
                  value={`৳${selectedDayRecord.dailyWageSnapshot}`}
                />
                <SummaryLine
                  label={strings.earnedAmountLabel}
                  value={`৳${selectedDayRecord.earnedAmount}`}
                  valueClass="font-bold text-blue-800"
                />
                <SummaryLine
                  label={strings.notesLabel}
                  value={selectedDayRecord.note || '-'}
                />
                <SummaryLine
                  label={strings.lastUpdatedLabel}
                  value={`${selectedDayRecord.updatedAtIso} (${
                    language === 'bn'
                      ? USER_ROLE_LABELS[selectedDayRecord.updatedByRole].bn
                      : USER_ROLE_LABELS[selectedDayRecord.updatedByRole].en
                  })`}
                />
              </div>
            ) : (
              <p className="mt-2 text-xs text-slate-500">{strings.notRecordedLabel}</p>
            )}

            {canEditAttendance && !selectedDayLocked ? (
              <button
                type="button"
                onClick={() => setShowAttendanceModal(true)}
                className="mt-3 flex min-h-[38px] w-full items-center justify-center rounded-xl border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-800 hover:bg-blue-100"
              >
                {strings.recordOrEditAttendance}
              </button>
            ) : (
              <p className="mt-2.5 text-[11px] font-medium text-amber-700">
                {selectedDayLocked ? strings.payrollLockedWarning : strings.roleRestrictedAction}
              </p>
            )}
          </div>

          {workerAttendanceAudits.length > 0 && (
            <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
              <h4 className="mb-2 text-xs font-bold text-slate-900">
                {strings.auditHistoryTitle}
              </h4>
              <div className="space-y-2">
                {workerAttendanceAudits.map((audit) => (
                  <div
                    key={audit.auditId}
                    className="rounded-xl border border-slate-100 bg-slate-50 p-2.5 text-[11px]"
                  >
                    <div className="font-semibold text-slate-800">
                      {audit.dateIso}: {audit.previousDutyType ?? 'NONE'} → {audit.newDutyType}
                    </div>
                    <div className="mt-0.5 text-slate-500 tabular-nums">
                      ৳{audit.previousEarned ?? 0} → ৳{audit.newEarned} · {audit.changedByRole} ·{' '}
                      {audit.changedAtIso}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: PAYROLL HISTORY */}
      {activeTab === 'payroll' && (
        <div className="space-y-3">
          <CurrentMonthProjectionCard
            strings={strings}
            summary={currentMonthSummary}
            projection={currentProjection}
          />

          <div className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs">
            <span className="font-semibold text-slate-600">{strings.selectYear}:</span>
            <div className="flex gap-1.5">
              {(['ALL', 2026, 2025] as const).map((y) => (
                <button
                  key={String(y)}
                  type="button"
                  onClick={() => setHistoryYearFilter(y)}
                  className={`rounded-lg border px-2.5 py-1 text-[11px] font-semibold ${
                    historyYearFilter === y
                      ? 'border-blue-700 bg-blue-50 text-blue-800'
                      : 'border-slate-200 bg-white text-slate-600'
                  }`}
                >
                  {y === 'ALL' ? strings.allFilter : y}
                </button>
              ))}
            </div>
          </div>

          {exportNotice && (
            <div className="text-[11px] font-semibold text-emerald-700">{exportNotice}</div>
          )}

          <div className="space-y-2.5">
            {chronologicalHistory.map((mSummary) => {
              const pStatus =
                language === 'bn'
                  ? PAYROLL_STATUS_LABELS[mSummary.payrollStatus].bn
                  : PAYROLL_STATUS_LABELS[mSummary.payrollStatus].en;
              const lockStatus =
                language === 'bn'
                  ? PERIOD_LOCK_LABELS[mSummary.periodLockStatus].bn
                  : PERIOD_LOCK_LABELS[mSummary.periodLockStatus].en;

              return (
                <button
                  key={mSummary.periodIso}
                  type="button"
                  onClick={() => setBreakdownModalSummary(mSummary)}
                  className="w-full rounded-2xl border border-slate-200 bg-white p-3.5 text-left transition-colors hover:border-blue-300"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-mono text-xs font-bold text-slate-900">
                      {mSummary.periodIso} ·{' '}
                      <span
                        className={
                          mSummary.periodLockStatus === 'FINALIZED'
                            ? 'text-amber-700'
                            : 'text-emerald-700'
                        }
                      >
                        {lockStatus}
                      </span>
                    </div>
                    <span className="text-xs font-semibold text-blue-800">{pStatus}</span>
                  </div>

                  <div className="mt-1.5 text-[11px] text-slate-500 tabular-nums">
                    H:{mSummary.halfDutyCount} F:{mSummary.fullDutyCount} 1.5:{mSummary.oneAndHalfDutyCount} D:{mSummary.doubleDutyCount} 2.5:{mSummary.twoAndHalfDutyCount} T:{mSummary.tripleDutyCount} A:{mSummary.absentCount} L:{mSummary.leaveCount} ·{' '}
                    {mSummary.totalDutyUnits.toFixed(1)} {strings.dutyUnitsLabel}
                  </div>

                  <div className="mt-2 grid grid-cols-3 gap-2 border-t border-slate-100 pt-2 text-xs tabular-nums">
                    <div>
                      <div className="text-[10px] text-slate-500">{strings.totalEarnedAmount}</div>
                      <div className="font-bold text-slate-900">
                        ৳{mSummary.totalEarnedAmount}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500">{strings.totalPaidAmount}</div>
                      <div className="font-bold text-emerald-700">
                        ৳{mSummary.totalPaidAmount}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-slate-500">{strings.remainingBalance}</div>
                      <div className="font-bold text-blue-800">
                        ৳{mSummary.outstandingBalance}
                      </div>
                    </div>
                  </div>
                  {mSummary.advanceAllocatedAmount > 0 && (
                    <div className="mt-1 text-[10px] font-semibold text-amber-700 tabular-nums">
                      {strings.advanceAppliedLabel}: ৳{mSummary.advanceAllocatedAmount}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: PAYMENT HISTORY & ADVANCES */}
      {activeTab === 'payments' && (
        <div className="space-y-3">
          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <div className="divide-y divide-slate-100 text-xs">
              <SummaryLine
                label={strings.totalEarnedAmount}
                value={`৳${overallBalances.totalEarned.toLocaleString('en-US')}`}
                valueClass="font-bold text-slate-900"
              />
              <SummaryLine
                label={strings.totalPaidAmount}
                value={`৳${overallBalances.totalPaid.toLocaleString('en-US')}`}
                valueClass="font-bold text-emerald-700"
              />
              <SummaryLine
                label={strings.unallocatedAdvancesLabel}
                value={`৳${unallocatedAdvanceTotal.toLocaleString('en-US')}`}
                valueClass="font-bold text-amber-700"
              />
              <SummaryLine
                label={strings.remainingBalance}
                value={`৳${overallBalances.outstanding.toLocaleString('en-US')}`}
                valueClass="font-bold text-blue-800"
              />
            </div>

            {canEditPayments ? (
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(true)}
                  className="flex min-h-[40px] items-center justify-center gap-1.5 rounded-xl bg-blue-700 px-3 py-2 text-xs font-semibold text-white hover:bg-blue-800"
                >
                  <Plus className="h-4 w-4" />
                  <span>{strings.recordPayment}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowAdvanceModal(true)}
                  className="flex min-h-[40px] items-center justify-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-800 hover:bg-blue-100"
                >
                  <span>{strings.recordAdvanceBtn}</span>
                </button>
              </div>
            ) : (
              <p className="mt-2.5 text-[11px] font-medium text-amber-700">
                {strings.roleRestrictedAction}
              </p>
            )}
          </div>

          {workerAdvances.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-800">
                {strings.unallocatedAdvancesLabel}
              </h4>
              {workerAdvances.map((adv) => {
                const remaining = computeAdvanceRemaining(adv, allocations);
                return (
                  <div
                    key={adv.id}
                    className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-3.5"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-semibold text-slate-900">
                        {adv.id} · {adv.advanceDateIso} ({sitesById[adv.siteId]?.siteCode ?? adv.siteId})
                      </div>
                      <div className="mt-0.5 truncate text-[11px] text-slate-500">
                        {adv.referenceNo} · {adv.note}
                      </div>
                      <div className="mt-0.5 text-[11px] font-semibold text-amber-700 tabular-nums">
                        Total: ৳{adv.amount} · Remaining: ৳{remaining}
                      </div>
                    </div>
                    {remaining > 0 && canEditPayments && (
                      <button
                        type="button"
                        onClick={() => setAllocateTarget(adv)}
                        className="shrink-0 rounded-xl border border-blue-200 bg-blue-50 px-2.5 py-1.5 text-[11px] font-semibold text-blue-800 hover:bg-blue-100"
                      >
                        {strings.allocateAdvanceBtn}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-800">
              {strings.transactionHistory}
            </h4>
            {workerPayments.map((tx) => {
              const txLocked = isPeriodFinalized(
                tx.applicablePeriod,
                payrollPeriods,
                tx.siteId
              );
              return (
                <div
                  key={tx.id}
                  className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-3.5"
                >
                  <div className="min-w-0 flex-1">
                    <div
                      className={`text-xs font-semibold ${
                        tx.isVoided ? 'text-slate-400 line-through' : 'text-slate-900'
                      }`}
                    >
                      {tx.id} · {sitesById[tx.siteId]?.siteCode ?? tx.siteId} · {tx.dateIso}
                    </div>
                    <div className="mt-0.5 text-[11px] font-semibold text-blue-800">
                      {strings.applicablePeriodLabel}: {tx.applicablePeriod} · {tx.referenceNo}
                    </div>
                    <div className="mt-0.5 truncate text-[11px] text-slate-500">
                      {language === 'bn' ? tx.noteBn : tx.noteEn}
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div
                      className={`text-sm font-bold tabular-nums ${
                        tx.isVoided ? 'text-rose-700' : 'text-emerald-700'
                      }`}
                    >
                      {tx.isVoided ? strings.voidedLabel : `৳${tx.paidAmount}`}
                    </div>
                    {!tx.isVoided && canEditPayments && !txLocked && (
                      <button
                        type="button"
                        onClick={() => setVoidTarget(tx)}
                        className="mt-0.5 text-[11px] font-semibold text-rose-700 hover:underline"
                      >
                        {strings.voidTransaction}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {workerPaymentAudits.length > 0 && (
            <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
              <h4 className="mb-2 text-xs font-bold text-slate-900">
                {strings.auditHistoryTitle}
              </h4>
              <div className="space-y-1.5 text-[11px] text-slate-600">
                {workerPaymentAudits.map((pa) => (
                  <div key={pa.auditId}>
                    {pa.transactionId}: {pa.action} (৳{pa.newAmount}) · {pa.changedByRole} ·{' '}
                    {pa.changedAtIso}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: PERSONAL INFO & TRANSFER HISTORY */}
      {activeTab === 'personal' && (
        <div className="space-y-3">
          <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white px-4 py-1 text-xs">
            <SummaryLine
              label={strings.activeSiteLabel}
              value={currentSite ? `${currentSite.siteCode} · ${currentSite.siteName}` : worker.siteId}
              valueClass="font-semibold text-blue-800"
            />
            <SummaryLine label={strings.fullNameLabel} value={displayName} />
            <SummaryLine
              label={strings.workerIdLabel}
              value={`${worker.localWorkerCode || worker.id} (${worker.id})`}
            />
            <SummaryLine label={strings.phoneNumberLabel} value={worker.phoneNumber || '-'} />
            <SummaryLine label={strings.categoryLabel} value={categoryLabel} />
            <SummaryLine label={strings.joiningDateLabel} value={worker.joiningDateIso} />
            <SummaryLine label={strings.leavingDateLabel} value={worker.leavingDateIso || '-'} />
            <SummaryLine label={strings.dailyWageLabel} value={`৳${worker.dailyWage}`} />
            <SummaryLine
              label={strings.foodAllowanceLabel}
              value={`৳${worker.dailyFoodAllowance}`}
            />
            <SummaryLine
              label={strings.statusLabel}
              value={worker.isActive ? strings.activeStatus : strings.inactiveStatus}
              valueClass={worker.isActive ? 'text-emerald-700' : 'text-rose-700'}
            />
            {worker.photoPath && <SummaryLine label="Photo Path" value={worker.photoPath} />}
          </div>

          {canTransfer && (
            <button
              type="button"
              onClick={() => setShowTransferModal(true)}
              className="flex min-h-[40px] w-full items-center justify-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-800 hover:bg-blue-100"
            >
              <ArrowRightLeft className="h-3.5 w-3.5" />
              <span>{strings.transferWorkerBtn}</span>
            </button>
          )}

          {transfersForWorker.length > 0 && (
            <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
              <h4 className="mb-2 text-xs font-bold text-slate-900">
                {strings.siteTransferHistoryTitle}
              </h4>
              <div className="space-y-2 text-[11px]">
                {transfersForWorker.map((tr) => (
                  <div
                    key={tr.historyId}
                    className="rounded-xl border border-slate-100 bg-slate-50 p-2.5"
                  >
                    <div className="font-semibold text-slate-900">
                      {sitesById[tr.fromSiteId]?.siteCode ?? tr.fromSiteId} →{' '}
                      {sitesById[tr.toSiteId]?.siteCode ?? tr.toSiteId} · {tr.transferDateIso}
                    </div>
                    <div className="mt-0.5 text-slate-500">
                      ID: {tr.previousLocalCode} → {tr.newLocalCode} · {tr.note || '-'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Monthly Breakdown Drill-Down Modal */}
      {breakdownModalSummary && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="max-h-[85vh] w-full max-w-sm overflow-y-auto rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                {strings.monthlyBreakdownTitle} · {breakdownModalSummary.periodIso}
              </h3>
              <button
                type="button"
                onClick={() => setBreakdownModalSummary(null)}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-3 divide-y divide-slate-100 text-xs">
              <SummaryLine
                label={strings.halfDutyLabel}
                value={String(breakdownModalSummary.halfDutyCount)}
                valueClass="text-amber-700 font-semibold"
              />
              <SummaryLine
                label={strings.fullDutyLabel}
                value={String(breakdownModalSummary.fullDutyCount)}
                valueClass="text-emerald-700 font-semibold"
              />
              <SummaryLine
                label={strings.oneAndHalfDutyLabel}
                value={String(breakdownModalSummary.oneAndHalfDutyCount)}
                valueClass="text-teal-700 font-semibold"
              />
              <SummaryLine
                label={strings.doubleDutyLabel}
                value={String(breakdownModalSummary.doubleDutyCount)}
                valueClass="text-indigo-700 font-semibold"
              />
              <SummaryLine
                label={strings.twoAndHalfDutyLabel}
                value={String(breakdownModalSummary.twoAndHalfDutyCount)}
                valueClass="text-purple-700 font-semibold"
              />
              <SummaryLine
                label={strings.tripleDutyLabel}
                value={String(breakdownModalSummary.tripleDutyCount)}
                valueClass="text-blue-700 font-semibold"
              />
              <SummaryLine
                label={strings.absentLabel}
                value={String(breakdownModalSummary.absentCount)}
                valueClass="text-rose-700 font-semibold"
              />
              <SummaryLine
                label={strings.leaveLabel}
                value={String(breakdownModalSummary.leaveCount)}
              />
              <SummaryLine
                label={strings.totalDutyUnits}
                value={breakdownModalSummary.totalDutyUnits.toFixed(1)}
              />
              <SummaryLine
                label={strings.totalEarnedAmount}
                value={`৳${breakdownModalSummary.totalEarnedAmount}`}
              />
              <SummaryLine
                label={strings.totalPaidAmount}
                value={`৳${breakdownModalSummary.totalPaidAmount}`}
                valueClass="text-emerald-700 font-bold"
              />
              <SummaryLine
                label={strings.advanceAppliedLabel}
                value={`৳${breakdownModalSummary.advanceAllocatedAmount}`}
                valueClass="text-amber-700 font-semibold"
              />
              <SummaryLine
                label={strings.remainingBalance}
                value={`৳${breakdownModalSummary.outstandingBalance}`}
                valueClass="text-blue-800 font-bold"
              />
            </div>

            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setBreakdownModalSummary(null)}
                className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                {strings.close}
              </button>
              <button
                type="button"
                onClick={() => {
                  handleExportWorkerPdf(breakdownModalSummary);
                  setBreakdownModalSummary(null);
                }}
                className="flex min-h-[38px] items-center gap-1.5 rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800"
              >
                <Download className="h-3.5 w-3.5" />
                <span>{strings.exportWorkerPdfBtn}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Transfer Worker Between Sites Modal (Admin Only) */}
      {showTransferModal && (
        <TransferWorkerModal
          strings={strings}
          worker={worker}
          allSites={allSites}
          allWorkersAcrossSites={allWorkersAcrossSites}
          onClose={() => setShowTransferModal(false)}
          onConfirm={(toSiteId, newLocalCode, transferDateIso, note) => {
            onTransferWorker({
              workerId: worker.id,
              toSiteId,
              newLocalCode,
              transferDateIso,
              note,
            });
            setShowTransferModal(false);
          }}
        />
      )}

      {/* Attendance Modal */}
      {showAttendanceModal && (
        <ProfileAttendanceModal
          strings={strings}
          language={language}
          dateIso={selectedCalendarDate}
          worker={worker}
          dutyConfig={dutyConfig}
          existingRecord={selectedDayRecord}
          onClose={() => setShowAttendanceModal(false)}
          onSave={(dutyType, note, editReason) => {
            onRecordAttendance({
              dateIso: selectedCalendarDate,
              worker,
              dutyType,
              note,
              editReason,
            });
            setShowAttendanceModal(false);
          }}
        />
      )}

      {/* Payment Modal */}
      {showPaymentModal && (
        <ProfilePaymentModal
          strings={strings}
          siteId={worker.siteId}
          defaultPeriod={selectedPeriodIso}
          outstandingBalance={monthlySummary.outstandingBalance}
          payrollPeriods={payrollPeriods}
          onClose={() => setShowPaymentModal(false)}
          onConfirm={(payDate, periodIso, amount, referenceNo, note, token) => {
            onRecordPayment({
              workerId: worker.id,
              dateIso: payDate,
              applicablePeriod: periodIso,
              paidAmount: amount,
              referenceNo,
              note,
              submissionToken: token,
            });
            setShowPaymentModal(false);
          }}
        />
      )}

      {/* Advance Entry Modal */}
      {showAdvanceModal && (
        <ProfileAdvanceModal
          strings={strings}
          onClose={() => setShowAdvanceModal(false)}
          onConfirm={(advDate, amount, referenceNo, note, token) => {
            onRecordAdvance({
              workerId: worker.id,
              advanceDateIso: advDate,
              amount,
              referenceNo,
              note,
              submissionToken: token,
            });
            setShowAdvanceModal(false);
          }}
        />
      )}

      {/* Allocate Advance Modal */}
      {allocateTarget && (
        <ProfileAllocateAdvanceModal
          strings={strings}
          advance={allocateTarget}
          remainingAdvance={computeAdvanceRemaining(allocateTarget, allocations)}
          defaultPeriod={selectedPeriodIso}
          payrollPeriods={payrollPeriods}
          onClose={() => setAllocateTarget(null)}
          onConfirm={(targetPeriod, amountToAllocate, note) => {
            onAllocateAdvance({
              advanceId: allocateTarget.id,
              targetPeriod,
              amountToAllocate,
              note,
            });
            setAllocateTarget(null);
          }}
        />
      )}

      {/* Void Confirmation Modal */}
      {voidTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <h3 className="text-sm font-bold text-slate-900">{strings.voidTransaction}</h3>
            <p className="mt-2 text-xs leading-relaxed text-slate-600">
              {strings.confirmVoidPaymentMsg}
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setVoidTarget(null)}
                className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                {strings.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  onVoidPayment(voidTarget.id, 'Voided from Worker Profile');
                  setVoidTarget(null);
                }}
                className="min-h-[38px] rounded-xl bg-rose-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-rose-800"
              >
                {strings.confirmAction}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TransferWorkerModal({
  strings,
  worker,
  allSites,
  allWorkersAcrossSites,
  onClose,
  onConfirm,
}: {
  strings: BilingualUiStrings;
  worker: Worker;
  allSites: Site[];
  allWorkersAcrossSites: Worker[];
  onClose: () => void;
  onConfirm: (toSiteId: string, newLocalCode: string, dateIso: string, note: string) => void;
}) {
  const destinationOptions = allSites.filter(
    (s) => s.id !== worker.siteId && s.status !== 'ARCHIVED'
  );
  const [toSiteId, setToSiteId] = useState(destinationOptions[0]?.id ?? '');
  const [newLocalCode, setNewLocalCode] = useState(worker.localWorkerCode || worker.id);
  const [transferDateIso, setTransferDateIso] = useState('2026-11-15');
  const [note, setNote] = useState('');

  const duplicateInTarget = isLocalWorkerCodeDuplicate(
    toSiteId,
    newLocalCode,
    worker.id,
    allWorkersAcrossSites
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            {strings.transferWorkerTitle}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!toSiteId || !newLocalCode.trim() || duplicateInTarget) return;
            onConfirm(toSiteId, newLocalCode.trim().toUpperCase(), transferDateIso, note.trim());
          }}
          className="mt-3 space-y-2.5"
        >
          <div>
            <label className="block text-[11px] font-medium text-slate-600">
              {strings.targetSiteLabel}
            </label>
            <select
              value={toSiteId}
              onChange={(e) => setToSiteId(e.target.value)}
              className="mt-1 h-9 w-full rounded-xl border border-slate-300 bg-white px-2.5 text-xs font-semibold"
            >
              {destinationOptions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.siteCode} · {s.siteName}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-600">
              {strings.workerIdLabel}
            </label>
            <input
              type="text"
              required
              value={newLocalCode}
              onChange={(e) => setNewLocalCode(e.target.value)}
              className="mt-1 h-9 w-full rounded-xl border border-slate-300 px-3 font-mono text-xs"
            />
          </div>

          {duplicateInTarget && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 px-2.5 py-2 text-[11px] text-rose-800">
              {strings.duplicateLocalCodeError}
            </div>
          )}

          <div>
            <label className="block text-[11px] font-medium text-slate-600">
              {strings.selectDate}
            </label>
            <input
              type="date"
              value={transferDateIso}
              onChange={(e) => setTransferDateIso(e.target.value)}
              className="mt-1 h-9 w-full rounded-xl border border-slate-300 px-2.5 text-xs"
            />
          </div>

          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={strings.transferNoteLabel}
            className="h-9 w-full rounded-xl border border-slate-300 px-3 text-xs"
          />

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600"
            >
              {strings.cancel}
            </button>
            <button
              type="submit"
              disabled={!toSiteId || duplicateInTarget}
              className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white disabled:opacity-50"
            >
              {strings.confirmAction}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function CurrentMonthProjectionCard({
  strings,
  summary,
  projection,
}: {
  strings: BilingualUiStrings;
  summary: WorkerMonthlySummary;
  projection: ReturnType<typeof computeCurrentMonthProjection>;
}) {
  return (
    <div className="rounded-2xl border border-blue-200 bg-blue-50/70 p-3.5 text-xs">
      <div className="font-bold text-blue-900">
        {strings.currentMonthPayrollTitle} ({summary.periodIso})
      </div>
      <div className="mt-2 space-y-1.5 tabular-nums">
        <div className="flex justify-between">
          <span className="text-slate-600">{strings.earnedUpToTodayLabel}</span>
          <span className="font-bold text-slate-900">
            ৳{projection.earnedToDate.toLocaleString('en-US')}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-600">{strings.totalPaidAmount}</span>
          <span className="font-bold text-emerald-700">
            ৳{projection.paidToDate.toLocaleString('en-US')}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-600">{strings.remainingBalance}</span>
          <span className="font-bold text-blue-800">
            ৳{projection.remainingBalance.toLocaleString('en-US')}
          </span>
        </div>
        <div className="flex justify-between border-t border-blue-200 pt-1.5">
          <span className="text-slate-600">{strings.estimatedMonthEndLabel}</span>
          <span className="font-bold text-amber-800">
            ৳{projection.estimatedMonthEndSalary.toLocaleString('en-US')}
          </span>
        </div>
      </div>
      <div className="mt-1 text-[10px] font-medium text-amber-800">
        {strings.estimateDisclaimer}
      </div>
    </div>
  );
}

function SummaryLine({
  label,
  value,
  valueClass = 'font-semibold text-slate-900',
}: {
  label: string;
  value: string;
  valueClass?: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5">
      <span className="text-slate-500">{label}</span>
      <span className={`text-right tabular-nums ${valueClass}`}>{value}</span>
    </div>
  );
}

function ProfileAttendanceModal({
  strings,
  language,
  dateIso,
  worker,
  dutyConfig,
  existingRecord,
  onClose,
  onSave,
}: {
  strings: BilingualUiStrings;
  language: AppLanguage;
  dateIso: string;
  worker: Worker;
  dutyConfig: DutyMultiplierConfig;
  existingRecord: DailyAttendanceRecord | null;
  onClose: () => void;
  onSave: (dutyType: DutyType, note: string, editReason: string) => void;
}) {
  const [selectedDuty, setSelectedDuty] = useState<DutyType>(
    existingRecord?.dutyType ?? 'FULL_DUTY'
  );
  const [note, setNote] = useState(existingRecord?.note ?? '');
  const [needsConfirm, setNeedsConfirm] = useState(false);

  const wageBase = existingRecord?.dailyWageSnapshot ?? worker.dailyWage;
  const multiplier = getMultiplierForDuty(dutyConfig, selectedDuty);
  const previewEarned = calculateDailyEarnedTaka(wageBase, multiplier);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (existingRecord && !needsConfirm) {
      setNeedsConfirm(true);
      return;
    }
    onSave(
      selectedDuty,
      note.trim(),
      existingRecord ? 'Edited from Worker Profile' : 'Initial record'
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            {strings.recordOrEditAttendance} · {dateIso}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-3 space-y-3">
          <div className="grid grid-cols-2 gap-1.5">
            {DUTY_ORDER.map((dt) => {
              const mult = getMultiplierForDuty(dutyConfig, dt);
              const label =
                language === 'bn' ? DUTY_TYPE_LABELS[dt].bn : DUTY_TYPE_LABELS[dt].en;
              const selected = selectedDuty === dt;
              return (
                <button
                  key={dt}
                  type="button"
                  onClick={() => setSelectedDuty(dt)}
                  className={`flex min-h-[38px] items-center justify-between rounded-xl border px-2.5 py-1.5 text-xs font-semibold transition-colors ${
                    selected
                      ? 'border-blue-700 bg-blue-700 text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="truncate">{label}</span>
                  <span className="ml-1 shrink-0 font-mono text-[11px]">{mult}x</span>
                </button>
              );
            })}
          </div>

          <div className="space-y-1 rounded-xl border border-blue-100 bg-blue-50/70 px-3 py-2.5 text-xs">
            <div className="flex justify-between gap-2 text-slate-700">
              <span>{strings.dutyTypeLabel}</span>
              <span className="font-semibold text-blue-950">
                {language === 'bn'
                  ? DUTY_TYPE_LABELS[selectedDuty].bn
                  : DUTY_TYPE_LABELS[selectedDuty].en}
              </span>
            </div>
            <div className="flex justify-between gap-2 text-slate-700 tabular-nums">
              <span>{strings.dutyMultiplierLabel}</span>
              <span className="font-semibold text-blue-950">{multiplier}x</span>
            </div>
            <div className="flex justify-between gap-2 text-slate-700 tabular-nums">
              <span>{strings.savedDailyWageLabel}</span>
              <span className="font-semibold text-slate-900">৳{wageBase}</span>
            </div>
            <div className="flex justify-between gap-2 border-t border-blue-200 pt-1 font-bold text-blue-900 tabular-nums">
              <span>{strings.earnedAmountLabel}</span>
              <span>
                ৳{wageBase} × {multiplier} = ৳{previewEarned}
              </span>
            </div>
          </div>

          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={strings.notesLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm focus:border-blue-600 focus:outline-none"
          />

          {needsConfirm && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-2.5 text-xs text-amber-900">
              {strings.confirmEditAttendanceMsg}
            </div>
          )}

          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              {strings.cancel}
            </button>
            <button
              type="submit"
              className="flex min-h-[38px] items-center gap-1 rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            >
              <Check className="h-3.5 w-3.5" />
              <span>{needsConfirm ? strings.confirmAction : strings.saveChanges}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ProfilePaymentModal({
  strings,
  siteId,
  defaultPeriod,
  outstandingBalance,
  payrollPeriods,
  onClose,
  onConfirm,
}: {
  strings: BilingualUiStrings;
  siteId: string;
  defaultPeriod: string;
  outstandingBalance: number;
  payrollPeriods: PayrollPeriodRecord[];
  onClose: () => void;
  onConfirm: (
    paymentDateIso: string,
    applicablePeriod: string,
    amount: number,
    referenceNo: string,
    note: string,
    token: string
  ) => void;
}) {
  const safeBalance = Math.max(0, outstandingBalance);
  const [paymentDateIso, setPaymentDateIso] = useState('2026-11-15');
  const [applicablePeriod, setApplicablePeriod] = useState(defaultPeriod);
  const [amount, setAmount] = useState(String(safeBalance));
  const [referenceNo, setReferenceNo] = useState('');
  const [note, setNote] = useState('');
  const [token] = useState(() => `pay_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`);

  const locked = isPeriodFinalized(applicablePeriod, payrollPeriods, siteId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (locked) return;
    const numeric = Number(amount);
    if (!Number.isFinite(numeric) || numeric <= 0) return;
    onConfirm(
      paymentDateIso || '2026-11-15',
      applicablePeriod,
      Math.trunc(numeric),
      referenceNo.trim() || 'CASH',
      note.trim() || 'Worker wage payment',
      token
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">{strings.recordPayment}</h3>
          <button
            type="button"
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-3 space-y-2.5">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-medium text-slate-600">
                {strings.paymentDateLabel}
              </label>
              <input
                type="date"
                value={paymentDateIso}
                onChange={(e) => setPaymentDateIso(e.target.value)}
                className="mt-1 h-9 w-full rounded-xl border border-slate-300 px-2 text-xs"
              />
            </div>
            <div>
              <label className="block text-[11px] font-medium text-slate-600">
                {strings.applicablePeriodLabel}
              </label>
              <select
                value={applicablePeriod}
                onChange={(e) => setApplicablePeriod(e.target.value)}
                className="mt-1 h-9 w-full rounded-xl border border-slate-300 bg-white px-2 text-xs font-semibold"
              >
                {['2026-09', '2026-10', '2026-11', '2026-12'].map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {locked && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 px-2.5 py-2 text-[11px] font-medium text-rose-800">
              {strings.payrollLockedWarning}
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setAmount(String(safeBalance))}
              className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
            >
              {strings.fullPaymentBtn} (৳{safeBalance})
            </button>
            <button
              type="button"
              onClick={() => setAmount(String(Math.floor(safeBalance / 2)))}
              className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
            >
              {strings.partialPaymentBtn} (৳{Math.floor(safeBalance / 2)})
            </button>
          </div>

          <input
            type="number"
            min={1}
            required
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder={strings.paymentAmountLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm tabular-nums"
          />
          <input
            type="text"
            value={referenceNo}
            onChange={(e) => setReferenceNo(e.target.value)}
            placeholder={strings.referenceNoLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
          />
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={strings.paymentNoteLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
          />

          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              {strings.cancel}
            </button>
            <button
              type="submit"
              disabled={locked}
              className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 disabled:opacity-50"
            >
              {strings.saveEntry}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ProfileAdvanceModal({
  strings,
  onClose,
  onConfirm,
}: {
  strings: BilingualUiStrings;
  onClose: () => void;
  onConfirm: (
    dateIso: string,
    amount: number,
    ref: string,
    note: string,
    token: string
  ) => void;
}) {
  const [dateIso, setDateIso] = useState('2026-11-15');
  const [amount, setAmount] = useState('');
  const [ref, setRef] = useState('');
  const [note, setNote] = useState('');
  const [token] = useState(() => `adv_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
        <h3 className="text-sm font-bold text-slate-900">{strings.recordAdvanceBtn}</h3>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const num = Math.trunc(Number(amount));
            if (!Number.isFinite(num) || num <= 0) return;
            onConfirm(dateIso || '2026-11-15', num, ref || 'ADV', note || 'Site advance', token);
          }}
          className="mt-3 space-y-2.5"
        >
          <input
            type="date"
            value={dateIso}
            onChange={(e) => setDateIso(e.target.value)}
            className="h-9 w-full rounded-xl border border-slate-300 px-3 text-xs"
          />
          <input
            type="number"
            min={1}
            required
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder={strings.paymentAmountLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm tabular-nums"
          />
          <input
            type="text"
            value={ref}
            onChange={(e) => setRef(e.target.value)}
            placeholder={strings.referenceNoLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
          />
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={strings.notesLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
          />
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600"
            >
              {strings.cancel}
            </button>
            <button
              type="submit"
              className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white"
            >
              {strings.saveEntry}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ProfileAllocateAdvanceModal({
  strings,
  advance,
  remainingAdvance,
  defaultPeriod,
  payrollPeriods,
  onClose,
  onConfirm,
}: {
  strings: BilingualUiStrings;
  advance: AdvanceRecord;
  remainingAdvance: number;
  defaultPeriod: string;
  payrollPeriods: PayrollPeriodRecord[];
  onClose: () => void;
  onConfirm: (targetPeriod: string, amountToAllocate: number, note: string) => void;
}) {
  const [targetPeriod, setTargetPeriod] = useState(defaultPeriod);
  const [amount, setAmount] = useState(String(remainingAdvance));
  const [note, setNote] = useState(`Applied ${advance.id}`);
  const locked = isPeriodFinalized(targetPeriod, payrollPeriods, advance.siteId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
        <h3 className="text-sm font-bold text-slate-900">
          {strings.allocateAdvanceBtn} ({advance.id})
        </h3>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (locked) return;
            const num = Math.min(remainingAdvance, Math.trunc(Number(amount)));
            if (num > 0) onConfirm(targetPeriod, num, note.trim() || `Applied ${advance.id}`);
          }}
          className="mt-3 space-y-2.5"
        >
          <select
            value={targetPeriod}
            onChange={(e) => setTargetPeriod(e.target.value)}
            className="h-9 w-full rounded-xl border border-slate-300 bg-white px-2 text-xs font-semibold"
          >
            {['2026-09', '2026-10', '2026-11', '2026-12'].map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
          {locked && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 px-2.5 py-2 text-[11px] text-rose-800">
              {strings.payrollLockedWarning}
            </div>
          )}
          <input
            type="number"
            min={1}
            max={remainingAdvance}
            required
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm tabular-nums"
          />
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={strings.notesLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
          />
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600"
            >
              {strings.cancel}
            </button>
            <button
              type="submit"
              disabled={locked}
              className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white disabled:opacity-50"
            >
              {strings.confirmAction}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
