import { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArchiveRestore,
  CheckCircle2,
  Database,
  FileArchive,
  Globe,
  HardDriveDownload,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Upload,
  WifiOff,
  X,
} from 'lucide-react';
import { BilingualUiStrings, USER_ROLE_LABELS } from '../../data/bilingualStrings';
import {
  AppLanguage,
  BackupHistoryRecord,
  BackupProgress,
  BackupValidationResult,
  DutyMultiplierConfig,
  Site,
  UserRole,
  UserSiteAccount,
} from '../../types/siteLedger';

interface SettingsScreenViewProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  activeRole: UserRole;
  activeSite: Site;
  userSiteAccounts: UserSiteAccount[];
  dutyConfig: DutyMultiplierConfig;
  backupHistory: BackupHistoryRecord[];
  backupProgress: BackupProgress;
  pendingRestore: BackupValidationResult | null;
  backupFeedback: { type: 'success' | 'error'; message: string } | null;
  onSelectLanguage: (lang: AppLanguage) => void;
  onSelectRole: (role: UserRole) => void;
  onSaveDutyConfig: (config: DutyMultiplierConfig) => void;
  onCreateFullBackup: () => void;
  onInspectBackupFile: (file: File, openRestorePrompt: boolean) => void;
  onConfirmRestore: () => void;
  onDismissPendingRestore: () => void;
  onClearBackupFeedback: () => void;
  onResetSampleData: () => void;
}

const ROLES: UserRole[] = ['ADMIN', 'MANAGER', 'ACCOUNTANT'];

export function SettingsScreenView({
  strings,
  language,
  activeRole,
  activeSite,
  userSiteAccounts,
  dutyConfig,
  backupHistory,
  backupProgress,
  pendingRestore,
  backupFeedback,
  onSelectLanguage,
  onSelectRole,
  onSaveDutyConfig,
  onCreateFullBackup,
  onInspectBackupFile,
  onConfirmRestore,
  onDismissPendingRestore,
  onClearBackupFeedback,
  onResetSampleData,
}: SettingsScreenViewProps) {
  const [halfText, setHalfText] = useState(String(dutyConfig.halfDutyMultiplier));
  const [fullText, setFullText] = useState(String(dutyConfig.fullDutyMultiplier));
  const [oneAndHalfText, setOneAndHalfText] = useState(
    String(dutyConfig.oneAndHalfDutyMultiplier)
  );
  const [doubleText, setDoubleText] = useState(String(dutyConfig.doubleDutyMultiplier));
  const [twoAndHalfText, setTwoAndHalfText] = useState(
    String(dutyConfig.twoAndHalfDutyMultiplier)
  );
  const [tripleText, setTripleText] = useState(String(dutyConfig.tripleDutyMultiplier));
  const [absentText, setAbsentText] = useState(String(dutyConfig.absentMultiplier));
  const [leaveText, setLeaveText] = useState(String(dutyConfig.leaveMultiplier));
  const [savedNotice, setSavedNotice] = useState(false);

  const restoreFileInputRef = useRef<HTMLInputElement | null>(null);
  const verifyFileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setHalfText(String(dutyConfig.halfDutyMultiplier));
    setFullText(String(dutyConfig.fullDutyMultiplier));
    setOneAndHalfText(String(dutyConfig.oneAndHalfDutyMultiplier));
    setDoubleText(String(dutyConfig.doubleDutyMultiplier));
    setTwoAndHalfText(String(dutyConfig.twoAndHalfDutyMultiplier));
    setTripleText(String(dutyConfig.tripleDutyMultiplier));
    setAbsentText(String(dutyConfig.absentMultiplier));
    setLeaveText(String(dutyConfig.leaveMultiplier));
  }, [dutyConfig]);

  const isAdmin = activeRole === 'ADMIN';
  const currentAccount = userSiteAccounts.find((a) => a.role === activeRole);
  const hasSiteAccess =
    isAdmin || Boolean(currentAccount?.assignedSiteIds.includes(activeSite.id));

  const handleSaveMultipliers = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    const parseNonNeg = (val: string, fallback: number) => {
      const n = Number(val);
      return Number.isFinite(n) && n >= 0 ? n : fallback;
    };
    onSaveDutyConfig({
      halfDutyMultiplier: parseNonNeg(halfText, 0.5),
      fullDutyMultiplier: parseNonNeg(fullText, 1.0),
      oneAndHalfDutyMultiplier: parseNonNeg(oneAndHalfText, 1.5),
      doubleDutyMultiplier: parseNonNeg(doubleText, 2.0),
      twoAndHalfDutyMultiplier: parseNonNeg(twoAndHalfText, 2.5),
      tripleDutyMultiplier: parseNonNeg(tripleText, 3.0),
      absentMultiplier: parseNonNeg(absentText, 0.0),
      leaveMultiplier: parseNonNeg(leaveText, 0.0),
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  return (
    <div className="space-y-3.5 p-4">
      {/* Phase 2 — Offline Backup & Restore System */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <FileArchive className="h-4 w-4 text-blue-700" />
          <span>{strings.backupSectionTitle}</span>
        </div>
        <p className="mt-1 text-xs leading-relaxed text-slate-500">
          {strings.backupSectionDesc}
        </p>

        <input
          ref={restoreFileInputRef}
          type="file"
          accept=".zip,application/zip"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onInspectBackupFile(file, true);
            e.target.value = '';
          }}
        />
        <input
          ref={verifyFileInputRef}
          type="file"
          accept=".zip,application/zip"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onInspectBackupFile(file, false);
            e.target.value = '';
          }}
        />

        <div className="mt-3 space-y-2">
          <button
            type="button"
            disabled={backupProgress.isRunning}
            onClick={onCreateFullBackup}
            className="flex min-h-[42px] w-full items-center justify-center gap-2 rounded-xl bg-blue-700 px-3 py-2 text-xs font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
          >
            <HardDriveDownload className="h-4 w-4" />
            <span>{strings.createFullBackupBtn}</span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              disabled={backupProgress.isRunning}
              onClick={() => restoreFileInputRef.current?.click()}
              className="flex min-h-[38px] items-center justify-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 px-2.5 py-2 text-xs font-semibold text-blue-800 hover:bg-blue-100"
            >
              <Upload className="h-3.5 w-3.5" />
              <span className="truncate">{strings.restoreFromBackupBtn}</span>
            </button>
            <button
              type="button"
              disabled={backupProgress.isRunning}
              onClick={() => verifyFileInputRef.current?.click()}
              className="flex min-h-[38px] items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-100"
            >
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-700" />
              <span className="truncate">{strings.verifyBackupBtn}</span>
            </button>
          </div>
        </div>

        {backupProgress.isRunning && (
          <div className="mt-3 rounded-xl border border-blue-100 bg-blue-50 p-2.5 text-xs">
            <div className="flex justify-between font-semibold text-blue-900">
              <span>{backupProgress.stageLabel}</span>
              <span className="tabular-nums">{backupProgress.progressPercent}%</span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-blue-200">
              <div
                className="h-full bg-blue-700 transition-all"
                style={{ width: `${backupProgress.progressPercent}%` }}
              />
            </div>
          </div>
        )}

        {backupFeedback && (
          <div
            className={`mt-3 flex items-start justify-between gap-2 rounded-xl border p-2.5 text-xs ${
              backupFeedback.type === 'success'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                : 'border-rose-200 bg-rose-50 text-rose-900'
            }`}
          >
            <div className="flex items-start gap-1.5">
              {backupFeedback.type === 'success' ? (
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-700" />
              ) : (
                <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-700" />
              )}
              <span className="break-words">{backupFeedback.message}</span>
            </div>
            <button
              type="button"
              onClick={onClearBackupFeedback}
              className="shrink-0 text-[10px] font-bold underline"
            >
              OK
            </button>
          </div>
        )}

        {/* Backup History List */}
        <div className="mt-3.5 border-t border-slate-100 pt-3">
          <div className="mb-2 text-xs font-bold text-slate-800">
            {strings.backupHistoryTitle} ({backupHistory.length})
          </div>
          {backupHistory.length === 0 ? (
            <p className="text-[11px] text-slate-500">{strings.noBackupHistoryText}</p>
          ) : (
            <div className="space-y-2">
              {backupHistory.map((item) => (
                <div
                  key={item.id}
                  className="rounded-xl border border-slate-100 bg-slate-50 p-2.5 text-[11px]"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate font-mono font-bold text-slate-900">
                      {item.fileName}
                    </span>
                    <span
                      className={`shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-bold ${
                        item.fileExists && item.verifiedStatus === 'VERIFIED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {item.fileExists
                        ? strings.backupVerifiedBadge
                        : strings.backupMissingFileBadge}
                    </span>
                  </div>
                  <div className="mt-0.5 text-slate-600 tabular-nums">
                    {item.createdAtIso} · v{item.schemaVersion} · {item.counts.sites} sites ·{' '}
                    {item.counts.workers} workers · {item.counts.expenses} exp
                  </div>
                  <div className="mt-0.5 font-mono text-[10px] text-slate-400">
                    SHA-256: {item.checksumSha256.slice(0, 20)}...
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Language Switcher */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <Globe className="h-4 w-4 text-blue-700" />
          <span>{strings.languageSettingTitle}</span>
        </div>
        <p className="mt-1 text-xs leading-relaxed text-slate-500">
          {strings.languageSettingDesc}
        </p>

        <div className="mt-3 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => onSelectLanguage('en')}
            className={`min-h-[42px] rounded-xl border px-3 py-2 text-xs font-semibold transition-colors ${
              language === 'en'
                ? 'border-blue-700 bg-blue-700 text-white'
                : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
            }`}
          >
            English
          </button>
          <button
            type="button"
            onClick={() => onSelectLanguage('bn')}
            className={`min-h-[42px] rounded-xl border px-3 py-2 text-xs font-semibold transition-colors ${
              language === 'bn'
                ? 'border-blue-700 bg-blue-700 text-white'
                : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
            }`}
          >
            বাংলা (Bengali)
          </button>
        </div>
      </div>

      {/* Role-Based Access Switcher */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <ShieldCheck className="h-4 w-4 text-blue-700" />
          <span>{strings.roleSettingTitle}</span>
        </div>
        <p className="mt-1 text-xs leading-relaxed text-slate-500">
          {strings.roleSettingDesc}
        </p>

        <div className="mt-3 grid grid-cols-3 gap-1.5">
          {ROLES.map((role) => {
            const label =
              language === 'bn'
                ? USER_ROLE_LABELS[role].bn
                : USER_ROLE_LABELS[role].en;
            const selected = activeRole === role;
            return (
              <button
                key={role}
                type="button"
                onClick={() => onSelectRole(role)}
                className={`min-h-[38px] rounded-xl border px-2 py-1.5 text-xs font-semibold transition-colors ${
                  selected
                    ? 'border-blue-700 bg-blue-700 text-white'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>

        <div
          className={`mt-2.5 rounded-xl border px-3 py-2 text-[11px] font-medium ${
            hasSiteAccess
              ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
              : 'border-rose-200 bg-rose-50 text-rose-800'
          }`}
        >
          {activeSite.siteCode} · {activeSite.siteName}:{' '}
          {hasSiteAccess ? strings.backupVerifiedBadge : strings.siteAccessDeniedWarning}
        </div>
      </div>

      {/* Admin Site Duty Multipliers */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <Sliders className="h-4 w-4 text-blue-700" />
          <span>
            {strings.dutyMultiplierSettingTitle} ({activeSite.siteCode})
          </span>
        </div>
        <p className="mt-1 text-xs leading-relaxed text-slate-500">
          {strings.dutyMultiplierSettingDesc}
        </p>

        <form onSubmit={handleSaveMultipliers} className="mt-3 space-y-2.5">
          <div className="grid grid-cols-2 gap-2">
            <MultiplierField
              label={strings.halfDutyLabel}
              value={halfText}
              disabled={!isAdmin}
              onChange={setHalfText}
            />
            <MultiplierField
              label={strings.fullDutyLabel}
              value={fullText}
              disabled={!isAdmin}
              onChange={setFullText}
            />
            <MultiplierField
              label={strings.oneAndHalfDutyLabel}
              value={oneAndHalfText}
              disabled={!isAdmin}
              onChange={setOneAndHalfText}
            />
            <MultiplierField
              label={strings.doubleDutyLabel}
              value={doubleText}
              disabled={!isAdmin}
              onChange={setDoubleText}
            />
            <MultiplierField
              label={strings.twoAndHalfDutyLabel}
              value={twoAndHalfText}
              disabled={!isAdmin}
              onChange={setTwoAndHalfText}
            />
            <MultiplierField
              label={strings.tripleDutyLabel}
              value={tripleText}
              disabled={!isAdmin}
              onChange={setTripleText}
            />
            <MultiplierField
              label={strings.absentLabel}
              value={absentText}
              disabled={!isAdmin}
              onChange={setAbsentText}
            />
            <MultiplierField
              label={strings.leaveLabel}
              value={leaveText}
              disabled={!isAdmin}
              onChange={setLeaveText}
            />
          </div>

          {!isAdmin && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
              {strings.adminOnlyWarning}
            </div>
          )}

          {savedNotice && (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-medium text-emerald-800">
              {strings.multipliersSavedNotice}
            </div>
          )}

          <button
            type="submit"
            disabled={!isAdmin}
            className="flex min-h-[40px] w-full items-center justify-center rounded-xl bg-blue-700 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-800 disabled:bg-slate-300"
          >
            {strings.saveMultipliers}
          </button>
        </form>
      </div>

      {/* Offline SQLite & Reset */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <Database className="h-4 w-4 text-blue-700" />
          <span>{strings.dataStageNoticeTitle}</span>
        </div>
        <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
          {strings.dataStageNoticeBody}
        </p>
        <button
          type="button"
          onClick={onResetSampleData}
          className="mt-3 flex min-h-[40px] items-center gap-2 rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-50"
        >
          <RotateCcw className="h-3.5 w-3.5 text-blue-700" />
          <span>{strings.resetSampleData}</span>
        </button>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <WifiOff className="h-4 w-4 text-blue-700" />
          <span>{strings.offlineReadyTitle}</span>
        </div>
        <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
          {strings.offlineReadyBody}
        </p>
      </div>

      {/* Restore Validation & Safety Confirmation Modal */}
      {pendingRestore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="max-h-[90vh] w-full max-w-sm overflow-y-auto rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ArchiveRestore className="h-4 w-4 text-blue-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  {strings.restoreConfirmTitle}
                </h3>
              </div>
              <button
                type="button"
                onClick={onDismissPendingRestore}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-3 space-y-2 text-xs">
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-1">
                <div className="font-mono font-bold text-slate-900 break-all">
                  {pendingRestore.fileName}
                </div>
                <div className="text-slate-600 tabular-nums">
                  Created: {pendingRestore.createdAtIso || '-'} · Schema v
                  {pendingRestore.schemaVersion}
                </div>
                <div className="font-mono text-[10px] text-slate-500">
                  SHA-256: {pendingRestore.checksumSha256.slice(0, 28)}...
                </div>
                <div className="pt-1 font-semibold text-slate-800 tabular-nums">
                  Sites: {pendingRestore.counts.sites} · Workers:{' '}
                  {pendingRestore.counts.workers} · Att:{' '}
                  {pendingRestore.counts.attendanceRecords} · Exp:{' '}
                  {pendingRestore.counts.expenses} · Photos:{' '}
                  {pendingRestore.counts.workerPhotos +
                    pendingRestore.counts.receiptImages}
                </div>
              </div>

              {pendingRestore.isOlderThanCurrentData && (
                <div className="flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 p-2.5 text-amber-900">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-700" />
                  <span>{strings.restoreOlderWarning}</span>
                </div>
              )}

              {pendingRestore.errors.length > 0 ? (
                <div className="rounded-xl border border-rose-300 bg-rose-50 p-2.5 text-rose-900">
                  {pendingRestore.errors.map((err) => (
                    <div key={err}>• {err}</div>
                  ))}
                </div>
              ) : (
                <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-2.5 text-emerald-900">
                  {strings.restoreSafetyNotice}
                </div>
              )}
            </div>

            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={onDismissPendingRestore}
                className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                {strings.cancel}
              </button>
              <button
                type="button"
                disabled={!pendingRestore.isValid}
                onClick={onConfirmRestore}
                className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 disabled:bg-slate-300"
              >
                {strings.confirmAction}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MultiplierField({
  label,
  value,
  disabled,
  onChange,
}: {
  label: string;
  value: string;
  disabled: boolean;
  onChange: (val: string) => void;
}) {
  return (
    <div>
      <label className="block text-[11px] font-medium text-slate-600">{label}</label>
      <input
        type="number"
        step="0.1"
        min="0"
        disabled={disabled}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 h-9 w-full rounded-lg border border-slate-300 px-2.5 text-xs tabular-nums disabled:bg-slate-100 disabled:text-slate-500 focus:border-blue-600 focus:outline-none"
      />
    </div>
  );
}
