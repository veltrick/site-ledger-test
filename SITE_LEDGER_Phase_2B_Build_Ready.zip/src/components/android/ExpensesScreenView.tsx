import { useMemo, useRef, useState } from 'react';
import {
  Camera,
  Edit3,
  Eye,
  Info,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import {
  BilingualUiStrings,
  EXPENSE_METHOD_LABELS,
} from '../../data/bilingualStrings';
import {
  AppLanguage,
  ExpenseCategory,
  ExpensePaymentMethod,
  Site,
  SiteExpense,
  UserRole,
} from '../../types/siteLedger';
import { processPickedReceiptPhoto } from '../../utils/imageResize';

interface ExpensesScreenViewProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  activeRole: UserRole;
  activeSite: Site;
  categories: ExpenseCategory[];
  expenses: SiteExpense[];
  onSaveExpense: (expense: SiteExpense) => void;
  onVoidExpense: (expenseId: string, reason: string) => void;
  onAddCategory: (nameEn: string, nameBn: string) => void;
}

export function ExpensesScreenView({
  strings,
  language,
  activeRole,
  activeSite,
  categories,
  expenses,
  onSaveExpense,
  onVoidExpense,
  onAddCategory,
}: ExpensesScreenViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilterId, setCategoryFilterId] = useState<string>('ALL');
  const [monthFilter, setMonthFilter] = useState<string>('ALL');
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [editingExpense, setEditingExpense] = useState<SiteExpense | null>(null);
  const [showAddCategoryModal, setShowAddCategoryModal] = useState(false);
  const [voidTarget, setVoidTarget] = useState<SiteExpense | null>(null);
  const [previewReceiptExpense, setPreviewReceiptExpense] = useState<SiteExpense | null>(null);

  const canVoid = activeRole !== 'MANAGER';
  const canAddCategory = activeRole === 'ADMIN';

  const categoryMap = useMemo(
    () => new Map(categories.map((c) => [c.id, c])),
    [categories]
  );

  const availableMonths = useMemo(() => {
    const months = new Set<string>(['2026-11', '2026-10']);
    for (const e of expenses) {
      if (e.expenseDateIso.length >= 7) months.add(e.expenseDateIso.slice(0, 7));
    }
    return Array.from(months).sort((a, b) => b.localeCompare(a));
  }, [expenses]);

  const filteredExpenses = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return expenses.filter((e) => {
      if (categoryFilterId !== 'ALL' && e.categoryId !== categoryFilterId) return false;
      if (monthFilter !== 'ALL' && !e.expenseDateIso.startsWith(monthFilter)) return false;
      if (!q) return true;
      return (
        e.title.toLowerCase().includes(q) ||
        e.vendorName.toLowerCase().includes(q) ||
        e.referenceNo.toLowerCase().includes(q) ||
        e.notes.toLowerCase().includes(q)
      );
    });
  }, [expenses, categoryFilterId, monthFilter, searchQuery]);

  const activeItems = useMemo(
    () => filteredExpenses.filter((e) => !e.isVoided),
    [filteredExpenses]
  );
  const totalGeneralExpenses = useMemo(
    () => activeItems.reduce((sum, e) => sum + e.amount, 0),
    [activeItems]
  );

  return (
    <div className="space-y-3.5 p-4">
      <div className="flex items-start gap-2.5 rounded-xl border border-blue-200 bg-blue-50/70 px-3 py-2 text-xs text-blue-950">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-blue-700" />
        <span>
          {activeSite.siteCode} · {activeSite.siteName} — {strings.expensesTitle}
        </span>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-base font-bold text-slate-900">{strings.expensesTitle}</h2>
        <div className="flex items-center gap-1.5">
          {canAddCategory && (
            <button
              type="button"
              onClick={() => setShowAddCategoryModal(true)}
              className="flex min-h-[36px] items-center rounded-xl border border-slate-300 bg-white px-2.5 py-1.5 text-[11px] font-semibold text-slate-700 hover:bg-slate-50"
            >
              {strings.addCategoryBtn}
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              setEditingExpense(null);
              setShowExpenseModal(true);
            }}
            className="flex min-h-[36px] items-center gap-1 rounded-xl bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-800"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>{strings.addExpenseBtn}</span>
          </button>
        </div>
      </div>

      {/* General Expenses Summary Card */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex items-baseline justify-between gap-2">
          <div>
            <div className="text-xs font-medium text-slate-500">
              {strings.totalGeneralExpensesLabel}
            </div>
            <div className="mt-1 text-2xl font-bold text-amber-700 tabular-nums">
              ৳{totalGeneralExpenses.toLocaleString('en-US')}
            </div>
          </div>
          <div className="text-right text-[11px] font-semibold text-slate-500 tabular-nums">
            {activeItems.length} vouchers
          </div>
        </div>
        <div className="mt-1.5 text-[11px] text-slate-500">
          {language === 'bn'
            ? 'সাধারণ সাইট খরচ কর্মীদের মজুরি/বেতন থেকে আলাদাভাবে হিসাব করা হয়।'
            : 'General site overhead is tracked separately from worker wages and payroll.'}
        </div>
      </div>

      {/* Search & Month Filter */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={strings.searchWorkersPlaceholder}
            className="h-9 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
          />
        </div>
        <select
          value={monthFilter}
          onChange={(e) => setMonthFilter(e.target.value)}
          className="h-9 rounded-xl border border-slate-200 bg-white px-2.5 text-xs font-semibold text-slate-800 focus:border-blue-600 focus:outline-none"
        >
          <option value="ALL">{strings.allFilter}</option>
          {availableMonths.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>
      </div>

      {/* Category Filter Strip */}
      <div className="thin-scroll flex gap-1.5 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setCategoryFilterId('ALL')}
          className={`shrink-0 rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition-colors ${
            categoryFilterId === 'ALL'
              ? 'border-blue-700 bg-blue-700 text-white'
              : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
          }`}
        >
          {strings.allFilter}
        </button>
        {categories.map((cat) => {
          const active = categoryFilterId === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategoryFilterId(cat.id)}
              className={`shrink-0 rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition-colors whitespace-nowrap ${
                active
                  ? 'border-blue-700 bg-blue-700 text-white'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
              }`}
            >
              {language === 'bn' ? cat.nameBn : cat.nameEn}
            </button>
          );
        })}
      </div>

      {/* Expenses List */}
      {filteredExpenses.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center text-xs text-slate-500">
          {strings.notRecordedLabel}
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredExpenses.map((exp) => {
            const cat = categoryMap.get(exp.categoryId);
            const catLabel = cat
              ? language === 'bn'
                ? cat.nameBn
                : cat.nameEn
              : exp.categoryId;
            const methodLabel =
              language === 'bn'
                ? EXPENSE_METHOD_LABELS[exp.paymentMethod].bn
                : EXPENSE_METHOD_LABELS[exp.paymentMethod].en;

            return (
              <div
                key={exp.id}
                className="rounded-2xl border border-slate-200 bg-white p-3.5"
              >
                <div className="flex items-start justify-between gap-2.5">
                  <div className="min-w-0 flex-1">
                    <div
                      className={`text-sm font-semibold ${
                        exp.isVoided ? 'text-slate-400 line-through' : 'text-slate-900'
                      }`}
                    >
                      {exp.title}
                    </div>
                    <div className="mt-0.5 text-[11px] font-semibold text-blue-800">
                      {catLabel} · {exp.expenseDateIso} · {methodLabel}
                    </div>
                    {(exp.vendorName || exp.referenceNo) && (
                      <div className="mt-0.5 text-[11px] text-slate-500">
                        {exp.vendorName || '-'}
                        {exp.referenceNo ? ` · ${exp.referenceNo}` : ''}
                      </div>
                    )}
                    {exp.notes && (
                      <div className="mt-0.5 text-[11px] text-slate-500">{exp.notes}</div>
                    )}
                    {exp.receiptPath && (
                      <button
                        type="button"
                        onClick={() => setPreviewReceiptExpense(exp)}
                        className="mt-1 inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 hover:underline"
                      >
                        <Eye className="h-3 w-3" />
                        <span>{exp.receiptPath.split('/').pop()}</span>
                      </button>
                    )}
                  </div>

                  <div className="shrink-0 text-right">
                    <div
                      className={`text-sm font-bold tabular-nums ${
                        exp.isVoided ? 'text-rose-700' : 'text-slate-900'
                      }`}
                    >
                      {exp.isVoided ? strings.voidedLabel : `৳${exp.amount.toLocaleString('en-US')}`}
                    </div>
                    {!exp.isVoided && (
                      <div className="mt-1 flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingExpense(exp);
                            setShowExpenseModal(true);
                          }}
                          className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-blue-700"
                          aria-label={strings.editExpenseBtn}
                        >
                          <Edit3 className="h-3.5 w-3.5" />
                        </button>
                        {canVoid && (
                          <button
                            type="button"
                            onClick={() => setVoidTarget(exp)}
                            className="text-[11px] font-semibold text-rose-700 hover:underline"
                          >
                            {strings.voidTransaction}
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Expense Modal */}
      {showExpenseModal && (
        <ExpenseFormModal
          strings={strings}
          language={language}
          activeRole={activeRole}
          activeSiteId={activeSite.id}
          categories={categories}
          initialExpense={editingExpense}
          onClose={() => {
            setShowExpenseModal(false);
            setEditingExpense(null);
          }}
          onConfirm={(exp) => {
            onSaveExpense(exp);
            setShowExpenseModal(false);
            setEditingExpense(null);
          }}
        />
      )}

      {/* Add Custom Category Modal (Admin Only) */}
      {showAddCategoryModal && (
        <AddCategoryModal
          strings={strings}
          onClose={() => setShowAddCategoryModal(false)}
          onConfirm={(nameEn, nameBn) => {
            onAddCategory(nameEn, nameBn);
            setShowAddCategoryModal(false);
          }}
        />
      )}

      {/* Void Confirmation Modal */}
      {voidTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <h3 className="text-sm font-bold text-slate-900">{strings.voidTransaction}</h3>
            <p className="mt-2 text-xs leading-relaxed text-slate-600">
              {strings.confirmVoidExpenseMsg}
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setVoidTarget(null)}
                className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                {strings.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  onVoidExpense(voidTarget.id, 'Voided from Site Expenses');
                  setVoidTarget(null);
                }}
                className="min-h-[38px] rounded-xl bg-rose-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-rose-800"
              >
                {strings.confirmAction}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Receipt Preview Modal */}
      {previewReceiptExpense && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="text-xs font-bold text-slate-900">
                {previewReceiptExpense.title}
              </h3>
              <button
                type="button"
                onClick={() => setPreviewReceiptExpense(null)}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            {previewReceiptExpense.receiptDataUrl ? (
              <img
                src={previewReceiptExpense.receiptDataUrl}
                alt={previewReceiptExpense.title}
                className="mt-3 max-h-72 w-full rounded-xl border border-slate-200 object-contain"
              />
            ) : (
              <p className="mt-3 text-xs text-slate-500">
                {previewReceiptExpense.receiptPath}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function ExpenseFormModal({
  strings,
  language,
  activeRole,
  activeSiteId,
  categories,
  initialExpense,
  onClose,
  onConfirm,
}: {
  strings: BilingualUiStrings;
  language: AppLanguage;
  activeRole: UserRole;
  activeSiteId: string;
  categories: ExpenseCategory[];
  initialExpense: SiteExpense | null;
  onClose: () => void;
  onConfirm: (expense: SiteExpense) => void;
}) {
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [expenseId] = useState(
    () => initialExpense?.id ?? `EXP-${Math.floor(400 + Math.random() * 599)}`
  );
  const [title, setTitle] = useState(initialExpense?.title ?? '');
  const [categoryId, setCategoryId] = useState(
    initialExpense?.categoryId ?? categories[0]?.id ?? 'CAT-MATERIALS'
  );
  const [expenseDateIso, setExpenseDateIso] = useState(
    initialExpense?.expenseDateIso ?? '2026-11-15'
  );
  const [amount, setAmount] = useState(
    initialExpense ? String(initialExpense.amount) : ''
  );
  const [vendorName, setVendorName] = useState(initialExpense?.vendorName ?? '');
  const [paymentMethod, setPaymentMethod] = useState<ExpensePaymentMethod>(
    initialExpense?.paymentMethod ?? 'CASH'
  );
  const [referenceNo, setReferenceNo] = useState(initialExpense?.referenceNo ?? '');
  const [notes, setNotes] = useState(initialExpense?.notes ?? '');
  const [receiptPath, setReceiptPath] = useState<string | null>(
    initialExpense?.receiptPath ?? null
  );
  const [receiptDataUrl, setReceiptDataUrl] = useState<string | null>(
    initialExpense?.receiptDataUrl ?? null
  );

  const handleReceiptPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const processed = await processPickedReceiptPhoto(file, expenseId);
    setReceiptDataUrl(processed.dataUrl);
    setReceiptPath(processed.relativePath);
    e.target.value = '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmt = Math.trunc(Number(amount));
    if (!title.trim() || !Number.isFinite(numericAmt) || numericAmt <= 0) return;

    onConfirm({
      id: expenseId,
      siteId: activeSiteId,
      expenseDateIso: expenseDateIso || '2026-11-15',
      categoryId,
      title: title.trim(),
      amount: numericAmt,
      vendorName: vendorName.trim(),
      paymentMethod,
      referenceNo: referenceNo.trim(),
      notes: notes.trim(),
      receiptPath,
      receiptDataUrl,
      recordedByRole: initialExpense?.recordedByRole ?? activeRole,
      createdAtIso:
        initialExpense?.createdAtIso || new Date().toISOString().slice(0, 19),
      isVoided: initialExpense?.isVoided ?? false,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
      <div className="max-h-[90vh] w-full max-w-sm overflow-y-auto rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            {initialExpense ? strings.editExpenseBtn : strings.addExpenseBtn}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-3 space-y-2.5">
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Title / Description..."
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm focus:border-blue-600 focus:outline-none"
          />

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-medium text-slate-600">
                {strings.paymentAmountLabel}
              </label>
              <input
                type="number"
                min={1}
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="mt-1 h-9 w-full rounded-xl border border-slate-300 px-2.5 text-sm tabular-nums focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[11px] font-medium text-slate-600">
                {strings.selectDate}
              </label>
              <input
                type="date"
                value={expenseDateIso}
                onChange={(e) => setExpenseDateIso(e.target.value)}
                className="mt-1 h-9 w-full rounded-xl border border-slate-300 px-2 text-xs focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-600">
              {strings.expenseCategoryLabel}
            </label>
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="mt-1 h-9 w-full rounded-xl border border-slate-300 bg-white px-2.5 text-xs font-semibold"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {language === 'bn' ? c.nameBn : c.nameEn}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-600">
              {strings.expenseMethodLabel}
            </label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value as ExpensePaymentMethod)}
              className="mt-1 h-9 w-full rounded-xl border border-slate-300 bg-white px-2.5 text-xs font-semibold"
            >
              {(['CASH', 'BANK', 'MOBILE_BANKING'] as ExpensePaymentMethod[]).map((m) => (
                <option key={m} value={m}>
                  {language === 'bn'
                    ? EXPENSE_METHOD_LABELS[m].bn
                    : EXPENSE_METHOD_LABELS[m].en}
                </option>
              ))}
            </select>
          </div>

          <input
            type="text"
            value={vendorName}
            onChange={(e) => setVendorName(e.target.value)}
            placeholder={strings.expenseVendorLabel}
            className="h-9 w-full rounded-xl border border-slate-300 px-3 text-xs focus:border-blue-600 focus:outline-none"
          />
          <input
            type="text"
            value={referenceNo}
            onChange={(e) => setReferenceNo(e.target.value)}
            placeholder={strings.referenceNoLabel}
            className="h-9 w-full rounded-xl border border-slate-300 px-3 text-xs focus:border-blue-600 focus:outline-none"
          />
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder={strings.notesLabel}
            className="h-9 w-full rounded-xl border border-slate-300 px-3 text-xs focus:border-blue-600 focus:outline-none"
          />

          {/* Private Receipt Photo Picker */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              onChange={handleReceiptPick}
              className="hidden"
            />
            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="flex min-h-[34px] items-center gap-1.5 rounded-lg border border-blue-200 bg-white px-2.5 py-1 text-xs font-semibold text-blue-700 hover:bg-blue-50"
              >
                <Camera className="h-3.5 w-3.5" />
                <span>{strings.receiptPhotoLabel}</span>
              </button>
              {receiptPath && (
                <button
                  type="button"
                  onClick={() => {
                    setReceiptPath(null);
                    setReceiptDataUrl(null);
                  }}
                  className="flex items-center gap-1 text-[11px] font-semibold text-rose-700"
                >
                  <Trash2 className="h-3 w-3" />
                  <span>{strings.removePhoto}</span>
                </button>
              )}
            </div>
            {receiptDataUrl && (
              <div className="mt-2 flex items-center gap-2">
                <img
                  src={receiptDataUrl}
                  alt={strings.receiptPhotoLabel}
                  className="h-12 w-12 rounded-lg border border-slate-200 object-cover"
                />
                <span className="truncate font-mono text-[10px] text-emerald-700">
                  {receiptPath}
                </span>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              {strings.cancel}
            </button>
            <button
              type="submit"
              className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            >
              {strings.saveEntry}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AddCategoryModal({
  strings,
  onClose,
  onConfirm,
}: {
  strings: BilingualUiStrings;
  onClose: () => void;
  onConfirm: (nameEn: string, nameBn: string) => void;
}) {
  const [nameEn, setNameEn] = useState('');
  const [nameBn, setNameBn] = useState('');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
        <h3 className="text-sm font-bold text-slate-900">{strings.addCategoryBtn}</h3>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!nameEn.trim()) return;
            onConfirm(nameEn.trim(), nameBn.trim() || nameEn.trim());
          }}
          className="mt-3 space-y-2.5"
        >
          <input
            type="text"
            required
            value={nameEn}
            onChange={(e) => setNameEn(e.target.value)}
            placeholder="Category Name (English)"
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
          />
          <input
            type="text"
            value={nameBn}
            onChange={(e) => setNameBn(e.target.value)}
            placeholder="খাতের নাম (বাংলা)"
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
          />
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600"
            >
              {strings.cancel}
            </button>
            <button
              type="submit"
              className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white"
            >
              {strings.confirmAction}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
