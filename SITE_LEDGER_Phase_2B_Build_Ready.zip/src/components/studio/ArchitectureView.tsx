import { ArchiveRestore, Building2, Calculator, Database, FolderTree, Languages, ShieldCheck } from 'lucide-react';

export function ArchitectureView() {
  const packages = [
    {
      path: 'domain/model/Models.kt',
      desc: 'Multi-site & backup domain models: Site, SiteStatus, Worker (global id + localWorkerCode), WorkerSiteHistory, ExpenseCategory, SiteExpense, ExpenseAuditEntry, BackupManifest, BackupHistoryRecord, SyncEvent.',
    },
    {
      path: 'domain/service/WageCalculator.kt',
      desc: 'Exact integer hundredths calculation engine (Daily Wage × Duty Multiplier = Integer Taka), site-isolated & all-sites consolidated payroll summaries, separated General Site Expenses, and worker transfer balances.',
    },
    {
      path: 'data/local/SiteLedgerDatabaseContract.kt',
      desc: 'SQLite schema v6 adding sites, worker_site_history, expense_categories, expenses, expense_audits, user_site_assignments, backup_history, and sync_events with composite site_id indexes.',
    },
    {
      path: 'data/local/SiteLedgerSqliteOpenHelper.kt',
      desc: 'Non-destructive SQLiteOpenHelper upgrading v1 → v2 → v3 → v4 → v5 → v6: creates SITE-MAIN baseline, backfills site_id on all legacy records, preserves worker photos, attendance, payments, advances & locks.',
    },
    {
      path: 'data/backup/OfflineBackupManager.kt',
      desc: 'Phase 2 offline ZIP backup & atomic restore: WAL-checkpointed SQLite binary copy, worker_photos/ & receipt_images/, backup_manifest.json with SHA-256 checksums, safety pre-restore backup, and automatic rollback.',
    },
    {
      path: 'ui/screens/ExpensesScreen.kt & SitesManagementScreen.kt',
      desc: 'General Site Expenses ledger (9 default + Admin categories, camera/gallery receipts, void audit trail) & Multi-Site management with Admin site transfers and RBAC assignments.',
    },
    {
      path: 'ui/screens/PayrollSpreadsheetScreen.kt',
      desc: 'Master Payroll Spreadsheet with Active Site vs All Sites consolidated toggle, Site badge column, 50 rows/page pagination, bottom Totals row, and per-site Finalize/Reopen controls.',
    },
    {
      path: 'test/java/com/siteledger/app/MultiSiteAndBackupTest.kt',
      desc: 'Phase 2 & 3 unit verification covering site isolation, duplicate localWorkerCode per site, worker transfer history preservation, expenses separation, and SHA-256 backup/restore verification.',
    },
  ];

  const tables = [
    {
      name: 'sites & user_site_assignments (v6)',
      columns:
        'sites(site_id PK, site_name, site_code, address, client_name, site_manager, start_date_iso, status ACTIVE/PAUSED/COMPLETED/ARCHIVED, notes) · user_site_assignments(user_id PK, display_name, role, assigned_site_ids, can_manage_all_sites)',
    },
    {
      name: 'workers & worker_site_history (v6)',
      columns:
        'workers(worker_id PK, site_id, local_worker_code, full_name_en, full_name_bn, phone_number, work_category, daily_wage, photo_path) [UNIQUE(site_id, local_worker_code)] · worker_site_history(history_id PK, worker_id, from_site_id, to_site_id, transfer_date_iso)',
    },
    {
      name: 'attendance_records & attendance_audit_log (v6)',
      columns:
        'attendance_records(date_iso PK, worker_id PK, site_id, duty_type, daily_wage_snapshot, multiplier_snapshot, earned_amount) · attendance_audit_log(audit_id PK, site_id, worker_id, previous_duty_type, new_duty_type, reason)',
    },
    {
      name: 'payment_ledger, advances & payment_allocations (v6)',
      columns:
        'payment_ledger(entry_id PK, site_id, worker_id, applicable_period, paid_amount, is_voided) · advances(advance_id PK, site_id, worker_id, amount) · payment_allocations(allocation_id PK, site_id, source_type, source_id, payroll_period, allocated_amount)',
    },
    {
      name: 'expense_categories, expenses & expense_audit_log (v6)',
      columns:
        'expense_categories(category_id PK, name_en, name_bn, is_system_default) · expenses(expense_id PK, site_id, expense_date_iso, category_id, title, amount, payment_method, receipt_path, is_voided) · expense_audit_log(audit_id PK, expense_id, site_id, action)',
    },
    {
      name: 'payroll_periods, duty_settings, backup_history & sync_events (v6)',
      columns:
        'payroll_periods(site_id PK, period_iso PK, status OPEN/FINALIZED) · duty_settings(site_id PK, 8 multipliers) · backup_history(backup_id PK, checksum_sha256, file_size_bytes) · sync_events(event_id PK, entity_type, site_id, sync_status)',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-5">
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
            <Building2 className="h-4 w-4 text-blue-700" />
            <span>Multi-Site Isolation</span>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-slate-600">
            Active site switcher, per-site RBAC, per-site unique worker codes, and lossless Admin
            site transfers preserving historical earnings.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
            <Calculator className="h-4 w-4 text-blue-700" />
            <span>Payroll vs Expenses</span>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-slate-600">
            General Site Expenses (cement, food, transport, rentals + receipts) are cleanly separated
            from worker salary ledgers and 8-tier duty math.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
            <ArchiveRestore className="h-4 w-4 text-blue-700" />
            <span>Offline ZIP Backups</span>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-slate-600">
            SHA-256 verified ZIP containing WAL-checkpointed SQLite DB, worker photos, receipts,
            pre-restore safety snapshot, and atomic rollback.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
            <Languages className="h-4 w-4 text-blue-700" />
            <span>বাংলা &amp; English</span>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-slate-600">
            Bilingual labels across multi-site ledgers, expense categories, backup verification,
            spreadsheet exports, and Android Compose UI.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
            <ShieldCheck className="h-4 w-4 text-blue-700" />
            <span>Sync-Ready &amp; Offline</span>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-slate-600">
            100% offline-first storage with Admin payroll locks, audit logs, and local sync_events
            mutation queue for future optional sync.
          </p>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6">
        <h2 className="text-base font-bold text-slate-900">Modular Android Package Structure</h2>
        <div className="mt-4 divide-y divide-slate-100">
          {packages.map((pkg) => (
            <div
              key={pkg.path}
              className="flex flex-col gap-1 py-3 md:flex-row md:items-baseline md:gap-6"
            >
              <code className="shrink-0 font-mono text-xs font-semibold text-blue-800 md:w-80">
                {pkg.path}
              </code>
              <p className="text-xs leading-relaxed text-slate-600">{pkg.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center gap-2 text-base font-bold text-slate-900">
          <Database className="h-4 w-4 text-blue-700" />
          <span>Offline SQLite Schema (Version 6 · Multi-Site &amp; Expenses Upgrade)</span>
        </div>
        <p className="mt-1 text-xs text-slate-500">
          Non-destructive upgrade v1 → v2 → v3 → v4 → v5 → v6 migrates existing records onto
          SITE-MAIN, preserving all workers, private photo paths, attendance, payments, advances,
          and payroll locks while adding multi-site isolation, general expenses, and backup tracking.
        </p>
        <div className="mt-4 space-y-3">
          {tables.map((t) => (
            <div key={t.name} className="rounded-xl border border-slate-200 bg-slate-50 p-3.5">
              <div className="font-mono text-xs font-bold text-slate-900">{t.name}</div>
              <div className="mt-1 font-mono text-xs text-slate-600">{t.columns}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
