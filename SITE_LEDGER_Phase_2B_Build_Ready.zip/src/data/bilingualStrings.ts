import {
  AppLanguage,
  DutyType,
  ExpensePaymentMethod,
  PayrollPeriodStatus,
  SiteStatus,
  UserRole,
  WorkCategory,
  WorkerPayrollStatus,
} from '../types/siteLedger';

export interface BilingualUiStrings {
  appName: string;
  appSubtitle: string;
  sampleDataNotice: string;
  navDashboard: string;
  navWorkers: string;
  navAttendance: string;
  navSpreadsheet: string;
  navPayments: string;
  navExpenses: string;
  navReports: string;
  navSites: string;
  navSettings: string;
  totalWorkers: string;
  presentToday: string;
  absentToday: string;
  todaysPayments: string;
  monthlyExpenses: string;
  generalExpensesCardLabel: string;
  paidPayrollCardLabel: string;
  outstandingPayrollCardLabel: string;
  siteOverviewTitle: string;
  quickActionsTitle: string;
  searchWorkersPlaceholder: string;
  addWorker: string;
  editWorker: string;
  workerProfile: string;
  transferWorkerBtn: string;
  transferWorkerTitle: string;
  targetSiteLabel: string;
  transferNoteLabel: string;
  siteTransferHistoryTitle: string;
  duplicateLocalCodeError: string;
  fullNameLabel: string;
  workerIdLabel: string;
  phoneNumberLabel: string;
  categoryLabel: string;
  joiningDateLabel: string;
  leavingDateLabel: string;
  dailyWageLabel: string;
  foodAllowanceLabel: string;
  activeStatus: string;
  inactiveStatus: string;
  statusLabel: string;
  allFilter: string;
  sortLabel: string;
  sortByName: string;
  sortById: string;
  sortByCategory: string;
  sortByEarnings: string;
  sortByPaid: string;
  sortByOutstanding: string;
  saveWorker: string;
  saveChanges: string;
  cancel: string;
  close: string;
  confirmAction: string;
  addPhoto: string;
  replacePhoto: string;
  removePhoto: string;
  photoPreviewNotice: string;
  noPhotoPlaceholderText: string;
  profileTabOverview: string;
  profileTabAttendance: string;
  profileTabPayrollHistory: string;
  profileTabPayments: string;
  profileTabPersonal: string;
  totalCalendarDays: string;
  halfDutyLabel: string;
  fullDutyLabel: string;
  oneAndHalfDutyLabel: string;
  doubleDutyLabel: string;
  twoAndHalfDutyLabel: string;
  tripleDutyLabel: string;
  absentLabel: string;
  leaveLabel: string;
  notRecordedLabel: string;
  totalDutyUnits: string;
  totalEarnedAmount: string;
  totalPaidAmount: string;
  advanceAppliedLabel: string;
  unallocatedAdvancesLabel: string;
  remainingBalance: string;
  payrollStatusLabel: string;
  currentMonthPayrollTitle: string;
  earnedUpToTodayLabel: string;
  estimatedMonthEndLabel: string;
  estimateDisclaimer: string;
  monthlyBreakdownTitle: string;
  selectedDateDetails: string;
  dutyTypeLabel: string;
  dutyMultiplierLabel: string;
  savedDailyWageLabel: string;
  dutyUnitsLabel: string;
  earnedAmountLabel: string;
  notesLabel: string;
  lastUpdatedLabel: string;
  auditHistoryTitle: string;
  recordOrEditAttendance: string;
  confirmEditAttendanceMsg: string;
  confirmVoidPaymentMsg: string;
  selectDate: string;
  selectMonth: string;
  selectYear: string;
  paymentLedgerTitle: string;
  recordPayment: string;
  recordAdvanceBtn: string;
  allocateAdvanceBtn: string;
  applicablePeriodLabel: string;
  paymentDateLabel: string;
  fullPaymentBtn: string;
  partialPaymentBtn: string;
  referenceNoLabel: string;
  transactionHistory: string;
  selectWorker: string;
  paymentAmountLabel: string;
  paymentNoteLabel: string;
  saveEntry: string;
  voidTransaction: string;
  voidedLabel: string;
  payrollSpreadsheetTitle: string;
  allSitesToggleLabel: string;
  activeSiteToggleLabel: string;
  siteColumnLabel: string;
  totalsRowLabel: string;
  finalizePayrollBtn: string;
  reopenPayrollBtn: string;
  payrollFinalizedBadge: string;
  payrollOpenBadge: string;
  payrollLockedWarning: string;
  confirmFinalizeMsg: string;
  confirmReopenMsg: string;
  exportExcelBtn: string;
  exportAllPdfBtn: string;
  exportWorkerPdfBtn: string;
  printAttendanceBtn: string;
  exportSuccessNotice: string;
  dailySiteAttendance: string;
  dailyTotalDutyUnits: string;
  monthlySiteSummary: string;
  yearlyPayrollSummary: string;
  monthlyTotalEarned: string;
  monthlyTotalPaid: string;
  monthlyOutstanding: string;
  workerWiseReportTitle: string;
  roleSettingTitle: string;
  roleSettingDesc: string;
  dutyMultiplierSettingTitle: string;
  dutyMultiplierSettingDesc: string;
  saveMultipliers: string;
  multipliersSavedNotice: string;
  adminOnlyWarning: string;
  roleRestrictedAction: string;
  overpaymentWarning: string;
  noMonthAttendanceWarning: string;
  languageSettingTitle: string;
  languageSettingDesc: string;
  dataStageNoticeTitle: string;
  dataStageNoticeBody: string;
  resetSampleData: string;
  offlineReadyTitle: string;
  offlineReadyBody: string;
  noWorkersFound: string;
  perDaySuffix: string;
  // Phase 2 — Backup & Restore
  backupSectionTitle: string;
  backupSectionDesc: string;
  createFullBackupBtn: string;
  restoreFromBackupBtn: string;
  verifyBackupBtn: string;
  backupHistoryTitle: string;
  noBackupHistoryText: string;
  restoreConfirmTitle: string;
  restoreOlderWarning: string;
  restoreSafetyNotice: string;
  backupVerifiedBadge: string;
  backupMissingFileBadge: string;
  // Phase 3 — Multi-Site & Expenses
  activeSiteLabel: string;
  sitesOverviewTitle: string;
  addSiteBtn: string;
  editSiteBtn: string;
  siteNameLabel: string;
  siteCodeLabel: string;
  siteAddressLabel: string;
  clientNameLabel: string;
  siteManagerLabel: string;
  archiveSiteBtn: string;
  sitePermissionsTitle: string;
  siteAccessDeniedWarning: string;
  expensesTitle: string;
  addExpenseBtn: string;
  editExpenseBtn: string;
  addCategoryBtn: string;
  expenseCategoryLabel: string;
  expenseVendorLabel: string;
  expenseMethodLabel: string;
  receiptPhotoLabel: string;
  totalGeneralExpensesLabel: string;
  confirmVoidExpenseMsg: string;
}

export const BILINGUAL_STRINGS: Record<AppLanguage, BilingualUiStrings> = {
  en: {
    appName: 'SITE LEDGER',
    appSubtitle: 'Multi-Site Construction Workforce & Expense Management',
    sampleDataNotice:
      'Offline v6 · Multi-Site Isolation, General Site Expenses & Verified ZIP Backups',
    navDashboard: 'Dashboard',
    navWorkers: 'Workers',
    navAttendance: 'Attendance',
    navSpreadsheet: 'Payroll Sheet',
    navPayments: 'Payments',
    navExpenses: 'Expenses',
    navReports: 'Reports',
    navSites: 'Sites',
    navSettings: 'Settings',
    totalWorkers: 'Total Workers',
    presentToday: 'Present Today',
    absentToday: 'Absent Today',
    todaysPayments: "Today's Payments",
    monthlyExpenses: 'Earned Payroll',
    generalExpensesCardLabel: 'Site Expenses',
    paidPayrollCardLabel: 'Paid Payroll',
    outstandingPayrollCardLabel: 'Outstanding Payroll',
    siteOverviewTitle: 'Active Site Snapshot',
    quickActionsTitle: 'Quick Navigation',
    searchWorkersPlaceholder: 'Search by name, ID, or phone...',
    addWorker: 'Add Worker',
    editWorker: 'Edit Worker',
    workerProfile: 'Worker Profile',
    transferWorkerBtn: 'Transfer Site',
    transferWorkerTitle: 'Transfer Worker Between Sites',
    targetSiteLabel: 'Destination Site',
    transferNoteLabel: 'Transfer Note',
    siteTransferHistoryTitle: 'Site Assignment & Transfer History',
    duplicateLocalCodeError: 'Worker ID already exists at this construction site.',
    fullNameLabel: 'Full Name',
    workerIdLabel: 'Site Worker ID',
    phoneNumberLabel: 'Phone Number',
    categoryLabel: 'Work Category',
    joiningDateLabel: 'Joining Date',
    leavingDateLabel: 'Leaving Date (Optional)',
    dailyWageLabel: 'Daily Wage (৳)',
    foodAllowanceLabel: 'Food Allowance (৳)',
    activeStatus: 'Active',
    inactiveStatus: 'Inactive',
    statusLabel: 'Worker Status',
    allFilter: 'All',
    sortLabel: 'Sort',
    sortByName: 'Name',
    sortById: 'ID',
    sortByCategory: 'Category',
    sortByEarnings: 'Earnings',
    sortByPaid: 'Paid',
    sortByOutstanding: 'Balance',
    saveWorker: 'Save Worker',
    saveChanges: 'Save Changes',
    cancel: 'Cancel',
    close: 'Close',
    confirmAction: 'Confirm',
    addPhoto: 'Add Photo',
    replacePhoto: 'Replace Photo',
    removePhoto: 'Remove Photo',
    photoPreviewNotice: 'Preview ready. Save to store permanently in local storage.',
    noPhotoPlaceholderText: 'No photo added',
    profileTabOverview: 'Overview',
    profileTabAttendance: 'Attendance',
    profileTabPayrollHistory: 'Payroll History',
    profileTabPayments: 'Payment History',
    profileTabPersonal: 'Personal Info',
    totalCalendarDays: 'Calendar Days',
    halfDutyLabel: 'Half Duty',
    fullDutyLabel: 'Full Duty',
    oneAndHalfDutyLabel: 'One and Half Duty',
    doubleDutyLabel: 'Double Duty',
    twoAndHalfDutyLabel: 'Two and Half Duty',
    tripleDutyLabel: 'Triple Duty',
    absentLabel: 'Absent',
    leaveLabel: 'Leave',
    notRecordedLabel: 'Not Recorded',
    totalDutyUnits: 'Total Duty Units',
    totalEarnedAmount: 'Total Earned',
    totalPaidAmount: 'Total Paid',
    advanceAppliedLabel: 'Advance Applied',
    unallocatedAdvancesLabel: 'Unallocated Advances',
    remainingBalance: 'Outstanding Balance',
    payrollStatusLabel: 'Payroll Status',
    currentMonthPayrollTitle: 'Current Month Payroll',
    earnedUpToTodayLabel: 'Earned Up to Today',
    estimatedMonthEndLabel: 'Estimated Month-End',
    estimateDisclaimer: 'Projection only — not finalized salary',
    monthlyBreakdownTitle: 'Monthly Payroll Breakdown',
    selectedDateDetails: 'Selected Date Details',
    dutyTypeLabel: 'Duty Type',
    dutyMultiplierLabel: 'Duty Multiplier',
    savedDailyWageLabel: 'Daily Wage',
    dutyUnitsLabel: 'Duty Units',
    earnedAmountLabel: 'Earned Amount',
    notesLabel: 'Notes',
    lastUpdatedLabel: 'Last Updated',
    auditHistoryTitle: 'Audit History',
    recordOrEditAttendance: 'Record / Edit Attendance',
    confirmEditAttendanceMsg:
      'Confirm updating an existing attendance record? This change will be saved in the audit log.',
    confirmVoidPaymentMsg:
      'Confirm reversing this payment transaction? The reversal remains visible in the audit log.',
    selectDate: 'Select Date',
    selectMonth: 'Month',
    selectYear: 'Year',
    paymentLedgerTitle: 'Payment Ledger',
    recordPayment: 'Record Payment',
    recordAdvanceBtn: 'Record Advance',
    allocateAdvanceBtn: 'Apply to Month',
    applicablePeriodLabel: 'Salary Period',
    paymentDateLabel: 'Payment Date',
    fullPaymentBtn: 'Full Balance',
    partialPaymentBtn: 'Partial (50%)',
    referenceNoLabel: 'Reference No.',
    transactionHistory: 'Payment Transactions',
    selectWorker: 'Select Worker',
    paymentAmountLabel: 'Amount (৳)',
    paymentNoteLabel: 'Payment Note',
    saveEntry: 'Save Entry',
    voidTransaction: 'Reverse',
    voidedLabel: 'Reversed',
    payrollSpreadsheetTitle: 'PAYROLL SPREADSHEET',
    allSitesToggleLabel: 'All Sites',
    activeSiteToggleLabel: 'Active Site',
    siteColumnLabel: 'Site',
    totalsRowLabel: 'TOTALS',
    finalizePayrollBtn: 'Finalize Payroll',
    reopenPayrollBtn: 'Reopen Payroll',
    payrollFinalizedBadge: 'Finalized',
    payrollOpenBadge: 'Open',
    payrollLockedWarning:
      'Payroll period is finalized for this site. Admin must reopen it before editing attendance or payments.',
    confirmFinalizeMsg:
      'Finalize payroll for this site and month? Ordinary attendance and payment edits will be locked until reopened by Admin.',
    confirmReopenMsg:
      'Reopen this finalized payroll period? Reopening is recorded in the payroll audit trail.',
    exportExcelBtn: 'Excel (.xls)',
    exportAllPdfBtn: 'All PDF',
    exportWorkerPdfBtn: 'Worker PDF',
    printAttendanceBtn: 'Print Sheet',
    exportSuccessNotice: 'Offline report exported:',
    dailySiteAttendance: 'Daily Site Attendance',
    dailyTotalDutyUnits: 'Daily Total Duty Units',
    monthlySiteSummary: 'Monthly Site Summary',
    yearlyPayrollSummary: 'Yearly Payroll Summary',
    monthlyTotalEarned: 'Monthly Earned Wages',
    monthlyTotalPaid: 'Monthly Paid Wages',
    monthlyOutstanding: 'Monthly Outstanding',
    workerWiseReportTitle: 'Worker-wise Monthly Comparison',
    roleSettingTitle: 'Active User Role',
    roleSettingDesc:
      'Switch site role to verify Admin, Manager, and Accountant permissions.',
    dutyMultiplierSettingTitle: 'Site Duty Multipliers (Admin)',
    dutyMultiplierSettingDesc:
      'Configure future multipliers for the active site. Past records keep their saved snapshots.',
    saveMultipliers: 'Save Multipliers',
    multipliersSavedNotice: 'Future duty multipliers updated.',
    adminOnlyWarning: 'Only Admin can modify duty multipliers, finalize payroll, or manage sites.',
    roleRestrictedAction: 'Current role does not have permission for this action.',
    overpaymentWarning: 'Warning: Allocated payments exceed earned salary (negative balance).',
    noMonthAttendanceWarning: 'Notice: No attendance recorded yet for this month.',
    languageSettingTitle: 'App Language',
    languageSettingDesc: 'Switch interface text between English and Bengali.',
    dataStageNoticeTitle: 'Offline SQLite v6 & Media Storage',
    dataStageNoticeBody:
      'Sites, workers, photos, receipt images, attendance snapshots, expenses, advances, and audit logs persist offline.',
    resetSampleData: 'Reset Sample Data',
    offlineReadyTitle: 'Offline-First Architecture',
    offlineReadyBody:
      'Designed to operate at remote construction sites without an internet connection, Firebase, or cloud services.',
    noWorkersFound: 'No matching workers found.',
    perDaySuffix: '/day',
    backupSectionTitle: 'Offline Backup & Restore',
    backupSectionDesc:
      'Export a verified portable ZIP containing full database snapshot, worker photos, receipt images, and SHA-256 manifest.',
    createFullBackupBtn: 'Create Full Backup',
    restoreFromBackupBtn: 'Restore From Backup',
    verifyBackupBtn: 'Verify Backup',
    backupHistoryTitle: 'Backup History',
    noBackupHistoryText: 'No local backups recorded yet.',
    restoreConfirmTitle: 'Confirm Full Data Restore',
    restoreOlderWarning: 'Warning: Selected backup is older than your current data.',
    restoreSafetyNotice:
      'An automatic pre-restore safety backup is captured first. Original data is preserved on any error.',
    backupVerifiedBadge: 'Verified',
    backupMissingFileBadge: 'File missing',
    activeSiteLabel: 'Active Site',
    sitesOverviewTitle: 'Sites Overview & Management',
    addSiteBtn: 'Add Site',
    editSiteBtn: 'Edit Site',
    siteNameLabel: 'Site Name',
    siteCodeLabel: 'Site Code',
    siteAddressLabel: 'Location / Address',
    clientNameLabel: 'Client Name',
    siteManagerLabel: 'Site Manager',
    archiveSiteBtn: 'Archive',
    sitePermissionsTitle: 'User Site Access Permissions',
    siteAccessDeniedWarning: 'Access denied: Current role is not assigned to this site.',
    expensesTitle: 'Site Expenses',
    addExpenseBtn: 'Add Expense',
    editExpenseBtn: 'Edit Expense',
    addCategoryBtn: 'Add Category',
    expenseCategoryLabel: 'Expense Category',
    expenseVendorLabel: 'Vendor / Paid To',
    expenseMethodLabel: 'Payment Method',
    receiptPhotoLabel: 'Receipt Photo',
    totalGeneralExpensesLabel: 'Total General Site Expenses',
    confirmVoidExpenseMsg:
      'Void this expense record? Financial records are reversed with an audit entry rather than hard-deleted.',
  },
  bn: {
    appName: 'সাইট লেজার',
    appSubtitle: 'মাল্টি-সাইট নির্মাণ কর্মী ও ব্যয় ব্যবস্থাপনা',
    sampleDataNotice:
      'অফলাইন v6 · মাল্টি-সাইট সুরক্ষা, খরচ হিসাব ও যাচাইকৃত ZIP ব্যাকআপ',
    navDashboard: 'ড্যাশবোর্ড',
    navWorkers: 'কর্মী',
    navAttendance: 'উপস্থিতি',
    navSpreadsheet: 'বেতন শিট',
    navPayments: 'পেমেন্ট',
    navExpenses: 'সাইট খরচ',
    navReports: 'রিপোর্ট',
    navSites: 'সাইটসমূহ',
    navSettings: 'সেটিংস',
    totalWorkers: 'মোট কর্মী',
    presentToday: 'আজ উপস্থিত',
    absentToday: 'আজ অনুপস্থিত',
    todaysPayments: 'আজকের পেমেন্ট',
    monthlyExpenses: 'অর্জিত বেতন',
    generalExpensesCardLabel: 'সাইটের সাধারণ খরচ',
    paidPayrollCardLabel: 'পরিশোধিত বেতন',
    outstandingPayrollCardLabel: 'বকেয়া বেতন',
    siteOverviewTitle: 'সক্রিয় সাইটের সারসংক্ষেপ',
    quickActionsTitle: 'দ্রুত নেভিগেশন',
    searchWorkersPlaceholder: 'নাম, আইডি বা ফোন দিয়ে খুঁজুন...',
    addWorker: 'কর্মী যোগ করুন',
    editWorker: 'কর্মী সম্পাদনা',
    workerProfile: 'কর্মীর প্রোফাইল',
    transferWorkerBtn: 'সাইট বদলি',
    transferWorkerTitle: 'কর্মী অন্য সাইটে বদলি করুন',
    targetSiteLabel: 'নতুন সাইট',
    transferNoteLabel: 'বদলির মন্তব্য',
    siteTransferHistoryTitle: 'সাইট বদলির ইতিহাস',
    duplicateLocalCodeError: 'এই সাইটে একই কর্মী আইডি ইতিমধ্যে ব্যবহৃত হয়েছে।',
    fullNameLabel: 'পূর্ণ নাম',
    workerIdLabel: 'সাইট কর্মী আইডি',
    phoneNumberLabel: 'ফোন নম্বর',
    categoryLabel: 'কাজের ধরন',
    joiningDateLabel: 'যোগদানের তারিখ',
    leavingDateLabel: 'বিদায়ের তারিখ (ঐচ্ছিক)',
    dailyWageLabel: 'দৈনিক মজুরি (৳)',
    foodAllowanceLabel: 'খাবার ভাতা (৳)',
    activeStatus: 'সক্রিয়',
    inactiveStatus: 'নিষ্ক্রিয়',
    statusLabel: 'কর্মীর অবস্থা',
    allFilter: 'সকল',
    sortLabel: 'সাজান',
    sortByName: 'নাম',
    sortById: 'আইডি',
    sortByCategory: 'ধরন',
    sortByEarnings: 'আয়',
    sortByPaid: 'পরিশোধ',
    sortByOutstanding: 'বকেয়া',
    saveWorker: 'সংরক্ষণ করুন',
    saveChanges: 'পরিবর্তন সংরক্ষণ',
    cancel: 'বাতিল',
    close: 'বন্ধ করুন',
    confirmAction: 'নিশ্চিত করুন',
    addPhoto: 'ছবি যোগ করুন',
    replacePhoto: 'ছবি পরিবর্তন',
    removePhoto: 'ছবি মুছুন',
    photoPreviewNotice: 'ছবির প্রিভিউ প্রস্তুত। সংরক্ষণ করতে সেভ চাপুন।',
    noPhotoPlaceholderText: 'কোনো ছবি নেই',
    profileTabOverview: 'সারসংক্ষেপ',
    profileTabAttendance: 'উপস্থিতি',
    profileTabPayrollHistory: 'বেতনের ইতিহাস',
    profileTabPayments: 'পেমেন্ট ইতিহাস',
    profileTabPersonal: 'ব্যক্তিগত তথ্য',
    totalCalendarDays: 'মাসের মোট দিন',
    halfDutyLabel: 'হাফ হাজিরা',
    fullDutyLabel: 'এক হাজিরা',
    oneAndHalfDutyLabel: 'দেড় হাজিরা',
    doubleDutyLabel: 'দুই হাজিরা',
    twoAndHalfDutyLabel: 'আড়াই হাজিরা',
    tripleDutyLabel: 'তিন হাজিরা',
    absentLabel: 'অনুপস্থিত',
    leaveLabel: 'ছুটি',
    notRecordedLabel: 'নথিভুক্ত নয়',
    totalDutyUnits: 'মোট ডিউটি ইউনিট',
    totalEarnedAmount: 'মোট অর্জিত',
    totalPaidAmount: 'মোট পরিশোধিত',
    advanceAppliedLabel: 'সমন্বিত অগ্রিম',
    unallocatedAdvancesLabel: 'অসমন্বিত অগ্রিম',
    remainingBalance: 'বকেয়া পাওনা',
    payrollStatusLabel: 'বেতনের অবস্থা',
    currentMonthPayrollTitle: 'চলতি মাসের বেতন',
    earnedUpToTodayLabel: 'আজ পর্যন্ত অর্জিত',
    estimatedMonthEndLabel: 'মাস শেষের আনুমানিক বেতন',
    estimateDisclaimer: 'শুধুই আনুমানিক হিসাব — চূড়ান্ত বেতন নয়',
    monthlyBreakdownTitle: 'মাসিক বেতন বিবরণী',
    selectedDateDetails: 'নির্বাচিত তারিখের বিবরণ',
    dutyTypeLabel: 'হাজিরার ধরন',
    dutyMultiplierLabel: 'ডিউটি গুণিতক',
    savedDailyWageLabel: 'দৈনিক মজুরি',
    dutyUnitsLabel: 'ডিউটি ইউনিট',
    earnedAmountLabel: 'অর্জিত টাকা',
    notesLabel: 'মন্তব্য',
    lastUpdatedLabel: 'সর্বশেষ হালনাগাদ',
    auditHistoryTitle: 'সংশোধনের ইতিহাস',
    recordOrEditAttendance: 'উপস্থিতি সংরক্ষণ / সংশোধন',
    confirmEditAttendanceMsg:
      'পূর্বের উপস্থিতি তথ্য পরিবর্তন করতে নিশ্চিত? এটি অডিট ইতিহাসে সংরক্ষিত থাকবে।',
    confirmVoidPaymentMsg:
      'এই লেনদেন রিভার্স/বাতিল করতে চান? রেকর্ড অডিট ইতিহাসে সংরক্ষিত থাকবে।',
    selectDate: 'তারিখ নির্বাচন করুন',
    selectMonth: 'মাস',
    selectYear: 'বছর',
    paymentLedgerTitle: 'পেমেন্ট খাতা',
    recordPayment: 'পেমেন্ট এন্ট্রি',
    recordAdvanceBtn: 'অগ্রিম এন্ট্রি',
    allocateAdvanceBtn: 'মাসে সমন্বয়',
    applicablePeriodLabel: 'বেতনের মাস',
    paymentDateLabel: 'পরিশোধের তারিখ',
    fullPaymentBtn: 'সম্পূর্ণ পাওনা',
    partialPaymentBtn: 'আংশিক (৫০%)',
    referenceNoLabel: 'রেফারেন্স নং',
    transactionHistory: 'পেমেন্ট লেনদেন',
    selectWorker: 'কর্মী নির্বাচন করুন',
    paymentAmountLabel: 'টাকার পরিমাণ (৳)',
    paymentNoteLabel: 'পেমেন্ট মন্তব্য',
    saveEntry: 'সংরক্ষণ করুন',
    voidTransaction: 'রিভার্স',
    voidedLabel: 'বাতিলকৃত',
    payrollSpreadsheetTitle: 'মাস্টার বেতন স্প্রেডশিট',
    allSitesToggleLabel: 'সকল সাইট',
    activeSiteToggleLabel: 'বর্তমান সাইট',
    siteColumnLabel: 'সাইট',
    totalsRowLabel: 'সর্বমোট',
    finalizePayrollBtn: 'বেতন চূড়ান্ত করুন',
    reopenPayrollBtn: 'পুনরায় খুলুন',
    payrollFinalizedBadge: 'চূড়ান্ত',
    payrollOpenBadge: 'খোলা',
    payrollLockedWarning:
      'এই সাইটের বেতন চূড়ান্ত করা হয়েছে। সংশোধনের আগে অ্যাডমিনকে পুনরায় খুলতে হবে।',
    confirmFinalizeMsg:
      'এই সাইট ও মাসের বেতন চূড়ান্ত করবেন? অ্যাডমিন পুনরায় না খোলা পর্যন্ত পরিবর্তন বন্ধ থাকবে।',
    confirmReopenMsg:
      'চূড়ান্তকৃত বেতন পুনরায় খুলতে চান? এটি অডিট ইতিহাসে নথিভুক্ত হবে।',
    exportExcelBtn: 'এক্সেল (.xls)',
    exportAllPdfBtn: 'সকল PDF',
    exportWorkerPdfBtn: 'কর্মীর PDF',
    printAttendanceBtn: 'প্রিন্ট শিট',
    exportSuccessNotice: 'অফলাইন রিপোর্ট তৈরি হয়েছে:',
    dailySiteAttendance: 'দৈনিক সাইট উপস্থিতি',
    dailyTotalDutyUnits: 'দৈনিক মোট ডিউটি ইউনিট',
    monthlySiteSummary: 'মাসিক সাইট সারসংক্ষেপ',
    yearlyPayrollSummary: 'বার্ষিক বেতন সারসংক্ষেপ',
    monthlyTotalEarned: 'মাসিক অর্জিত মজুরি',
    monthlyTotalPaid: 'মাসিক পরিশোধিত মজুরি',
    monthlyOutstanding: 'মাসিক বাকি পাওনা',
    workerWiseReportTitle: 'কর্মীভিত্তিক মাসিক তুলনা',
    roleSettingTitle: 'সক্রিয় ব্যবহারকারীর ভূমিকা',
    roleSettingDesc:
      'অ্যাডমিন, ম্যানেজার এবং হিসাবরক্ষক অনুমতি পরীক্ষা করতে ভূমিকা পরিবর্তন করুন।',
    dutyMultiplierSettingTitle: 'সাইটের ডিউটি গুণিতক (অ্যাডমিন)',
    dutyMultiplierSettingDesc:
      'সক্রিয় সাইটের ভবিষ্যতের ডিউটি গুণিতক নির্ধারণ করুন। পূর্বের রেকর্ডের স্ন্যাপশট অপরিবর্তিত থাকে।',
    saveMultipliers: 'গুণিতক সংরক্ষণ',
    multipliersSavedNotice: 'ভবিষ্যতের ডিউটি গুণিতক সংরক্ষিত হয়েছে।',
    adminOnlyWarning: 'শুধুমাত্র অ্যাডমিন ডিউটি গুণিতক, বেতন লক বা সাইট পরিচালনা করতে পারবেন।',
    roleRestrictedAction: 'বর্তমান ভূমিকার এই কাজের অনুমতি নেই।',
    overpaymentWarning: 'সতর্কতা: বরাদ্দকৃত পরিশোধ অর্জিত বেতনের চেয়ে বেশি।',
    noMonthAttendanceWarning: 'বিজ্ঞপ্তি: এই মাসে এখনো কোনো উপস্থিতি নথিভুক্ত হয়নি।',
    languageSettingTitle: 'অ্যাপের ভাষা',
    languageSettingDesc: 'ইংরেজি এবং বাংলা ভাষার মধ্যে পরিবর্তন করুন।',
    dataStageNoticeTitle: 'অফলাইন SQLite v6 ও মিডিয়া স্টোরেজ',
    dataStageNoticeBody:
      'সাইট, কর্মী, ছবি, রসিদের ছবি, উপস্থিতি, খরচ ও অডিট লগ অফলাইনে সংরক্ষিত থাকে।',
    resetSampleData: 'নমুনা তথ্য রিসেট',
    offlineReadyTitle: 'অফলাইন-ফার্স্ট কাঠামো',
    offlineReadyBody:
      'ইন্টারনেট সংযোগ, ফায়ারবেস বা ক্লাউড ছাড়াই নির্মাণ সাইটে ব্যবহারের জন্য তৈরি।',
    noWorkersFound: 'কোনো কর্মী পাওয়া যায়নি।',
    perDaySuffix: '/দিন',
    backupSectionTitle: 'অফলাইন ব্যাকআপ ও পুনরুদ্ধার',
    backupSectionDesc:
      'ডাটাবেস স্ন্যাপশট, কর্মীর ছবি, রসিদের ছবি ও SHA-256 ম্যানিফেস্টসহ সম্পূর্ণ ZIP ব্যাকআপ তৈরি করুন।',
    createFullBackupBtn: 'পূর্ণ ব্যাকআপ তৈরি',
    restoreFromBackupBtn: 'ব্যাকআপ পুনরুদ্ধার',
    verifyBackupBtn: 'ব্যাকআপ যাচাই',
    backupHistoryTitle: 'ব্যাকআপ ইতিহাস',
    noBackupHistoryText: 'এখনো কোনো স্থানীয় ব্যাকআপ নথিভুক্ত হয়নি।',
    restoreConfirmTitle: 'সম্পূর্ণ তথ্য পুনরুদ্ধার নিশ্চিত করুন',
    restoreOlderWarning: 'সতর্কতা: নির্বাচিত ব্যাকআপটি বর্তমান তথ্যের চেয়ে পুরোনো।',
    restoreSafetyNotice:
      'পুনরুদ্ধারের আগে স্বয়ংক্রিয় নিরাপত্তা ব্যাকআপ সংরক্ষণ করা হবে। ব্যর্থ হলে মূল তথ্য অক্ষত থাকবে।',
    backupVerifiedBadge: 'যাচাইকৃত',
    backupMissingFileBadge: 'ফাইল পাওয়া যায়নি',
    activeSiteLabel: 'সক্রিয় সাইট',
    sitesOverviewTitle: 'সকল সাইট ও পরিচালনা',
    addSiteBtn: 'নতুন সাইট',
    editSiteBtn: 'সাইট সম্পাদনা',
    siteNameLabel: 'সাইটের নাম',
    siteCodeLabel: 'সাইট কোড',
    siteAddressLabel: 'ঠিকানা / অবস্থান',
    clientNameLabel: 'ক্লায়েন্টের নাম',
    siteManagerLabel: 'সাইট ম্যানেজার',
    archiveSiteBtn: 'আর্কাইভ',
    sitePermissionsTitle: 'ব্যবহারকারীর সাইট অনুমতি',
    siteAccessDeniedWarning: 'অনুমতি নেই: বর্তমান ব্যবহারকারী এই সাইটে নিযুক্ত নন।',
    expensesTitle: 'সাইট খরচ খাতা',
    addExpenseBtn: 'খরচ যোগ করুন',
    editExpenseBtn: 'খরচ সম্পাদনা',
    addCategoryBtn: 'নতুন খাত',
    expenseCategoryLabel: 'খরচের খাত',
    expenseVendorLabel: 'বিক্রেতা / প্রাপক',
    expenseMethodLabel: 'পরিশোধ মাধ্যম',
    receiptPhotoLabel: 'রসিদের ছবি',
    totalGeneralExpensesLabel: 'মোট সাধারণ সাইট খরচ',
    confirmVoidExpenseMsg:
      'এই খরচের এন্ট্রি বাতিল/রিভার্স করতে চান? অডিট লগ সংরক্ষিত থাকবে।',
  },
};

export const WORK_CATEGORY_LABELS: Record<WorkCategory, { en: string; bn: string }> = {
  MASON: { en: 'Mason', bn: 'রাজমিস্ত্রি' },
  HELPER: { en: 'Helper', bn: 'হেল্পার' },
  STEEL_FIXER: { en: 'Steel Fixer', bn: 'রডমিস্ত্রি' },
  ELECTRICIAN: { en: 'Electrician', bn: 'ইলেকট্রিশিয়ান' },
  CARPENTER: { en: 'Carpenter', bn: 'কাঠমিস্ত্রি' },
  PLUMBER: { en: 'Plumber', bn: 'প্লাম্বার' },
};

export const DUTY_TYPE_LABELS: Record<
  DutyType,
  { shortCode: string; en: string; bn: string }
> = {
  HALF_DUTY: { shortCode: 'H', en: 'Half Duty', bn: 'হাফ হাজিরা' },
  FULL_DUTY: { shortCode: 'F', en: 'Full Duty', bn: 'এক হাজিরা' },
  ONE_AND_HALF_DUTY: { shortCode: '1.5', en: 'One and Half Duty', bn: 'দেড় হাজিরা' },
  DOUBLE_DUTY: { shortCode: 'D', en: 'Double Duty', bn: 'দুই হাজিরা' },
  TWO_AND_HALF_DUTY: { shortCode: '2.5', en: 'Two and Half Duty', bn: 'আড়াই হাজিরা' },
  TRIPLE_DUTY: { shortCode: 'T', en: 'Triple Duty', bn: 'তিন হাজিরা' },
  ABSENT: { shortCode: 'A', en: 'Absent', bn: 'অনুপস্থিত' },
  LEAVE: { shortCode: 'L', en: 'Leave', bn: 'ছুটি' },
};

export const USER_ROLE_LABELS: Record<UserRole, { en: string; bn: string }> = {
  ADMIN: { en: 'Admin', bn: 'অ্যাডমিন' },
  MANAGER: { en: 'Manager', bn: 'ম্যানেজার' },
  ACCOUNTANT: { en: 'Accountant', bn: 'হিসাবরক্ষক' },
};

export const PAYROLL_STATUS_LABELS: Record<
  WorkerPayrollStatus,
  { en: string; bn: string }
> = {
  PAID: { en: 'Paid', bn: 'পরিশোধিত' },
  PARTIAL: { en: 'Partial', bn: 'আংশিক' },
  UNPAID: { en: 'Unpaid', bn: 'বকেয়া' },
  OVERPAID: { en: 'Overpaid', bn: 'অতিরিক্ত পরিশোধিত' },
  NO_ATTENDANCE: { en: 'No Attendance', bn: 'উপস্থিতি নেই' },
};

export const PERIOD_LOCK_LABELS: Record<
  PayrollPeriodStatus,
  { en: string; bn: string }
> = {
  OPEN: { en: 'Open', bn: 'খোলা' },
  FINALIZED: { en: 'Finalized', bn: 'চূড়ান্ত' },
};

export const SITE_STATUS_LABELS: Record<SiteStatus, { en: string; bn: string }> = {
  ACTIVE: { en: 'Active', bn: 'সক্রিয়' },
  PAUSED: { en: 'Paused', bn: 'স্থগিত' },
  COMPLETED: { en: 'Completed', bn: 'সম্পন্ন' },
  ARCHIVED: { en: 'Archived', bn: 'আর্কাইভকৃত' },
};

export const EXPENSE_METHOD_LABELS: Record<
  ExpensePaymentMethod,
  { en: string; bn: string }
> = {
  CASH: { en: 'Cash', bn: 'নগদ' },
  BANK: { en: 'Bank', bn: 'ব্যাংক' },
  MOBILE_BANKING: { en: 'Mobile Banking', bn: 'মোবাইল ব্যাংকিং' },
};
