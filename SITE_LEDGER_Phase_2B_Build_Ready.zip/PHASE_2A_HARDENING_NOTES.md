# SITE LEDGER — Phase 2A Backup & Restore Hardening

This update modifies the existing Android project in place. It does not reset the database, change the SQLite schema, or start the PWA/Wi-Fi-sync phases.

## Changes made

- Restore now requires a successful, complete WAL checkpoint immediately before creating the rollback database snapshot.
- SQLite replacement uses a prepared same-directory file and rename-based installation; unsafe copy-overwrite fallback was removed.
- Worker-photo and receipt directories are prepared separately and swapped by directory rename instead of deleting live files one-by-one.
- Restore journal writes now use a synced temporary file and preserve a previous journal copy during replacement; startup reads the previous copy if the primary journal is unreadable.
- File-sync failures are no longer silently ignored.
- Backup ZIP output is assembled beside its destination and committed by rename without deleting the existing destination first.
- ZIP validation rejects oversized archives, excessive entry counts, oversized entries/manifests, excessive total expanded size, and extreme compression ratios.
- Android automatic app-data backup is disabled (`android:allowBackup="false"`) to align with the offline-first/no-cloud requirement.
- Added the referenced `app/proguard-rules.pro` file so the configured release build has its expected rules file.
- Added a regression test for failure of the WAL checkpoint before rollback snapshot creation.

## Verification performed in this environment

- Kotlin compiler successfully compiled the pure-JVM backup engine and its project model/schema dependencies.
- All 15 `BackupRestoreHardeningTest` cases passed using a local lightweight JUnit-compatible test harness.
- ZIP archive integrity and Android manifest XML parsing were checked.

## Verification not performed

- A full Android Gradle build was not run: this environment has no Gradle executable, no Gradle Wrapper in the supplied project, and no configured Android SDK.
- Tests were not run on a physical Android device or emulator, and the project test suite was not executed through the official Gradle/JUnit runner here.
- Sudden power-loss durability and device/filesystem-specific rename behavior still require Android device testing. The changes improve recovery and replacement safety but should not be advertised as proven power-loss-proof.

## Compatibility

- SQLite schema remains version 6.
- Backup format remains version 3.
- Existing supported backup formats v1 and v2 remain covered by the compatibility tests.
- Existing worker, attendance, payroll, advance, allocation, expense, site, and backup-history data structures were not intentionally changed.
