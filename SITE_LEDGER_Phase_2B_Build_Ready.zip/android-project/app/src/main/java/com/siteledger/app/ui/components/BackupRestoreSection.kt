package com.siteledger.app.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.siteledger.app.domain.model.BackupHistoryRecord
import com.siteledger.app.domain.model.BackupProgress
import com.siteledger.app.domain.model.BackupValidationResult
import com.siteledger.app.domain.model.RestoreRecoveryReport
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CanvasGrey
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusAmber
import com.siteledger.app.ui.theme.StatusGreen
import com.siteledger.app.ui.theme.StatusRed
import com.siteledger.app.ui.theme.SubtleBorderGrey

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BackupRestoreSection(
    strings: AppStrings,
    backupHistory: List<BackupHistoryRecord>,
    backupProgress: BackupProgress,
    pendingRestoreValidation: BackupValidationResult?,
    lastValidationResult: BackupValidationResult?,
    recoveryReport: RestoreRecoveryReport?,
    backupStatusDetail: String?,
    suggestedBackupFileName: String,
    onCreateBackupToUri: (Uri) -> Unit,
    onInspectBackupUri: (Uri, Boolean) -> Unit,
    onConfirmRestore: () -> Unit,
    onDismissPendingRestore: () -> Unit,
    onRetryRecovery: () -> Unit,
    onRefreshHistory: () -> Unit
) {
    LaunchedEffect(Unit) { onRefreshHistory() }

    val createBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) onCreateBackupToUri(uri)
    }

    val verifyBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onInspectBackupUri(uri, false)
    }

    val restoreBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onInspectBackupUri(uri, true)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CrispWhite),
        border = BorderStroke(1.dp, SubtleBorderGrey)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(strings.backupSectionTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = SlateInk)
            Text(strings.backupSectionDesc, style = MaterialTheme.typography.bodySmall, color = SlateMuted)

            if (recoveryReport != null && recoveryReport.recoveryNeeded) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = CanvasGrey,
                    border = BorderStroke(1.dp, if (recoveryReport.stillRequiresManualRecovery) StatusRed else StatusAmber)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(
                                Icons.Outlined.WarningAmber,
                                contentDescription = null,
                                tint = if (recoveryReport.stillRequiresManualRecovery) StatusRed else StatusAmber
                            )
                            Text(
                                text = strings.recoveryRequiredTitle,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (recoveryReport.stillRequiresManualRecovery) StatusRed else StatusAmber
                            )
                        }
                        Text(recoveryReport.message, style = MaterialTheme.typography.bodySmall, color = SlateInk)
                        if (!recoveryReport.safetyBackupPath.isNullOrBlank()) {
                            Text(
                                text = "Safety archive: ${recoveryReport.safetyBackupPath}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SlateMuted
                            )
                        }
                        if (recoveryReport.stillRequiresManualRecovery) {
                            OutlinedButton(
                                enabled = !backupProgress.isRunning,
                                onClick = onRetryRecovery
                            ) {
                                Text(strings.retryRecoveryBtn)
                            }
                        }
                    }
                }
            }

            if (backupProgress.isRunning) {
                LinearProgressIndicator(
                    progress = { (backupProgress.progressPercent / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
                val operationHeadline = when (backupProgress.operation) {
                    "BACKUP" -> strings.backupCreationStartedMsg
                    "RESTORE" -> strings.restoreInProgressMsg
                    else -> backupProgress.operation
                }
                Text(
                    "$operationHeadline — ${backupProgress.stageLabel} (${backupProgress.progressPercent}%)",
                    style = MaterialTheme.typography.labelSmall,
                    color = EngineeringBlue
                )
            }

            if (!backupStatusDetail.isNullOrBlank() && !backupProgress.isRunning) {
                val isError = backupStatusDetail.contains("failed", ignoreCase = true) ||
                    backupStatusDetail.contains("Recovery required", ignoreCase = true)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = CanvasGrey,
                    border = BorderStroke(1.dp, if (isError) StatusRed else StatusGreen)
                ) {
                    Text(
                        text = backupStatusDetail,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isError) StatusRed else SlateInk,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            if (lastValidationResult != null && !lastValidationResult.isValid && lastValidationResult.missingMediaFiles.isNotEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = CanvasGrey,
                    border = BorderStroke(1.dp, StatusRed)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "${strings.missingMediaHeader} (${lastValidationResult.missingMediaFiles.size})",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = StatusRed
                        )
                        lastValidationResult.missingMediaFiles.take(6).forEach { mediaPath ->
                            Text("• $mediaPath", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                        }
                    }
                }
            }

            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !backupProgress.isRunning,
                    onClick = { createBackupLauncher.launch(suggestedBackupFileName) }
                ) {
                    Icon(Icons.Outlined.Backup, contentDescription = null)
                    Text(" ${strings.createFullBackupBtn}")
                }
                OutlinedButton(
                    enabled = !backupProgress.isRunning,
                    onClick = { restoreBackupLauncher.launch(arrayOf("application/zip", "*/*")) }
                ) {
                    Icon(Icons.Outlined.Restore, contentDescription = null)
                    Text(" ${strings.restoreFromBackupBtn}")
                }
                OutlinedButton(
                    enabled = !backupProgress.isRunning,
                    onClick = { verifyBackupLauncher.launch(arrayOf("application/zip", "*/*")) }
                ) {
                    Icon(Icons.Outlined.VerifiedUser, contentDescription = null)
                    Text(" ${strings.verifyBackupBtn}")
                }
            }

            HorizontalDivider(color = SubtleBorderGrey)
            Text(strings.backupHistoryTitle, style = MaterialTheme.typography.titleSmall, color = SlateInk)

            if (backupHistory.isEmpty()) {
                Text(strings.noBackupHistoryText, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
            } else {
                backupHistory.take(8).forEach { rec ->
                    val sizeKb = (rec.fileSizeBytes / 1024L).coerceAtLeast(1L)
                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(rec.fileName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = SlateInk, modifier = Modifier.weight(1f))
                            Text(
                                text = if (rec.fileExists) strings.backupVerifiedBadge else strings.backupMissingFileBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (rec.fileExists) StatusGreen else StatusRed
                            )
                        }
                        Text(
                            text = "${rec.createdAtIso} · ${sizeKb} KB · ${rec.counts.workers}W · ${rec.counts.workerPhotos} photos · ${rec.counts.receiptImages} receipts · ${rec.counts.expenses} exp",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateMuted
                        )
                        Text(
                            text = "Format v${rec.formatVersion} · Schema v${rec.schemaVersion} · SHA-256: ${rec.checksumSha256.take(16)}...",
                            style = MaterialTheme.typography.labelSmall,
                            color = EngineeringBlue
                        )
                    }
                    HorizontalDivider(color = SubtleBorderGrey)
                }
            }
        }
    }

    pendingRestoreValidation?.let { info ->
        AlertDialog(
            onDismissRequest = onDismissPendingRestore,
            title = { Text(strings.restoreConfirmTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(strings.restoreValidationSuccessMsg, fontWeight = FontWeight.SemiBold, color = StatusGreen, style = MaterialTheme.typography.labelMedium)
                    Text("${info.fileName} (${info.createdAtIso})", fontWeight = FontWeight.SemiBold, color = SlateInk)
                    Text("Format v${info.formatVersion} · Schema v${info.schemaVersion} · Sites: ${info.counts.sites} · Workers: ${info.counts.workers}", style = MaterialTheme.typography.bodySmall)
                    Text("Attendance: ${info.counts.attendanceRecords} · Payments: ${info.counts.payments} · Advances: ${info.counts.advances} · Expenses: ${info.counts.expenses}", style = MaterialTheme.typography.bodySmall)
                    Text("Worker Photos: ${info.counts.workerPhotos} · Receipt Images: ${info.counts.receiptImages}", style = MaterialTheme.typography.bodySmall)
                    if (info.isOlderThanCurrentData) {
                        Text(strings.restoreOlderWarning, style = MaterialTheme.typography.bodySmall, color = StatusAmber, fontWeight = FontWeight.SemiBold)
                    }
                    Text(strings.restoreSafetyNotice, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                }
            },
            confirmButton = {
                Button(onClick = onConfirmRestore) { Text(strings.restoreFromBackupBtn) }
            },
            dismissButton = {
                TextButton(onClick = onDismissPendingRestore) { Text(strings.cancel) }
            }
        )
    }
}
