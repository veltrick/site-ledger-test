package com.siteledger.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.ExpenseCategory
import com.siteledger.app.domain.model.ExpensePaymentMethod
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteExpense
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.ui.components.SampleDataNoticeBanner
import com.siteledger.app.ui.components.SummaryMetricCard
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusGreen
import com.siteledger.app.ui.theme.StatusRed
import com.siteledger.app.ui.theme.SubtleBorderGrey
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ExpensesScreen(
    strings: AppStrings,
    language: AppLanguage,
    activeRole: UserRole,
    activeSite: Site,
    categories: List<ExpenseCategory>,
    expenses: List<SiteExpense>,
    onSaveExpense: (SiteExpense, Uri?, Boolean) -> Unit,
    onVoidExpense: (String, String) -> Unit,
    onAddCategory: (String, String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var categoryFilterId by remember { mutableStateOf<String?>(null) }
    var editingExpense by remember { mutableStateOf<SiteExpense?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var voidConfirmTarget by remember { mutableStateOf<SiteExpense?>(null) }

    val categoryLookup = remember(categories) { categories.associateBy { it.id } }
    val filteredExpenses = remember(expenses, searchQuery, categoryFilterId) {
        expenses.filter { e ->
            val q = searchQuery.trim()
            (categoryFilterId == null || e.categoryId == categoryFilterId) &&
                (q.isBlank() || e.title.contains(q, true) || e.vendorName.contains(q, true) || e.description.contains(q, true))
        }
    }
    val nonVoidedTotal = filteredExpenses.filter { !it.isVoided }.sumOf { it.amount }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { SampleDataNoticeBanner(noticeText = "${activeSite.siteName} (${activeSite.siteCode}) · ${strings.expensesTitle}") }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(strings.expensesTitle, style = MaterialTheme.typography.titleLarge, color = SlateInk)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (activeRole == UserRole.ADMIN) {
                        OutlinedButton(onClick = { showAddCategoryDialog = true }) { Text(strings.addCategoryBtn) }
                    }
                    Button(onClick = { showAddDialog = true }) {
                        Icon(Icons.Outlined.Add, contentDescription = null)
                        Text(" ${strings.addExpenseBtn}")
                    }
                }
            }
        }

        item {
            SummaryMetricCard(
                label = strings.totalGeneralExpensesLabel,
                value = "৳$nonVoidedTotal",
                supportingText = "${activeSite.siteName} · ${filteredExpenses.count { !it.isVoided }} items",
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(strings.searchWorkersPlaceholder) },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                FilterChip(selected = categoryFilterId == null, onClick = { categoryFilterId = null }, label = { Text(strings.allFilter) })
                categories.forEach { cat ->
                    val label = if (language == AppLanguage.BENGALI) cat.nameBn else cat.nameEn
                    FilterChip(selected = categoryFilterId == cat.id, onClick = { categoryFilterId = cat.id }, label = { Text(label) })
                }
            }
        }

        items(filteredExpenses, key = { it.id }) { exp ->
            val cat = categoryLookup[exp.categoryId]
            val catName = if (cat == null) exp.categoryId else if (language == AppLanguage.BENGALI) cat.nameBn else cat.nameEn
            val methodLabel = if (language == AppLanguage.BENGALI) exp.paymentMethod.labelBn else exp.paymentMethod.labelEn

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(exp.title, style = MaterialTheme.typography.titleMedium, color = if (exp.isVoided) SlateMuted else SlateInk)
                        Text("$catName · ${exp.expenseDateIso} · $methodLabel", style = MaterialTheme.typography.bodySmall, color = EngineeringBlue)
                        if (exp.vendorName.isNotBlank() || exp.referenceNo.isNotBlank()) {
                            Text("${exp.vendorName} · ${exp.referenceNo}", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                        }
                        if (!exp.receiptPhotoPath.isNullOrBlank()) {
                            Text("${strings.receiptPhotoLabel}: ${exp.receiptPhotoPath.substringAfterLast('/')}", style = MaterialTheme.typography.labelSmall, color = StatusGreen)
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (exp.isVoided) strings.voidedLabel else "৳${exp.amount}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (exp.isVoided) StatusRed else SlateInk
                        )
                        if (!exp.isVoided) {
                            Row {
                                IconButton(onClick = { editingExpense = exp }) {
                                    Icon(Icons.Outlined.Edit, contentDescription = strings.editExpenseBtn, tint = SlateMuted)
                                }
                                if (activeRole != UserRole.MANAGER) {
                                    TextButton(onClick = { voidConfirmTarget = exp }) {
                                        Text(strings.voidTransaction, color = StatusRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog || editingExpense != null) {
        ExpenseFormDialog(
            strings = strings,
            language = language,
            activeSiteId = activeSite.id,
            activeRole = activeRole,
            categories = categories,
            initialExpense = editingExpense,
            onDismiss = {
                showAddDialog = false
                editingExpense = null
            },
            onConfirm = { exp, pickedUri, removeReceipt ->
                onSaveExpense(exp, pickedUri, removeReceipt)
                showAddDialog = false
                editingExpense = null
            }
        )
    }

    if (showAddCategoryDialog) {
        var nameEn by remember { mutableStateOf("") }
        var nameBn by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddCategoryDialog = false },
            title = { Text(strings.addCategoryBtn) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = nameEn, onValueChange = { nameEn = it }, label = { Text("Category (EN)") }, singleLine = true)
                    OutlinedTextField(value = nameBn, onValueChange = { nameBn = it }, label = { Text("Category (BN)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (nameEn.isNotBlank()) {
                        onAddCategory(nameEn, nameBn)
                        showAddCategoryDialog = false
                    }
                }) { Text(strings.confirmAction) }
            },
            dismissButton = {
                TextButton(onClick = { showAddCategoryDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    voidConfirmTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { voidConfirmTarget = null },
            title = { Text(strings.voidTransaction) },
            text = { Text(strings.confirmVoidExpenseMsg) },
            confirmButton = {
                Button(onClick = {
                    onVoidExpense(target.id, "Voided from Expenses")
                    voidConfirmTarget = null
                }) { Text(strings.confirmAction) }
            },
            dismissButton = {
                TextButton(onClick = { voidConfirmTarget = null }) { Text(strings.cancel) }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ExpenseFormDialog(
    strings: AppStrings,
    language: AppLanguage,
    activeSiteId: String,
    activeRole: UserRole,
    categories: List<ExpenseCategory>,
    initialExpense: SiteExpense?,
    onDismiss: () -> Unit,
    onConfirm: (SiteExpense, Uri?, Boolean) -> Unit
) {
    var title by remember { mutableStateOf(initialExpense?.title ?: "") }
    var description by remember { mutableStateOf(initialExpense?.description ?: "") }
    var dateIso by remember { mutableStateOf(initialExpense?.expenseDateIso ?: "2026-11-15") }
    var amountText by remember { mutableStateOf(initialExpense?.amount?.toString() ?: "") }
    var vendor by remember { mutableStateOf(initialExpense?.vendorName ?: "") }
    var refNo by remember { mutableStateOf(initialExpense?.referenceNo ?: "") }
    var selectedCatId by remember { mutableStateOf(initialExpense?.categoryId ?: categories.firstOrNull()?.id ?: "CAT-OTHER") }
    var selectedMethod by remember { mutableStateOf(initialExpense?.paymentMethod ?: ExpensePaymentMethod.CASH) }
    var pickedReceiptUri by remember { mutableStateOf<Uri?>(null) }
    var receiptRemoved by remember { mutableStateOf(false) }

    val receiptPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pickedReceiptUri = uri
            receiptRemoved = false
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialExpense == null) strings.addExpenseBtn else strings.editExpenseBtn) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter(Char::isDigit) }, label = { Text(strings.paymentAmountLabel) }, singleLine = true)
                OutlinedTextField(value = dateIso, onValueChange = { dateIso = it }, label = { Text(strings.selectDate) }, singleLine = true)
                Text(strings.expenseCategoryLabel, style = MaterialTheme.typography.labelMedium, color = SlateMuted)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    categories.forEach { cat ->
                        val lbl = if (language == AppLanguage.BENGALI) cat.nameBn else cat.nameEn
                        FilterChip(selected = selectedCatId == cat.id, onClick = { selectedCatId = cat.id }, label = { Text(lbl) })
                    }
                }
                Text(strings.expenseMethodLabel, style = MaterialTheme.typography.labelMedium, color = SlateMuted)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExpensePaymentMethod.entries.forEach { m ->
                        FilterChip(selected = selectedMethod == m, onClick = { selectedMethod = m }, label = { Text(if (language == AppLanguage.BENGALI) m.labelBn else m.labelEn) })
                    }
                }
                OutlinedTextField(value = vendor, onValueChange = { vendor = it }, label = { Text(strings.expenseVendorLabel) }, singleLine = true)
                OutlinedTextField(value = refNo, onValueChange = { refNo = it }, label = { Text(strings.referenceNoLabel) }, singleLine = true)
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text(strings.notesLabel) })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        receiptPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Outlined.PhotoCamera, contentDescription = null)
                        Text(" ${strings.receiptPhotoLabel}")
                    }
                    if (pickedReceiptUri != null || (!receiptRemoved && !initialExpense?.receiptPhotoPath.isNullOrBlank())) {
                        TextButton(onClick = {
                            pickedReceiptUri = null
                            receiptRemoved = true
                        }) { Text(strings.removePhoto, color = StatusRed) }
                    }
                }
                if (pickedReceiptUri != null) {
                    Text(strings.photoPreviewNotice, style = MaterialTheme.typography.bodySmall, color = StatusGreen)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val amt = amountText.toIntOrNull() ?: 0
                if (title.isNotBlank() && amt > 0) {
                    val exp = SiteExpense(
                        id = initialExpense?.id ?: "EXP-${UUID.randomUUID().toString().take(8).uppercase()}",
                        siteId = activeSiteId,
                        categoryId = selectedCatId,
                        expenseDateIso = dateIso.ifBlank { "2026-11-15" },
                        title = title.trim(),
                        description = description.trim(),
                        amount = amt,
                        paymentMethod = selectedMethod,
                        vendorName = vendor.trim(),
                        referenceNo = refNo.trim(),
                        receiptPhotoPath = initialExpense?.receiptPhotoPath,
                        recordedByRole = activeRole,
                        createdAtIso = initialExpense?.createdAtIso ?: "",
                        isVoided = initialExpense?.isVoided ?: false
                    )
                    onConfirm(exp, pickedReceiptUri, receiptRemoved)
                }
            }) { Text(strings.saveEntry) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}
