package com.siteledger.app.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Manages permanent offline worker photos and expense receipt images in app-private internal storage.
 *
 * Layout inside Context.filesDir (backup-compatible):
 *   files/
 *     worker_photos/
 *       worker_<id>_<uuid>.jpg
 *     receipt_images/
 *       receipt_<id>_<uuid>.jpg
 *     safety_backups/
 *       ...
 *
 * SQLite stores only the relative path so the database + media folders can be archived and restored cleanly.
 */
class WorkerPhotoStorage(context: Context) {

    private val appContext = context.applicationContext

    val photosDirectory: File
        get() = File(appContext.filesDir, PHOTOS_FOLDER_NAME).apply {
            if (!exists()) mkdirs()
        }

    val receiptsDirectory: File
        get() = File(appContext.filesDir, RECEIPTS_FOLDER_NAME).apply {
            if (!exists()) mkdirs()
        }

    val safetyBackupsDirectory: File
        get() = File(appContext.filesDir, SAFETY_BACKUPS_FOLDER_NAME).apply {
            if (!exists()) mkdirs()
        }

    /**
     * Copies and normalizes a gallery Photo Picker URI into worker_photos/ with a unique filename.
     */
    suspend fun savePickedPhoto(workerId: String, sourceUri: Uri): String? =
        savePickedMedia(
            targetFolder = photosDirectory,
            folderName = PHOTOS_FOLDER_NAME,
            prefix = "worker_${workerId.replace(Regex("[^A-Za-z0-9_-]"), "_")}",
            sourceUri = sourceUri
        )

    /**
     * Copies and normalizes a picked receipt photo URI into receipt_images/ with a unique filename.
     */
    suspend fun savePickedReceiptPhoto(expenseId: String, sourceUri: Uri): String? =
        savePickedMedia(
            targetFolder = receiptsDirectory,
            folderName = RECEIPTS_FOLDER_NAME,
            prefix = "receipt_${expenseId.replace(Regex("[^A-Za-z0-9_-]"), "_")}",
            sourceUri = sourceUri
        )

    private suspend fun savePickedMedia(
        targetFolder: File,
        folderName: String,
        prefix: String,
        sourceUri: Uri
    ): String? = withContext(Dispatchers.IO) {
        val fileName = "${prefix}_${UUID.randomUUID()}.jpg"
        val targetFile = File(targetFolder, fileName)

        val bitmap = decodeDownsampledBitmap(sourceUri, MAX_DIMENSION_PX)
        if (bitmap != null) {
            FileOutputStream(targetFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
            }
            bitmap.recycle()
            return@withContext "$folderName/$fileName"
        }

        val copied = appContext.contentResolver.openInputStream(sourceUri)?.use { input ->
            FileOutputStream(targetFile).use { output ->
                input.copyTo(output)
            }
            true
        } ?: false

        if (copied) "$folderName/$fileName" else null
    }

    /**
     * Resolves a relative photo_path or receipt_photo_path stored in SQLite to an internal File,
     * guarding against path traversal outside filesDir.
     */
    fun resolvePhotoFile(relativePath: String?): File? {
        if (relativePath.isNullOrBlank()) return null
        val candidate = File(appContext.filesDir, relativePath)
        val canonicalBase = appContext.filesDir.canonicalPath
        val canonicalTarget = runCatching { candidate.canonicalPath }.getOrNull() ?: return null
        if (!canonicalTarget.startsWith(canonicalBase)) return null
        return if (candidate.exists() && candidate.isFile) candidate else null
    }

    suspend fun loadSavedBitmap(relativePath: String?): Bitmap? = withContext(Dispatchers.IO) {
        val file = resolvePhotoFile(relativePath) ?: return@withContext null
        runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()
    }

    suspend fun loadPreviewBitmap(uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        decodeDownsampledBitmap(uri, MAX_DIMENSION_PX)
    }

    suspend fun deletePhotoIfUnreferenced(
        relativePath: String?,
        isStillReferenced: Boolean
    ) = withContext(Dispatchers.IO) {
        if (isStillReferenced || relativePath.isNullOrBlank()) return@withContext
        val file = resolvePhotoFile(relativePath) ?: return@withContext
        val parentName = file.parentFile?.name
        if (parentName == PHOTOS_FOLDER_NAME || parentName == RECEIPTS_FOLDER_NAME) {
            runCatching { file.delete() }
        }
    }

    fun getBackupAssets(): BackupAssets {
        val dbFile = appContext.getDatabasePath(SiteLedgerDatabaseContract.DATABASE_NAME)
        val photoFiles = photosDirectory.listFiles()?.filter { it.isFile } ?: emptyList()
        val receiptFiles = receiptsDirectory.listFiles()?.filter { it.isFile } ?: emptyList()
        return BackupAssets(
            databaseFile = dbFile,
            workerPhotoFiles = photoFiles,
            receiptImageFiles = receiptFiles
        )
    }

    private fun decodeDownsampledBitmap(uri: Uri, maxDimension: Int): Bitmap? {
        val resolver = appContext.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, bounds)
        } ?: return null

        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sampleSize = 1
        while (bounds.outWidth / sampleSize > maxDimension ||
            bounds.outHeight / sampleSize > maxDimension
        ) {
            sampleSize *= 2
        }

        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOpts)
        }
    }

    data class BackupAssets(
        val databaseFile: File,
        val workerPhotoFiles: List<File>,
        val receiptImageFiles: List<File>
    )

    companion object {
        const val PHOTOS_FOLDER_NAME = "worker_photos"
        const val RECEIPTS_FOLDER_NAME = "receipt_images"
        const val SAFETY_BACKUPS_FOLDER_NAME = "safety_backups"
        private const val MAX_DIMENSION_PX = 960
        private const val JPEG_QUALITY = 88
    }
}
