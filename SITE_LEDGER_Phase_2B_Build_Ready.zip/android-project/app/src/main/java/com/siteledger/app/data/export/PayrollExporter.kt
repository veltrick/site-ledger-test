package com.siteledger.app.data.export

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import androidx.core.content.FileProvider
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.MasterSpreadsheetTotals
import com.siteledger.app.domain.model.WorkerMonthlySummary
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 100% offline export utility for SITE LEDGER.
 * Supports single-site exports and All-Sites Consolidated exports with Site column.
 */
object PayrollExporter {

    fun exportSpreadsheetExcel(
        context: Context,
        language: AppLanguage,
        periodIso: String,
        rows: List<WorkerMonthlySummary>,
        totals: MasterSpreadsheetTotals,
        siteHeaderLabel: String = "All Sites",
        includeSiteColumn: Boolean = true
    ): File {
        val dir = File(context.filesDir, "payroll_exports").apply { mkdirs() }
        val file = File(dir, "site_ledger_payroll_${periodIso}.xls")
        val generatedAt = currentDateTimeIso()

        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\"?>\n")
        sb.append("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" ")
        sb.append("xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">\n")
        sb.append("<Worksheet ss:Name=\"Payroll_${periodIso}\">\n<Table>\n")

        appendXmlRow(sb, listOf("SITE LEDGER — $siteHeaderLabel", "Payroll Month: $periodIso", "Generated: $generatedAt"))
        val headers = buildList {
            if (includeSiteColumn) add("Site")
            addAll(
                listOf(
                    "Worker ID", "Worker Name", "Category",
                    "Half (0.5)", "Full (1.0)", "1.5 Duty", "Double (2.0)", "2.5 Duty", "Triple (3.0)",
                    "Absent", "Leave", "Duty Units",
                    "Earned (BDT)", "Paid (BDT)", "Advance Applied", "Outstanding (BDT)", "Status"
                )
            )
        }
        appendXmlRow(sb, headers)

        rows.forEach { r ->
            val name = if (language == AppLanguage.BENGALI) r.worker.fullNameBn else r.worker.fullNameEn
            val cat = if (language == AppLanguage.BENGALI) r.worker.category.labelBn else r.worker.category.labelEn
            val rowCells = buildList {
                if (includeSiteColumn) add(r.siteName.ifBlank { r.siteId })
                addAll(
                    listOf(
                        r.worker.localWorkerCode,
                        name,
                        cat,
                        r.halfDutyCount.toString(),
                        r.fullDutyCount.toString(),
                        r.oneAndHalfDutyCount.toString(),
                        r.doubleDutyCount.toString(),
                        r.twoAndHalfDutyCount.toString(),
                        r.tripleDutyCount.toString(),
                        r.absentCount.toString(),
                        r.leaveCount.toString(),
                        String.format(Locale.US, "%.1f", r.totalDutyUnits),
                        r.totalEarnedAmount.toString(),
                        r.totalPaidAmount.toString(),
                        r.advanceAllocatedAmount.toString(),
                        r.outstandingBalance.toString(),
                        r.payrollStatus.name
                    )
                )
            }
            appendXmlRow(sb, rowCells)
        }

        val totalRow = buildList {
            if (includeSiteColumn) add("ALL")
            addAll(
                listOf(
                    "TOTAL",
                    "${totals.totalWorkers} rows",
                    "", "", "", "", "", "", "", "", "",
                    String.format(Locale.US, "%.1f", totals.totalDutyUnits),
                    totals.totalEarnedSalary.toString(),
                    totals.totalPaidSalary.toString(),
                    "",
                    totals.totalOutstandingSalary.toString(),
                    ""
                )
            )
        }
        appendXmlRow(sb, totalRow)

        sb.append("</Table>\n</Worksheet>\n</Workbook>")
        file.writeText(sb.toString(), Charsets.UTF_8)
        shareExportFile(context, file, "application/vnd.ms-excel")
        return file
    }

    fun exportAllWorkersPayrollPdf(
        context: Context,
        language: AppLanguage,
        periodIso: String,
        rows: List<WorkerMonthlySummary>,
        totals: MasterSpreadsheetTotals,
        siteHeaderLabel: String = "All Sites",
        includeSiteColumn: Boolean = true
    ): File {
        val dir = File(context.filesDir, "payroll_exports").apply { mkdirs() }
        val file = File(dir, "site_ledger_payroll_${periodIso}.pdf")
        val doc = PdfDocument()
        val pageWidth = 842
        val pageHeight = 595
        val titlePaint = Paint().apply { color = Color.rgb(30, 58, 138); textSize = 15f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { color = Color.rgb(15, 23, 42); textSize = 9.0f }
        val boldPaint = Paint().apply { color = Color.rgb(15, 23, 42); textSize = 9.0f; isFakeBoldText = true }

        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var y = 42f
        val generatedAt = currentDateTimeIso()

        fun drawHeader(canvas: android.graphics.Canvas) {
            canvas.drawText("SITE LEDGER — $siteHeaderLabel ($periodIso)", 28f, 34f, titlePaint)
            canvas.drawText("Generated: $generatedAt", 28f, 50f, bodyPaint)
            val colHeader = if (includeSiteColumn) {
                "Site          ID      Name             H  F 1.5 D 2.5 T  A  L  Units   Earned    Paid  Balance"
            } else {
                "ID      Name               Category     H  F 1.5 D 2.5 T  A  L  Units   Earned    Paid  Balance"
            }
            canvas.drawText(colHeader, 28f, 72f, boldPaint)
            y = 90f
        }

        drawHeader(page.canvas)
        rows.forEach { r ->
            if (y > pageHeight - 60f) {
                doc.finishPage(page)
                pageNum += 1
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                drawHeader(page.canvas)
            }
            val name = (if (language == AppLanguage.BENGALI) r.worker.fullNameBn else r.worker.fullNameEn).take(16)
            val line = if (includeSiteColumn) {
                val siteLbl = r.siteName.ifBlank { r.siteId }.take(12)
                "%-12s %-7s %-16s %2d %2d %3d %2d %3d %2d %2d %2d %5.1f %8d %8d %8d".format(
                    Locale.US,
                    siteLbl, r.worker.localWorkerCode, name,
                    r.halfDutyCount, r.fullDutyCount, r.oneAndHalfDutyCount,
                    r.doubleDutyCount, r.twoAndHalfDutyCount, r.tripleDutyCount,
                    r.absentCount, r.leaveCount,
                    r.totalDutyUnits, r.totalEarnedAmount, r.totalPaidAmount, r.outstandingBalance
                )
            } else {
                val cat = (if (language == AppLanguage.BENGALI) r.worker.category.labelBn else r.worker.category.labelEn).take(11)
                "%-7s %-18s %-11s %2d %2d %3d %2d %3d %2d %2d %2d %5.1f %8d %8d %8d".format(
                    Locale.US,
                    r.worker.localWorkerCode, name, cat,
                    r.halfDutyCount, r.fullDutyCount, r.oneAndHalfDutyCount,
                    r.doubleDutyCount, r.twoAndHalfDutyCount, r.tripleDutyCount,
                    r.absentCount, r.leaveCount,
                    r.totalDutyUnits, r.totalEarnedAmount, r.totalPaidAmount, r.outstandingBalance
                )
            }
            page.canvas.drawText(line, 28f, y, bodyPaint)
            y += 18f
        }

        y += 8f
        val totalsLine = "TOTAL (${totals.totalWorkers} rows)  Units: %.1f   Earned: ৳%d   Paid: ৳%d   Outstanding: ৳%d".format(
            Locale.US, totals.totalDutyUnits, totals.totalEarnedSalary, totals.totalPaidSalary, totals.totalOutstandingSalary
        )
        page.canvas.drawText(totalsLine, 28f, y, boldPaint)
        doc.finishPage(page)

        FileOutputStream(file).use { out -> doc.writeTo(out) }
        doc.close()
        shareExportFile(context, file, "application/pdf")
        return file
    }

    fun exportIndividualWorkerPdf(
        context: Context,
        language: AppLanguage,
        summary: WorkerMonthlySummary,
        dayRecords: List<DailyAttendanceRecord>
    ): File {
        val dir = File(context.filesDir, "payroll_exports").apply { mkdirs() }
        val file = File(dir, "worker_${summary.worker.id}_${summary.periodIso}.pdf")
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas
        val titlePaint = Paint().apply { color = Color.rgb(30, 58, 138); textSize = 15f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { color = Color.rgb(15, 23, 42); textSize = 11f }
        val boldPaint = Paint().apply { color = Color.rgb(15, 23, 42); textSize = 11f; isFakeBoldText = true }

        val name = if (language == AppLanguage.BENGALI) summary.worker.fullNameBn else summary.worker.fullNameEn
        val cat = if (language == AppLanguage.BENGALI) summary.worker.category.labelBn else summary.worker.category.labelEn
        val siteLbl = summary.siteName.ifBlank { summary.siteId }
        c.drawText("SITE LEDGER — $siteLbl", 32f, 40f, titlePaint)
        c.drawText("Payroll Month: ${summary.periodIso}   Generated: ${currentDateTimeIso()}", 32f, 60f, bodyPaint)
        c.drawText("Worker: $name (${summary.worker.localWorkerCode}) · $cat · Wage: ৳${summary.worker.dailyWage}/day", 32f, 82f, boldPaint)

        var y = 112f
        listOf(
            "Half / Full / 1.5 / Double / 2.5 / Triple: ${summary.halfDutyCount} / ${summary.fullDutyCount} / ${summary.oneAndHalfDutyCount} / ${summary.doubleDutyCount} / ${summary.twoAndHalfDutyCount} / ${summary.tripleDutyCount}",
            "Absent / Leave: ${summary.absentCount} / ${summary.leaveCount}",
            "Total Duty Units: ${String.format(Locale.US, "%.1f", summary.totalDutyUnits)}",
            "Total Earned Salary: ৳${summary.totalEarnedAmount}",
            "Total Paid (Incl. Advances Applied ৳${summary.advanceAllocatedAmount}): ৳${summary.totalPaidAmount}",
            "Outstanding Balance: ৳${summary.outstandingBalance} (${summary.payrollStatus.labelEn} · Period: ${summary.periodLockStatus.labelEn})"
        ).forEach { line ->
            c.drawText(line, 32f, y, bodyPaint)
            y += 18f
        }

        y += 12f
        c.drawText("Daily Attendance Breakdown", 32f, y, boldPaint)
        y += 18f
        dayRecords.sortedBy { it.dateIso }.take(28).forEach { rec ->
            c.drawText("${rec.dateIso}  ${rec.dutyType.name} (${rec.multiplierSnapshot}x)  ৳${rec.dailyWageSnapshot} -> ৳${rec.earnedAmount}  ${rec.note}", 32f, y, bodyPaint)
            y += 16f
        }

        doc.finishPage(page)
        FileOutputStream(file).use { out -> doc.writeTo(out) }
        doc.close()
        shareExportFile(context, file, "application/pdf")
        return file
    }

    fun printMonthlyAttendanceReport(
        context: Context,
        language: AppLanguage,
        periodIso: String,
        rows: List<WorkerMonthlySummary>,
        siteHeaderLabel: String = "All Sites",
        includeSiteColumn: Boolean = true
    ) {
        val html = buildString {
            append("<html><body><h2>SITE LEDGER ($siteHeaderLabel) — Printable Monthly Attendance ($periodIso)</h2>")
            append("<p>Generated: ${currentDateTimeIso()}</p>")
            append("<table border='1' cellspacing='0' cellpadding='5'>")
            append("<tr>")
            if (includeSiteColumn) append("<th>Site</th>")
            append("<th>ID</th><th>Name</th><th>H</th><th>F</th><th>1.5</th><th>D</th><th>2.5</th><th>T</th><th>A</th><th>L</th><th>Units</th><th>Earned</th><th>Paid</th><th>Balance</th></tr>")
            rows.forEach { r ->
                val name = if (language == AppLanguage.BENGALI) r.worker.fullNameBn else r.worker.fullNameEn
                append("<tr>")
                if (includeSiteColumn) append("<td>${r.siteName.ifBlank { r.siteId }}</td>")
                append("<td>${r.worker.localWorkerCode}</td><td>$name</td><td>${r.halfDutyCount}</td><td>${r.fullDutyCount}</td><td>${r.oneAndHalfDutyCount}</td><td>${r.doubleDutyCount}</td><td>${r.twoAndHalfDutyCount}</td><td>${r.tripleDutyCount}</td><td>${r.absentCount}</td><td>${r.leaveCount}</td><td>${String.format(Locale.US, "%.1f", r.totalDutyUnits)}</td><td>৳${r.totalEarnedAmount}</td><td>৳${r.totalPaidAmount}</td><td>৳${r.outstandingBalance}</td></tr>")
            }
            append("</table></body></html>")
        }
        val webView = WebView(context)
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        printManager.print(
            "SiteLedger_Attendance_$periodIso",
            webView.createPrintDocumentAdapter("SiteLedger_Attendance_$periodIso"),
            PrintAttributes.Builder().build()
        )
    }

    private fun shareExportFile(context: Context, file: File, mimeType: String) {
        runCatching {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, file.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun appendXmlRow(sb: StringBuilder, cells: List<String>) {
        sb.append("<Row>")
        cells.forEach { cell ->
            val escaped = cell.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            sb.append("<Cell><Data ss:Type=\"String\">$escaped</Data></Cell>")
        }
        sb.append("</Row>\n")
    }

    private fun currentDateTimeIso(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
}
