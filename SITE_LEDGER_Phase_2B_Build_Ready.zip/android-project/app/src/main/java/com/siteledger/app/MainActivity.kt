package com.siteledger.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.siteledger.app.data.repository.SqliteSiteLedgerRepository
import com.siteledger.app.ui.SiteLedgerViewModel
import com.siteledger.app.ui.navigation.SiteLedgerApp
import com.siteledger.app.ui.theme.SiteLedgerTheme

class MainActivity : ComponentActivity() {

    private val sqliteRepository by lazy {
        SqliteSiteLedgerRepository(applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SiteLedgerTheme {
                val vm: SiteLedgerViewModel = viewModel(
                    factory = SiteLedgerViewModel.Factory(sqliteRepository)
                )
                SiteLedgerApp(viewModel = vm)
            }
        }
    }
}
