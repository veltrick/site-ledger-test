package com.siteledger.app.data.repository

import android.content.Context
import android.net.Uri
import com.siteledger.app.data.backup.OfflineBackupManager
import com.siteledger.app.data.local.SiteLedgerDatabaseContract
import com.siteledger.app.data.local.SiteLedgerSqliteOpenHelper
import com.siteledger.app.data.local.WorkerPhotoStorage
import com.siteledger.app.data.sample.SampleSiteData
import com.siteledger.app.domain.model.AdvanceRecord
import com.siteledger.app.domain.model.AttendanceAuditEntry
import com.siteledger.app.domain.model.BackupHistoryRecord
import com.siteledger.app.domain.model.BackupProgress
import com.siteledger.app.domain.model.BackupValidationResult
import com.siteledger.app.domain.model.DEFAULT_SITE_ID
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyMultiplierConfig
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.ExpenseAuditEntry
import com.siteledger.app.domain.model.ExpenseCategory
import com.siteledger.app.domain.model.ExpensePaymentMethod
import com.siteledger.app.domain.model.MonthlyExpenseBreakdown
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PaymentAuditEntry
import com.siteledger.app.domain.model.PaymentLedgerEntry
import com.siteledger.app.domain.model.PaymentType
import com.siteledger.app.domain.model.PayrollAuditEntry
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.PayrollPeriodStatus
import com.siteledger.app.domain.model.RestoreRecoveryReport
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteExpense
import com.siteledger.app.domain.model.SiteStatus
import com.siteledger.app.domain.model.SyncEvent
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.UserSiteAccount
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.model.WorkerSiteHistory
import com.siteledger.app.domain.service.WageCalculator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

interface SiteLedgerRepository {
    val sites: StateFlow<List<Site>>
    val workers: StateFlow<List<Worker>>
    val workerTransfers: StateFlow<List<WorkerSiteHistory>>
    val attendanceRecords: StateFlow<List<DailyAttendanceRecord>>
    val attendanceAudits: StateFlow<List<AttendanceAuditEntry>>
    val payments: StateFlow<List<PaymentLedgerEntry>>
    val advances: StateFlow<List<AdvanceRecord>>
    val paymentAllocations: StateFlow<List<PaymentAllocation>>
    val paymentAudits: StateFlow<List<PaymentAuditEntry>>
    val payrollPeriods: StateFlow<List<PayrollPeriodRecord>>
    val payrollAudits: StateFlow<List<PayrollAuditEntry>>
    val dutyMultipliers: StateFlow<DutyMultiplierConfig>
    val expenseCategories: StateFlow<List<ExpenseCategory>>
    val expenses: StateFlow<List<SiteExpense>>
    val expenseAudits: StateFlow<List<ExpenseAuditEntry>>
    val userSiteAccounts: StateFlow<List<UserSiteAccount>>
    val backupHistory: StateFlow<List<BackupHistoryRecord>>
    val backupProgress: StateFlow<BackupProgress>
    val monthlyExpenses: StateFlow<MonthlyExpenseBreakdown>

    fun canRoleAccessSite(role: UserRole, siteId: String): Boolean
    fun getAccessibleSiteIds(role: UserRole): Set<String>
    fun isPeriodFinalized(siteId: String, periodIso: String): Boolean
    fun getDutyMultipliersForSite(siteId: String): DutyMultiplierConfig

    // Sites & Permissions
    suspend fun addOrUpdateSite(site: Site, role: UserRole): Boolean
    suspend fun archiveOrUpdateSiteStatus(siteId: String, newStatus: SiteStatus, role: UserRole): Boolean
    suspend fun updateUserSiteAssignments(roleToUpdate: UserRole, assignedSiteIds: List<String>, actingRole: UserRole): Boolean

    // Workers & Transfers
    suspend fun addWorker(worker: Worker, pendingPhotoUri: Uri? = null, role: UserRole = UserRole.ADMIN): Boolean
    suspend fun updateWorker(
        updatedWorker: Worker,
        pendingPhotoUri: Uri? = null,
        removeExistingPhoto: Boolean = false,
        role: UserRole = UserRole.ADMIN
    ): Boolean
    suspend fun transferWorker(
        workerId: String,
        targetSiteId: String,
        newLocalWorkerCode: String?,
        notes: String,
        role: UserRole
    ): Boolean

    // Attendance & Payroll
    suspend fun recordAttendance(
        siteId: String,
        dateIso: String,
        worker: Worker,
        dutyType: DutyType,
        note: String,
        role: UserRole,
        editReason: String = ""
    ): Boolean
    suspend fun recordPaymentTransaction(
        siteId: String,
        workerId: String,
        paymentDateIso: String,
        applicablePeriod: String,
        paidAmount: Int,
        referenceNo: String,
        note: String,
        role: UserRole,
        submissionToken: String
    ): Boolean
    suspend fun recordAdvance(
        siteId: String,
        workerId: String,
        advanceDateIso: String,
        amount: Int,
        referenceNo: String,
        note: String,
        role: UserRole,
        submissionToken: String
    ): Boolean
    suspend fun allocateAdvanceToPeriod(
        advanceId: String,
        targetPeriod: String,
        amountToAllocate: Int,
        role: UserRole,
        note: String
    ): Boolean
    suspend fun voidPaymentTransaction(
        transactionId: String,
        role: UserRole,
        reason: String
    ): Boolean
    suspend fun finalizePayrollPeriod(
        siteId: String,
        periodIso: String,
        role: UserRole,
        reason: String
    ): Boolean
    suspend fun reopenPayrollPeriod(
        siteId: String,
        periodIso: String,
        role: UserRole,
        reason: String
    ): Boolean
    suspend fun updateDutyMultipliers(config: DutyMultiplierConfig)

    // Expenses & Categories
    suspend fun addExpenseCategory(nameEn: String, nameBn: String, role: UserRole): ExpenseCategory?
    suspend fun addOrUpdateExpense(
        expense: SiteExpense,
        pendingReceiptUri: Uri? = null,
        removeExistingReceipt: Boolean = false,
        role: UserRole
    ): Boolean
    suspend fun voidExpense(expenseId: String, role: UserRole, reason: String): Boolean

    // Offline Backup & Restore
    fun suggestedBackupFileName(): String
    suspend fun recoverInterruptedRestoreIfNeeded(): RestoreRecoveryReport
    suspend fun createFullBackupToUri(targetUri: Uri): Result<BackupHistoryRecord>
    suspend fun inspectBackupUri(sourceUri: Uri): BackupValidationResult
    suspend fun restoreFromBackupUri(sourceUri: Uri): Result<BackupValidationResult>
    suspend fun refreshBackupHistoryAvailability()

    suspend fun resetSampleData()
}

class SqliteSiteLedgerRepository(
    context: Context,
    val photoStorage: WorkerPhotoStorage = WorkerPhotoStorage(context),
    private val dbHelper: SiteLedgerSqliteOpenHelper = SiteLedgerSqliteOpenHelper(context)
) : SiteLedgerRepository {

    private val backupManager = OfflineBackupManager(context, dbHelper, photoStorage)

    private val _sites = MutableStateFlow(dbHelper.readAllSites())
    override val sites: StateFlow<List<Site>> = _sites.asStateFlow()

    private val _workers = MutableStateFlow(dbHelper.readAllWorkers())
    override val workers: StateFlow<List<Worker>> = _workers.asStateFlow()

    private val _workerTransfers = MutableStateFlow(dbHelper.readWorkerSiteHistory())
    override val workerTransfers: StateFlow<List<WorkerSiteHistory>> = _workerTransfers.asStateFlow()

    private val _attendanceRecords = MutableStateFlow(dbHelper.readAllAttendance())
    override val attendanceRecords: StateFlow<List<DailyAttendanceRecord>> = _attendanceRecords.asStateFlow()

    private val _attendanceAudits = MutableStateFlow(dbHelper.readAttendanceAudits())
    override val attendanceAudits: StateFlow<List<AttendanceAuditEntry>> = _attendanceAudits.asStateFlow()

    private val _payments = MutableStateFlow(dbHelper.readAllPayments())
    override val payments: StateFlow<List<PaymentLedgerEntry>> = _payments.asStateFlow()

    private val _advances = MutableStateFlow(dbHelper.readAllAdvances())
    override val advances: StateFlow<List<AdvanceRecord>> = _advances.asStateFlow()

    private val _paymentAllocations = MutableStateFlow(dbHelper.readAllAllocations())
    override val paymentAllocations: StateFlow<List<PaymentAllocation>> = _paymentAllocations.asStateFlow()

    private val _paymentAudits = MutableStateFlow(dbHelper.readPaymentAudits())
    override val paymentAudits: StateFlow<List<PaymentAuditEntry>> = _paymentAudits.asStateFlow()

    private val _payrollPeriods = MutableStateFlow(dbHelper.readPayrollPeriods())
    override val payrollPeriods: StateFlow<List<PayrollPeriodRecord>> = _payrollPeriods.asStateFlow()

    private val _payrollAudits = MutableStateFlow(dbHelper.readPayrollAudits())
    override val payrollAudits: StateFlow<List<PayrollAuditEntry>> = _payrollAudits.asStateFlow()

    private val _dutyMultipliers = MutableStateFlow(dbHelper.readDutyMultipliers(DEFAULT_SITE_ID))
    override val dutyMultipliers: StateFlow<DutyMultiplierConfig> = _dutyMultipliers.asStateFlow()

    private val _expenseCategories = MutableStateFlow(dbHelper.readExpenseCategories())
    override val expenseCategories: StateFlow<List<ExpenseCategory>> = _expenseCategories.asStateFlow()

    private val _expenses = MutableStateFlow(dbHelper.readAllExpenses())
    override val expenses: StateFlow<List<SiteExpense>> = _expenses.asStateFlow()

    private val _expenseAudits = MutableStateFlow(dbHelper.readExpenseAudits())
    override val expenseAudits: StateFlow<List<ExpenseAuditEntry>> = _expenseAudits.asStateFlow()

    private val _userSiteAccounts = MutableStateFlow(dbHelper.readUserSiteAccounts())
    override val userSiteAccounts: StateFlow<List<UserSiteAccount>> = _userSiteAccounts.asStateFlow()

    private val _backupHistory = MutableStateFlow(attachAvailability(dbHelper.readBackupHistory()))
    override val backupHistory: StateFlow<List<BackupHistoryRecord>> = _backupHistory.asStateFlow()

    private val _backupProgress = MutableStateFlow(BackupProgress())
    override val backupProgress: StateFlow<BackupProgress> = _backupProgress.asStateFlow()

    private val _monthlyExpenses = MutableStateFlow(SampleSiteData.monthlyExpenseBaseline)
    override val monthlyExpenses: StateFlow<MonthlyExpenseBreakdown> = _monthlyExpenses.asStateFlow()

    private val processedSubmissionTokens = mutableSetOf<String>()

    override fun canRoleAccessSite(role: UserRole, siteId: String): Boolean {
        if (role == UserRole.ADMIN) return true
        val account = _userSiteAccounts.value.find { it.role == role } ?: return true
        return siteId in account.assignedSiteIds
    }

    override fun getAccessibleSiteIds(role: UserRole): Set<String> {
        if (role == UserRole.ADMIN) return _sites.value.map { it.id }.toSet()
        val account = _userSiteAccounts.value.find { it.role == role }
        return account?.assignedSiteIds?.toSet() ?: _sites.value.map { it.id }.toSet()
    }

    override fun isPeriodFinalized(siteId: String, periodIso: String): Boolean =
        _payrollPeriods.value.find { it.siteId == siteId && it.periodIso == periodIso }?.status ==
            PayrollPeriodStatus.FINALIZED

    override fun getDutyMultipliersForSite(siteId: String): DutyMultiplierConfig =
        dbHelper.readDutyMultipliers(siteId)

    override suspend fun addOrUpdateSite(site: Site, role: UserRole): Boolean {
        if (role != UserRole.ADMIN) return false
        val codeConflict = _sites.value.any {
            it.id != site.id && it.siteCode.equals(site.siteCode.trim(), ignoreCase = true)
        }
        if (codeConflict) return false
        val syncEvent = SyncEvent("SYN-${UUID.randomUUID().toString().take(8)}", "SITE", site.id, site.id, "UPSERT", currentTimestampIso())
        withContext(Dispatchers.IO) {
            dbHelper.upsertSite(site, syncEvent)
            _sites.value = dbHelper.readAllSites()
        }
        return true
    }

    override suspend fun archiveOrUpdateSiteStatus(siteId: String, newStatus: SiteStatus, role: UserRole): Boolean {
        if (role != UserRole.ADMIN) return false
        val existing = _sites.value.find { it.id == siteId } ?: return false
        return addOrUpdateSite(existing.copy(status = newStatus), role)
    }

    override suspend fun updateUserSiteAssignments(
        roleToUpdate: UserRole,
        assignedSiteIds: List<String>,
        actingRole: UserRole
    ): Boolean {
        if (actingRole != UserRole.ADMIN) return false
        val existing = _userSiteAccounts.value.find { it.role == roleToUpdate } ?: return false
        val updated = existing.copy(assignedSiteIds = assignedSiteIds.distinct())
        withContext(Dispatchers.IO) {
            dbHelper.upsertUserSiteAccount(updated)
            _userSiteAccounts.value = dbHelper.readUserSiteAccounts()
        }
        return true
    }

    override suspend fun addWorker(worker: Worker, pendingPhotoUri: Uri?, role: UserRole): Boolean {
        if (!canRoleAccessSite(role, worker.siteId)) return false
        if (WageCalculator.isLocalWorkerCodeDuplicate(worker.siteId, worker.localWorkerCode, null, _workers.value)) {
            return false
        }
        val savedPhotoPath = if (pendingPhotoUri != null) {
            photoStorage.savePickedPhoto(worker.id, pendingPhotoUri)
        } else {
            worker.photoPath
        }
        val finalWorker = worker.copy(photoPath = savedPhotoPath)
        val syncEvent = SyncEvent("SYN-${UUID.randomUUID().toString().take(8)}", "WORKER", finalWorker.id, finalWorker.siteId, "CREATE", currentTimestampIso())
        withContext(Dispatchers.IO) {
            dbHelper.upsertWorker(finalWorker, syncEvent)
            _workers.value = dbHelper.readAllWorkers()
        }
        return true
    }

    override suspend fun updateWorker(
        updatedWorker: Worker,
        pendingPhotoUri: Uri?,
        removeExistingPhoto: Boolean,
        role: UserRole
    ): Boolean {
        if (!canRoleAccessSite(role, updatedWorker.siteId)) return false
        if (WageCalculator.isLocalWorkerCodeDuplicate(updatedWorker.siteId, updatedWorker.localWorkerCode, updatedWorker.id, _workers.value)) {
            return false
        }
        val existingWorker = _workers.value.find { it.id == updatedWorker.id }
        val previousPhotoPath = existingWorker?.photoPath

        val nextPhotoPath: String? = when {
            pendingPhotoUri != null -> photoStorage.savePickedPhoto(updatedWorker.id, pendingPhotoUri)
            removeExistingPhoto -> null
            else -> previousPhotoPath
        }

        val finalWorker = updatedWorker.copy(photoPath = nextPhotoPath)
        val syncEvent = SyncEvent("SYN-${UUID.randomUUID().toString().take(8)}", "WORKER", finalWorker.id, finalWorker.siteId, "UPDATE", currentTimestampIso())
        withContext(Dispatchers.IO) {
            dbHelper.upsertWorker(finalWorker, syncEvent)
            _workers.value = dbHelper.readAllWorkers()

            if (previousPhotoPath != null && previousPhotoPath != nextPhotoPath) {
                val stillReferenced = dbHelper.countWorkersWithPhotoPath(previousPhotoPath) > 0
                photoStorage.deletePhotoIfUnreferenced(previousPhotoPath, stillReferenced)
            }
        }
        return true
    }

    override suspend fun transferWorker(
        workerId: String,
        targetSiteId: String,
        newLocalWorkerCode: String?,
        notes: String,
        role: UserRole
    ): Boolean {
        if (role != UserRole.ADMIN) return false
        val worker = _workers.value.find { it.id == workerId } ?: return false
        if (worker.siteId == targetSiteId) return false
        val candidateCode = newLocalWorkerCode?.trim().takeIf { !it.isNullOrBlank() } ?: worker.localWorkerCode
        if (WageCalculator.isLocalWorkerCodeDuplicate(targetSiteId, candidateCode, worker.id, _workers.value)) {
            return false
        }
        val nowDate = currentTimestampIso().take(10)
        val updated = worker.copy(siteId = targetSiteId, localWorkerCode = candidateCode)
        val history = WorkerSiteHistory(
            transferId = "TRF-${UUID.randomUUID().toString().take(8).uppercase()}",
            workerId = worker.id,
            previousSiteId = worker.siteId,
            newSiteId = targetSiteId,
            transferDateIso = nowDate,
            authorizedByRole = role,
            notes = notes
        )
        val syncEvent = SyncEvent("SYN-${UUID.randomUUID().toString().take(8)}", "WORKER_TRANSFER", worker.id, targetSiteId, "TRANSFER", currentTimestampIso())
        withContext(Dispatchers.IO) {
            dbHelper.transferWorkerSite(updated, history, syncEvent)
            _workers.value = dbHelper.readAllWorkers()
            _workerTransfers.value = dbHelper.readWorkerSiteHistory()
        }
        return true
    }

    override suspend fun recordAttendance(
        siteId: String,
        dateIso: String,
        worker: Worker,
        dutyType: DutyType,
        note: String,
        role: UserRole,
        editReason: String
    ): Boolean {
        if (!canRoleAccessSite(role, siteId)) return false
        val periodIso = dateIso.take(7)
        if (isPeriodFinalized(siteId, periodIso)) return false

        val nowIso = currentTimestampIso()
        val existing = _attendanceRecords.value.find {
            it.siteId == siteId && it.dateIso == dateIso && it.workerId == worker.id
        }
        val siteConfig = dbHelper.readDutyMultipliers(siteId)
        val multiplier = siteConfig.multiplierFor(dutyType)
        val wageSnapshot = existing?.dailyWageSnapshot ?: worker.dailyWage
        val earned = WageCalculator.calculateDailyEarnedTaka(wageSnapshot, multiplier)

        val record = DailyAttendanceRecord(
            dateIso = dateIso,
            workerId = worker.id,
            dutyType = dutyType,
            dailyWageSnapshot = wageSnapshot,
            multiplierSnapshot = multiplier,
            earnedAmount = earned,
            note = note,
            updatedAtIso = nowIso,
            updatedByRole = role,
            siteId = siteId
        )

        val auditEntry = if (existing == null || existing.dutyType != dutyType || existing.note != note) {
            AttendanceAuditEntry(
                auditId = "AUD-A-${UUID.randomUUID().toString().take(8)}",
                dateIso = dateIso,
                workerId = worker.id,
                previousDutyType = existing?.dutyType,
                newDutyType = dutyType,
                previousEarned = existing?.earnedAmount,
                newEarned = earned,
                changedByRole = role,
                changedAtIso = nowIso,
                reason = editReason.ifBlank { if (existing == null) "Initial record" else "Correction" },
                siteId = siteId
            )
        } else null

        val syncEvent = SyncEvent("SYN-${UUID.randomUUID().toString().take(8)}", "ATTENDANCE", "${siteId}_${dateIso}_${worker.id}", siteId, "UPSERT", nowIso)
        withContext(Dispatchers.IO) {
            dbHelper.upsertAttendanceWithAudit(record, auditEntry, syncEvent)
            _attendanceRecords.value = dbHelper.readAllAttendance()
            _attendanceAudits.value = dbHelper.readAttendanceAudits()
        }
        return true
    }

    override suspend fun recordPaymentTransaction(
        siteId: String,
        workerId: String,
        paymentDateIso: String,
        applicablePeriod: String,
        paidAmount: Int,
        referenceNo: String,
        note: String,
        role: UserRole,
        submissionToken: String
    ): Boolean {
        if (!canRoleAccessSite(role, siteId)) return false
        if (role == UserRole.MANAGER) return false
        if (paidAmount <= 0 || isPeriodFinalized(siteId, applicablePeriod)) return false
        synchronized(processedSubmissionTokens) {
            if (!processedSubmissionTokens.add(submissionToken)) return false
        }

        val nowIso = currentTimestampIso()
        val txnId = "TXN-${UUID.randomUUID().toString().take(8).uppercase()}"
        val allocId = "ALLOC-${UUID.randomUUID().toString().take(8).uppercase()}"
        val entry = PaymentLedgerEntry(
            id = txnId,
            workerId = workerId,
            dateIso = paymentDateIso,
            applicablePeriod = applicablePeriod,
            paymentType = PaymentType.SALARY,
            paidAmount = paidAmount,
            referenceNo = referenceNo,
            noteEn = note,
            noteBn = note,
            recordedByRole = role,
            createdAtIso = nowIso,
            isVoided = false,
            siteId = siteId
        )
        val allocation = PaymentAllocation(
            allocationId = allocId,
            sourceType = "PAYMENT",
            sourceId = txnId,
            workerId = workerId,
            payrollPeriod = applicablePeriod,
            allocatedAmount = paidAmount,
            allocatedAtIso = nowIso,
            allocatedByRole = role,
            note = note,
            isVoided = false,
            siteId = siteId
        )
        val audit = PaymentAuditEntry(
            auditId = "AUD-P-${UUID.randomUUID().toString().take(8)}",
            transactionId = txnId,
            workerId = workerId,
            action = "CREATED",
            previousAmount = null,
            newAmount = paidAmount,
            changedByRole = role,
            changedAtIso = nowIso,
            reason = "Period $applicablePeriod: ${note.ifBlank { "Manual payment entry" }}",
            siteId = siteId
        )
        val syncEvent = SyncEvent("SYN-${UUID.randomUUID().toString().take(8)}", "PAYMENT", txnId, siteId, "CREATE", nowIso)
        withContext(Dispatchers.IO) {
            dbHelper.insertOrUpdatePaymentWithAllocationAndAudit(entry, allocation, audit, syncEvent)
            _payments.value = dbHelper.readAllPayments()
            _paymentAllocations.value = dbHelper.readAllAllocations()
            _paymentAudits.value = dbHelper.readPaymentAudits()
        }
        return true
    }

    override suspend fun recordAdvance(
        siteId: String,
        workerId: String,
        advanceDateIso: String,
        amount: Int,
        referenceNo: String,
        note: String,
        role: UserRole,
        submissionToken: String
    ): Boolean {
        if (!canRoleAccessSite(role, siteId) || role == UserRole.MANAGER) return false
        if (amount <= 0) return false
        synchronized(processedSubmissionTokens) {
            if (!processedSubmissionTokens.add(submissionToken)) return false
        }

        val nowIso = currentTimestampIso()
        val advId = "ADV-${UUID.randomUUID().toString().take(8).uppercase()}"
        val advance = AdvanceRecord(
            id = advId,
            workerId = workerId,
            advanceDateIso = advanceDateIso,
            amount = amount,
            referenceNo = referenceNo,
            note = note,
            recordedByRole = role,
            createdAtIso = nowIso,
            isVoided = false,
            siteId = siteId
        )
        val audit = PaymentAuditEntry(
            auditId = "AUD-P-${UUID.randomUUID().toString().take(8)}",
            transactionId = advId,
            workerId = workerId,
            action = "ADVANCE_ISSUED",
            previousAmount = null,
            newAmount = amount,
            changedByRole = role,
            changedAtIso = nowIso,
            reason = note.ifBlank { "Worker cash advance" },
            siteId = siteId
        )
        withContext(Dispatchers.IO) {
            dbHelper.insertAdvanceWithAudit(advance, audit)
            _advances.value = dbHelper.readAllAdvances()
            _paymentAudits.value = dbHelper.readPaymentAudits()
        }
        return true
    }

    override suspend fun allocateAdvanceToPeriod(
        advanceId: String,
        targetPeriod: String,
        amountToAllocate: Int,
        role: UserRole,
        note: String
    ): Boolean {
        val adv = _advances.value.find { it.id == advanceId && !it.isVoided } ?: return false
        if (!canRoleAccessSite(role, adv.siteId) || role == UserRole.MANAGER) return false
        if (amountToAllocate <= 0 || isPeriodFinalized(adv.siteId, targetPeriod)) return false
        val remaining = WageCalculator.computeAdvanceRemaining(adv, _paymentAllocations.value)
        if (amountToAllocate > remaining) return false

        val nowIso = currentTimestampIso()
        val allocation = PaymentAllocation(
            allocationId = "ALLOC-${UUID.randomUUID().toString().take(8).uppercase()}",
            sourceType = "ADVANCE",
            sourceId = adv.id,
            workerId = adv.workerId,
            payrollPeriod = targetPeriod,
            allocatedAmount = amountToAllocate,
            allocatedAtIso = nowIso,
            allocatedByRole = role,
            note = note.ifBlank { "Advance applied to $targetPeriod" },
            isVoided = false,
            siteId = adv.siteId
        )
        val audit = PaymentAuditEntry(
            auditId = "AUD-P-${UUID.randomUUID().toString().take(8)}",
            transactionId = adv.id,
            workerId = adv.workerId,
            action = "ADVANCE_ALLOCATED",
            previousAmount = remaining,
            newAmount = amountToAllocate,
            changedByRole = role,
            changedAtIso = nowIso,
            reason = "Applied ৳$amountToAllocate to $targetPeriod",
            siteId = adv.siteId
        )
        withContext(Dispatchers.IO) {
            dbHelper.insertAllocationWithAudit(allocation, audit)
            _paymentAllocations.value = dbHelper.readAllAllocations()
            _paymentAudits.value = dbHelper.readPaymentAudits()
        }
        return true
    }

    override suspend fun voidPaymentTransaction(transactionId: String, role: UserRole, reason: String): Boolean {
        val existing = _payments.value.find { it.id == transactionId } ?: return false
        if (!canRoleAccessSite(role, existing.siteId) || role == UserRole.MANAGER) return false
        if (existing.isVoided || isPeriodFinalized(existing.siteId, existing.applicablePeriod)) return false

        val nowIso = currentTimestampIso()
        val updated = existing.copy(isVoided = true)
        val audit = PaymentAuditEntry(
            auditId = "AUD-P-${UUID.randomUUID().toString().take(8)}",
            transactionId = transactionId,
            workerId = existing.workerId,
            action = "REVERSAL_VOIDED",
            previousAmount = existing.paidAmount,
            newAmount = 0,
            changedByRole = role,
            changedAtIso = nowIso,
            reason = reason.ifBlank { "Transaction voided" },
            siteId = existing.siteId
        )
        withContext(Dispatchers.IO) {
            dbHelper.insertOrUpdatePaymentWithAllocationAndAudit(updated, null, audit)
            _payments.value = dbHelper.readAllPayments()
            _paymentAllocations.value = dbHelper.readAllAllocations()
            _paymentAudits.value = dbHelper.readPaymentAudits()
        }
        return true
    }

    override suspend fun finalizePayrollPeriod(siteId: String, periodIso: String, role: UserRole, reason: String): Boolean {
        if (role != UserRole.ADMIN) return false
        val nowIso = currentTimestampIso()
        val existing = _payrollPeriods.value.find { it.siteId == siteId && it.periodIso == periodIso }
        val updated = (existing ?: PayrollPeriodRecord(periodIso = periodIso, siteId = siteId)).copy(
            status = PayrollPeriodStatus.FINALIZED,
            finalizedAtIso = nowIso,
            finalizedByRole = role,
            notes = reason
        )
        val audit = PayrollAuditEntry(
            auditId = "AUD-PAY-${UUID.randomUUID().toString().take(8)}",
            periodIso = periodIso,
            action = "FINALIZED",
            changedByRole = role,
            changedAtIso = nowIso,
            reason = reason.ifBlank { "Payroll finalized by Admin" },
            siteId = siteId
        )
        withContext(Dispatchers.IO) {
            dbHelper.upsertPayrollPeriodWithAudit(updated, audit)
            _payrollPeriods.value = dbHelper.readPayrollPeriods()
            _payrollAudits.value = dbHelper.readPayrollAudits()
        }
        return true
    }

    override suspend fun reopenPayrollPeriod(siteId: String, periodIso: String, role: UserRole, reason: String): Boolean {
        if (role != UserRole.ADMIN) return false
        val nowIso = currentTimestampIso()
        val existing = _payrollPeriods.value.find { it.siteId == siteId && it.periodIso == periodIso } ?: return false
        val updated = existing.copy(
            status = PayrollPeriodStatus.OPEN,
            reopenedAtIso = nowIso,
            reopenedByRole = role,
            notes = reason
        )
        val audit = PayrollAuditEntry(
            auditId = "AUD-PAY-${UUID.randomUUID().toString().take(8)}",
            periodIso = periodIso,
            action = "REOPENED",
            changedByRole = role,
            changedAtIso = nowIso,
            reason = reason.ifBlank { "Payroll reopened by Admin" },
            siteId = siteId
        )
        withContext(Dispatchers.IO) {
            dbHelper.upsertPayrollPeriodWithAudit(updated, audit)
            _payrollPeriods.value = dbHelper.readPayrollPeriods()
            _payrollAudits.value = dbHelper.readPayrollAudits()
        }
        return true
    }

    override suspend fun updateDutyMultipliers(config: DutyMultiplierConfig) {
        val nowIso = currentTimestampIso()
        withContext(Dispatchers.IO) {
            dbHelper.saveDutyMultipliers(config, nowIso)
            _dutyMultipliers.value = dbHelper.readDutyMultipliers(config.siteId)
        }
    }

    override suspend fun addExpenseCategory(nameEn: String, nameBn: String, role: UserRole): ExpenseCategory? {
        if (role != UserRole.ADMIN) return null
        val trimmedEn = nameEn.trim()
        if (trimmedEn.isEmpty()) return null
        val cat = ExpenseCategory(
            id = "CAT-CUST-${UUID.randomUUID().toString().take(6).uppercase()}",
            nameEn = trimmedEn,
            nameBn = nameBn.trim().ifBlank { trimmedEn },
            isDefault = false
        )
        withContext(Dispatchers.IO) {
            dbHelper.upsertExpenseCategory(cat)
            _expenseCategories.value = dbHelper.readExpenseCategories()
        }
        return cat
    }

    override suspend fun addOrUpdateExpense(
        expense: SiteExpense,
        pendingReceiptUri: Uri?,
        removeExistingReceipt: Boolean,
        role: UserRole
    ): Boolean {
        if (!canRoleAccessSite(role, expense.siteId)) return false
        if (expense.amount <= 0 || expense.title.isBlank()) return false

        val existing = _expenses.value.find { it.id == expense.id }
        val prevPath = existing?.receiptPhotoPath
        val nextPath: String? = when {
            pendingReceiptUri != null -> photoStorage.savePickedReceiptPhoto(expense.id, pendingReceiptUri)
            removeExistingReceipt -> null
            else -> prevPath
        }
        val finalExpense = expense.copy(
            receiptPhotoPath = nextPath,
            createdAtIso = existing?.createdAtIso?.ifBlank { currentTimestampIso() } ?: currentTimestampIso()
        )
        val audit = ExpenseAuditEntry(
            auditId = "AUD-EXP-${UUID.randomUUID().toString().take(8)}",
            expenseId = finalExpense.id,
            siteId = finalExpense.siteId,
            action = if (existing == null) "CREATED" else "EDITED",
            previousAmount = existing?.amount,
            newAmount = finalExpense.amount,
            changedByRole = role,
            changedAtIso = currentTimestampIso(),
            reason = if (existing == null) finalExpense.title else "Edited expense"
        )
        val syncEvent = SyncEvent("SYN-${UUID.randomUUID().toString().take(8)}", "EXPENSE", finalExpense.id, finalExpense.siteId, audit.action, currentTimestampIso())

        withContext(Dispatchers.IO) {
            dbHelper.upsertExpenseWithAudit(finalExpense, audit, syncEvent)
            _expenses.value = dbHelper.readAllExpenses()
            _expenseAudits.value = dbHelper.readExpenseAudits()

            if (prevPath != null && prevPath != nextPath) {
                val stillRef = dbHelper.countExpensesWithReceiptPath(prevPath) > 0
                photoStorage.deletePhotoIfUnreferenced(prevPath, stillRef)
            }
        }
        return true
    }

    override suspend fun voidExpense(expenseId: String, role: UserRole, reason: String): Boolean {
        val existing = _expenses.value.find { it.id == expenseId } ?: return false
        if (!canRoleAccessSite(role, existing.siteId) || existing.isVoided) return false
        if (role == UserRole.MANAGER) return false

        val voided = existing.copy(isVoided = true)
        val audit = ExpenseAuditEntry(
            auditId = "AUD-EXP-${UUID.randomUUID().toString().take(8)}",
            expenseId = existing.id,
            siteId = existing.siteId,
            action = "VOIDED",
            previousAmount = existing.amount,
            newAmount = 0,
            changedByRole = role,
            changedAtIso = currentTimestampIso(),
            reason = reason.ifBlank { "Reversed expense" }
        )
        withContext(Dispatchers.IO) {
            dbHelper.upsertExpenseWithAudit(voided, audit)
            _expenses.value = dbHelper.readAllExpenses()
            _expenseAudits.value = dbHelper.readExpenseAudits()
        }
        return true
    }

    override fun suggestedBackupFileName(): String = backupManager.suggestedBackupFileName()

    override suspend fun recoverInterruptedRestoreIfNeeded(): RestoreRecoveryReport {
        val report = backupManager.recoverInterruptedRestoreIfNeeded { progress ->
            _backupProgress.value = progress
        }
        if (report.recoveryAttempted && report.recoverySucceeded) {
            withContext(Dispatchers.IO) {
                reloadAllFromDatabase()
            }
        }
        return report
    }

    override suspend fun createFullBackupToUri(targetUri: Uri): Result<BackupHistoryRecord> {
        val res = backupManager.createFullBackupToUri(targetUri) { progress ->
            _backupProgress.value = progress
        }
        _backupHistory.value = attachAvailability(dbHelper.readBackupHistory())
        return res
    }

    override suspend fun inspectBackupUri(sourceUri: Uri): BackupValidationResult =
        backupManager.inspectAndVerifyBackupUri(sourceUri) { progress ->
            _backupProgress.value = progress
        }

    override suspend fun restoreFromBackupUri(sourceUri: Uri): Result<BackupValidationResult> {
        val res = backupManager.restoreFromBackupUri(sourceUri) { progress ->
            _backupProgress.value = progress
        }
        if (res.isSuccess) {
            reloadAllFromDatabase()
        } else {
            // Also reload if an automatic rollback restored the prior DB
            runCatching { reloadAllFromDatabase() }
        }
        return res
    }

    override suspend fun refreshBackupHistoryAvailability() {
        withContext(Dispatchers.IO) {
            _backupHistory.value = attachAvailability(dbHelper.readBackupHistory())
        }
    }

    private fun attachAvailability(records: List<BackupHistoryRecord>): List<BackupHistoryRecord> =
        records.map { it.copy(fileExists = backupManager.isBackupLocationAvailable(it.locationUriOrPath)) }

    private fun reloadAllFromDatabase() {
        _sites.value = dbHelper.readAllSites()
        _workers.value = dbHelper.readAllWorkers()
        _workerTransfers.value = dbHelper.readWorkerSiteHistory()
        _attendanceRecords.value = dbHelper.readAllAttendance()
        _attendanceAudits.value = dbHelper.readAttendanceAudits()
        _payments.value = dbHelper.readAllPayments()
        _advances.value = dbHelper.readAllAdvances()
        _paymentAllocations.value = dbHelper.readAllAllocations()
        _paymentAudits.value = dbHelper.readPaymentAudits()
        _payrollPeriods.value = dbHelper.readPayrollPeriods()
        _payrollAudits.value = dbHelper.readPayrollAudits()
        _dutyMultipliers.value = dbHelper.readDutyMultipliers(DEFAULT_SITE_ID)
        _expenseCategories.value = dbHelper.readExpenseCategories()
        _expenses.value = dbHelper.readAllExpenses()
        _expenseAudits.value = dbHelper.readExpenseAudits()
        _userSiteAccounts.value = dbHelper.readUserSiteAccounts()
        _backupHistory.value = attachAvailability(dbHelper.readBackupHistory())
    }

    override suspend fun resetSampleData() {
        withContext(Dispatchers.IO) {
            val db = dbHelper.writableDatabase
            val existingWorkerPhotos = dbHelper.readAllWorkers().mapNotNull { it.photoPath }.distinct()
            val existingReceipts = dbHelper.readAllExpenses().mapNotNull { it.receiptPhotoPath }.distinct()
            db.beginTransaction()
            try {
                listOf(
                    SiteLedgerDatabaseContract.ExpenseAuditTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.ExpensesTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.ExpenseCategoriesTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.WorkerSiteHistoryTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.PayrollAuditTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.PayrollPeriodsTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.PaymentAllocationsTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.AdvancesTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.PaymentAuditTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.AttendanceAuditTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.PaymentsTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.AttendanceTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.WorkersTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.DutySettingsTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.UserSiteAssignmentsTable.TABLE_NAME,
                    SiteLedgerDatabaseContract.SitesTable.TABLE_NAME
                ).forEach { db.delete(it, null, null) }

                dbHelper.seedDefaultExpenseCategoriesIfEmpty(db)
                dbHelper.seedDefaultUserAssignmentsIfEmpty(db)
                dbHelper.seedInitialSampleDataIfEmpty(db)
                dbHelper.seedDefaultDutyMultipliersIfEmpty(db, DEFAULT_SITE_ID)
                dbHelper.seedDefaultDutyMultipliersIfEmpty(db, SampleSiteData.ANNEX_SITE_ID)
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            (existingWorkerPhotos + existingReceipts).forEach { path ->
                photoStorage.deletePhotoIfUnreferenced(path, isStillReferenced = false)
            }
            reloadAllFromDatabase()
        }
    }

    private fun currentTimestampIso(): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date())
}

class InMemorySampleSiteLedgerRepository : SiteLedgerRepository {
    private val _sites = MutableStateFlow(SampleSiteData.initialSites)
    override val sites: StateFlow<List<Site>> = _sites.asStateFlow()

    private val _workers = MutableStateFlow(SampleSiteData.workers)
    override val workers: StateFlow<List<Worker>> = _workers.asStateFlow()

    private val _workerTransfers = MutableStateFlow(SampleSiteData.initialTransfers)
    override val workerTransfers: StateFlow<List<WorkerSiteHistory>> = _workerTransfers.asStateFlow()

    private val _attendanceRecords = MutableStateFlow(SampleSiteData.initialAttendance)
    override val attendanceRecords: StateFlow<List<DailyAttendanceRecord>> = _attendanceRecords.asStateFlow()

    private val _attendanceAudits = MutableStateFlow<List<AttendanceAuditEntry>>(emptyList())
    override val attendanceAudits: StateFlow<List<AttendanceAuditEntry>> = _attendanceAudits.asStateFlow()

    private val _payments = MutableStateFlow(SampleSiteData.initialPayments)
    override val payments: StateFlow<List<PaymentLedgerEntry>> = _payments.asStateFlow()

    private val _advances = MutableStateFlow(SampleSiteData.initialAdvances)
    override val advances: StateFlow<List<AdvanceRecord>> = _advances.asStateFlow()

    private val _paymentAllocations = MutableStateFlow(SampleSiteData.initialAllocations)
    override val paymentAllocations: StateFlow<List<PaymentAllocation>> = _paymentAllocations.asStateFlow()

    private val _paymentAudits = MutableStateFlow<List<PaymentAuditEntry>>(emptyList())
    override val paymentAudits: StateFlow<List<PaymentAuditEntry>> = _paymentAudits.asStateFlow()

    private val _payrollPeriods = MutableStateFlow(SampleSiteData.initialPayrollPeriods)
    override val payrollPeriods: StateFlow<List<PayrollPeriodRecord>> = _payrollPeriods.asStateFlow()

    private val _payrollAudits = MutableStateFlow<List<PayrollAuditEntry>>(emptyList())
    override val payrollAudits: StateFlow<List<PayrollAuditEntry>> = _payrollAudits.asStateFlow()

    private val _dutyMultipliers = MutableStateFlow(DutyMultiplierConfig())
    override val dutyMultipliers: StateFlow<DutyMultiplierConfig> = _dutyMultipliers.asStateFlow()

    private val _expenseCategories = MutableStateFlow(SampleSiteData.defaultExpenseCategories)
    override val expenseCategories: StateFlow<List<ExpenseCategory>> = _expenseCategories.asStateFlow()

    private val _expenses = MutableStateFlow(SampleSiteData.initialExpenses)
    override val expenses: StateFlow<List<SiteExpense>> = _expenses.asStateFlow()

    private val _expenseAudits = MutableStateFlow<List<ExpenseAuditEntry>>(emptyList())
    override val expenseAudits: StateFlow<List<ExpenseAuditEntry>> = _expenseAudits.asStateFlow()

    private val _userSiteAccounts = MutableStateFlow(SampleSiteData.defaultUserSiteAccounts)
    override val userSiteAccounts: StateFlow<List<UserSiteAccount>> = _userSiteAccounts.asStateFlow()

    private val _backupHistory = MutableStateFlow<List<BackupHistoryRecord>>(emptyList())
    override val backupHistory: StateFlow<List<BackupHistoryRecord>> = _backupHistory.asStateFlow()

    private val _backupProgress = MutableStateFlow(BackupProgress())
    override val backupProgress: StateFlow<BackupProgress> = _backupProgress.asStateFlow()

    private val _monthlyExpenses = MutableStateFlow(SampleSiteData.monthlyExpenseBaseline)
    override val monthlyExpenses: StateFlow<MonthlyExpenseBreakdown> = _monthlyExpenses.asStateFlow()

    private val processedTokens = mutableSetOf<String>()

    override fun canRoleAccessSite(role: UserRole, siteId: String): Boolean {
        if (role == UserRole.ADMIN) return true
        return _userSiteAccounts.value.find { it.role == role }?.assignedSiteIds?.contains(siteId) ?: true
    }

    override fun getAccessibleSiteIds(role: UserRole): Set<String> {
        if (role == UserRole.ADMIN) return _sites.value.map { it.id }.toSet()
        return _userSiteAccounts.value.find { it.role == role }?.assignedSiteIds?.toSet() ?: emptySet()
    }

    override fun isPeriodFinalized(siteId: String, periodIso: String): Boolean =
        _payrollPeriods.value.find { it.siteId == siteId && it.periodIso == periodIso }?.status == PayrollPeriodStatus.FINALIZED

    override fun getDutyMultipliersForSite(siteId: String): DutyMultiplierConfig = _dutyMultipliers.value

    override suspend fun addOrUpdateSite(site: Site, role: UserRole): Boolean {
        if (role != UserRole.ADMIN) return false
        _sites.update { list -> list.filterNot { it.id == site.id } + site }
        return true
    }

    override suspend fun archiveOrUpdateSiteStatus(siteId: String, newStatus: SiteStatus, role: UserRole): Boolean {
        if (role != UserRole.ADMIN) return false
        _sites.update { list -> list.map { if (it.id == siteId) it.copy(status = newStatus) else it } }
        return true
    }

    override suspend fun updateUserSiteAssignments(roleToUpdate: UserRole, assignedSiteIds: List<String>, actingRole: UserRole): Boolean {
        if (actingRole != UserRole.ADMIN) return false
        _userSiteAccounts.update { list ->
            list.map { if (it.role == roleToUpdate) it.copy(assignedSiteIds = assignedSiteIds.distinct()) else it }
        }
        return true
    }

    override suspend fun addWorker(worker: Worker, pendingPhotoUri: Uri?, role: UserRole): Boolean {
        if (!canRoleAccessSite(role, worker.siteId)) return false
        if (WageCalculator.isLocalWorkerCodeDuplicate(worker.siteId, worker.localWorkerCode, null, _workers.value)) return false
        _workers.update { listOf(worker) + it }
        return true
    }

    override suspend fun updateWorker(updatedWorker: Worker, pendingPhotoUri: Uri?, removeExistingPhoto: Boolean, role: UserRole): Boolean {
        if (!canRoleAccessSite(role, updatedWorker.siteId)) return false
        if (WageCalculator.isLocalWorkerCodeDuplicate(updatedWorker.siteId, updatedWorker.localWorkerCode, updatedWorker.id, _workers.value)) return false
        _workers.update { list -> list.map { if (it.id == updatedWorker.id) updatedWorker else it } }
        return true
    }

    override suspend fun transferWorker(workerId: String, targetSiteId: String, newLocalWorkerCode: String?, notes: String, role: UserRole): Boolean {
        if (role != UserRole.ADMIN) return false
        val worker = _workers.value.find { it.id == workerId } ?: return false
        val code = newLocalWorkerCode?.trim().takeIf { !it.isNullOrBlank() } ?: worker.localWorkerCode
        if (WageCalculator.isLocalWorkerCodeDuplicate(targetSiteId, code, worker.id, _workers.value)) return false
        _workers.update { list -> list.map { if (it.id == workerId) it.copy(siteId = targetSiteId, localWorkerCode = code) else it } }
        _workerTransfers.update { listOf(WorkerSiteHistory("TRF-${it.size + 1}", workerId, worker.siteId, targetSiteId, "2026-11-15", role, notes)) + it }
        return true
    }

    override suspend fun recordAttendance(siteId: String, dateIso: String, worker: Worker, dutyType: DutyType, note: String, role: UserRole, editReason: String): Boolean {
        if (!canRoleAccessSite(role, siteId) || isPeriodFinalized(siteId, dateIso.take(7))) return false
        val multiplier = _dutyMultipliers.value.multiplierFor(dutyType)
        val existing = _attendanceRecords.value.find { it.siteId == siteId && it.dateIso == dateIso && it.workerId == worker.id }
        val wage = existing?.dailyWageSnapshot ?: worker.dailyWage
        val earned = WageCalculator.calculateDailyEarnedTaka(wage, multiplier)
        val record = DailyAttendanceRecord(dateIso, worker.id, dutyType, wage, multiplier, earned, note, "2026-11-15T18:00:00", role, siteId)
        _attendanceRecords.update { list -> list.filterNot { it.siteId == siteId && it.dateIso == dateIso && it.workerId == worker.id } + record }
        return true
    }

    override suspend fun recordPaymentTransaction(siteId: String, workerId: String, paymentDateIso: String, applicablePeriod: String, paidAmount: Int, referenceNo: String, note: String, role: UserRole, submissionToken: String): Boolean {
        if (!canRoleAccessSite(role, siteId) || role == UserRole.MANAGER || paidAmount <= 0 || isPeriodFinalized(siteId, applicablePeriod)) return false
        if (!processedTokens.add(submissionToken)) return false
        val txId = "TXN-${510 + _payments.value.size}"
        val entry = PaymentLedgerEntry(txId, workerId, paymentDateIso, applicablePeriod, PaymentType.SALARY, paidAmount, referenceNo, note, note, role, "2026-11-15T18:00:00", false, siteId)
        val alloc = PaymentAllocation("ALLOC-$txId", "PAYMENT", txId, workerId, applicablePeriod, paidAmount, "2026-11-15T18:00:00", role, note, false, siteId)
        _payments.update { listOf(entry) + it }
        _paymentAllocations.update { listOf(alloc) + it }
        return true
    }

    override suspend fun recordAdvance(siteId: String, workerId: String, advanceDateIso: String, amount: Int, referenceNo: String, note: String, role: UserRole, submissionToken: String): Boolean {
        if (!canRoleAccessSite(role, siteId) || role == UserRole.MANAGER || amount <= 0 || !processedTokens.add(submissionToken)) return false
        val advId = "ADV-${210 + _advances.value.size}"
        _advances.update { listOf(AdvanceRecord(advId, workerId, advanceDateIso, amount, referenceNo, note, role, "2026-11-15T18:00:00", false, siteId)) + it }
        return true
    }

    override suspend fun allocateAdvanceToPeriod(advanceId: String, targetPeriod: String, amountToAllocate: Int, role: UserRole, note: String): Boolean {
        val adv = _advances.value.find { it.id == advanceId && !it.isVoided } ?: return false
        if (!canRoleAccessSite(role, adv.siteId) || role == UserRole.MANAGER || amountToAllocate <= 0 || isPeriodFinalized(adv.siteId, targetPeriod)) return false
        val rem = WageCalculator.computeAdvanceRemaining(adv, _paymentAllocations.value)
        if (amountToAllocate > rem) return false
        val alloc = PaymentAllocation("ALLOC-ADV-${_paymentAllocations.value.size + 1}", "ADVANCE", adv.id, adv.workerId, targetPeriod, amountToAllocate, "2026-11-15T18:00:00", role, note, false, adv.siteId)
        _paymentAllocations.update { listOf(alloc) + it }
        return true
    }

    override suspend fun voidPaymentTransaction(transactionId: String, role: UserRole, reason: String): Boolean {
        val existing = _payments.value.find { it.id == transactionId } ?: return false
        if (!canRoleAccessSite(role, existing.siteId) || role == UserRole.MANAGER || existing.isVoided || isPeriodFinalized(existing.siteId, existing.applicablePeriod)) return false
        _payments.update { list -> list.map { if (it.id == transactionId) it.copy(isVoided = true) else it } }
        _paymentAllocations.update { list -> list.map { if (it.sourceType == "PAYMENT" && it.sourceId == transactionId) it.copy(isVoided = true) else it } }
        return true
    }

    override suspend fun finalizePayrollPeriod(siteId: String, periodIso: String, role: UserRole, reason: String): Boolean {
        if (role != UserRole.ADMIN) return false
        _payrollPeriods.update { list ->
            list.filterNot { it.siteId == siteId && it.periodIso == periodIso } + PayrollPeriodRecord(periodIso, PayrollPeriodStatus.FINALIZED, "2026-11-15T18:00:00", role, null, null, reason, siteId)
        }
        return true
    }

    override suspend fun reopenPayrollPeriod(siteId: String, periodIso: String, role: UserRole, reason: String): Boolean {
        if (role != UserRole.ADMIN) return false
        val cur = _payrollPeriods.value.find { it.siteId == siteId && it.periodIso == periodIso } ?: return false
        _payrollPeriods.update { list ->
            list.filterNot { it.siteId == siteId && it.periodIso == periodIso } + cur.copy(status = PayrollPeriodStatus.OPEN, reopenedAtIso = "2026-11-15T18:00:00", reopenedByRole = role, notes = reason)
        }
        return true
    }

    override suspend fun updateDutyMultipliers(config: DutyMultiplierConfig) { _dutyMultipliers.value = config }

    override suspend fun addExpenseCategory(nameEn: String, nameBn: String, role: UserRole): ExpenseCategory? {
        if (role != UserRole.ADMIN || nameEn.isBlank()) return null
        val cat = ExpenseCategory("CAT-CUST-${_expenseCategories.value.size + 1}", nameEn.trim(), nameBn.trim().ifBlank { nameEn.trim() }, false)
        _expenseCategories.update { it + cat }
        return cat
    }

    override suspend fun addOrUpdateExpense(expense: SiteExpense, pendingReceiptUri: Uri?, removeExistingReceipt: Boolean, role: UserRole): Boolean {
        if (!canRoleAccessSite(role, expense.siteId) || expense.amount <= 0) return false
        _expenses.update { list -> list.filterNot { it.id == expense.id } + expense }
        return true
    }

    override suspend fun voidExpense(expenseId: String, role: UserRole, reason: String): Boolean {
        val existing = _expenses.value.find { it.id == expenseId } ?: return false
        if (!canRoleAccessSite(role, existing.siteId) || role == UserRole.MANAGER || existing.isVoided) return false
        _expenses.update { list -> list.map { if (it.id == expenseId) it.copy(isVoided = true) else it } }
        return true
    }

    override fun suggestedBackupFileName(): String = "SITE_LEDGER_BACKUP_2026_11_15_18_00.zip"
    override suspend fun recoverInterruptedRestoreIfNeeded(): RestoreRecoveryReport = RestoreRecoveryReport()
    override suspend fun createFullBackupToUri(targetUri: Uri): Result<BackupHistoryRecord> = Result.failure(UnsupportedOperationException("Use SQLite repository"))
    override suspend fun inspectBackupUri(sourceUri: Uri): BackupValidationResult = BackupValidationResult(false, "", "", "", 0, 0, com.siteledger.app.domain.model.BackupRecordCounts(), false, false, false, 0, listOf("Sample mode"))
    override suspend fun restoreFromBackupUri(sourceUri: Uri): Result<BackupValidationResult> = Result.failure(UnsupportedOperationException("Use SQLite repository"))
    override suspend fun refreshBackupHistoryAvailability() {}

    override suspend fun resetSampleData() {
        processedTokens.clear()
        _sites.value = SampleSiteData.initialSites
        _workers.value = SampleSiteData.workers
        _workerTransfers.value = SampleSiteData.initialTransfers
        _attendanceRecords.value = SampleSiteData.initialAttendance
        _payments.value = SampleSiteData.initialPayments
        _advances.value = SampleSiteData.initialAdvances
        _paymentAllocations.value = SampleSiteData.initialAllocations
        _payrollPeriods.value = SampleSiteData.initialPayrollPeriods
        _expenseCategories.value = SampleSiteData.defaultExpenseCategories
        _expenses.value = SampleSiteData.initialExpenses
        _userSiteAccounts.value = SampleSiteData.defaultUserSiteAccounts
    }
}
