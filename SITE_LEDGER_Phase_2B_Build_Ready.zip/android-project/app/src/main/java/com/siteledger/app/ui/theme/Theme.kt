package com.siteledger.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val SiteLedgerColorScheme = lightColorScheme(
    primary = EngineeringBlue,
    onPrimary = CrispWhite,
    primaryContainer = SoftBlueTint,
    onPrimaryContainer = DeepNavyBlue,
    secondary = SlateMuted,
    onSecondary = CrispWhite,
    background = CanvasGrey,
    onBackground = SlateInk,
    surface = CrispWhite,
    onSurface = SlateInk,
    surfaceVariant = CanvasGrey,
    onSurfaceVariant = SlateMuted,
    outline = SubtleBorderGrey
)

@Composable
fun SiteLedgerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SiteLedgerColorScheme,
        typography = SiteLedgerTypography,
        content = content
    )
}
