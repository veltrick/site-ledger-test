package com.siteledger.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyMultiplierConfig
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.PayrollPeriodStatus
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.service.WageCalculator
import com.siteledger.app.ui.components.SampleDataNoticeBanner
import com.siteledger.app.ui.components.WorkerAvatar
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusAmber
import com.siteledger.app.ui.theme.StatusGreen
import com.siteledger.app.ui.theme.SubtleBorderGrey
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AttendanceScreen(
    strings: AppStrings,
    language: AppLanguage,
    activeRole: UserRole,
    dutyConfig: DutyMultiplierConfig,
    availableDates: List<String>,
    selectedDate: String,
    onSelectDate: (String) -> Unit,
    workers: List<Worker>,
    records: List<DailyAttendanceRecord>,
    payrollPeriods: List<PayrollPeriodRecord>,
    onMarkDuty: (worker: Worker, dutyType: DutyType, note: String, reason: String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var pendingConfirm by remember {
        mutableStateOf<Triple<Worker, DutyType, DailyAttendanceRecord?>?>(null)
    }
    var pendingNote by remember { mutableStateOf("") }

    val dateMap = remember(records, selectedDate) {
        records.filter { it.dateIso == selectedDate }.associateBy { it.workerId }
    }
    val selectedPeriodIso = selectedDate.take(7)
    val isPeriodFinalized = remember(payrollPeriods, selectedPeriodIso) {
        payrollPeriods.find { it.periodIso == selectedPeriodIso }?.status == PayrollPeriodStatus.FINALIZED
    }

    val filteredWorkers = remember(workers, searchQuery) {
        workers.filter { w ->
            w.isActive && (searchQuery.isBlank() ||
                w.fullNameEn.contains(searchQuery, ignoreCase = true) ||
                w.fullNameBn.contains(searchQuery, ignoreCase = true) ||
                w.id.contains(searchQuery, ignoreCase = true))
        }
    }

    val dayRecords = dateMap.values.toList()
    val totalUnits = WageCalculator.sumDutyUnits(dayRecords)
    val totalDayEarned = dayRecords.sumOf { it.earnedAmount }
    val canEdit = activeRole != UserRole.ACCOUNTANT && !isPeriodFinalized

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { SampleDataNoticeBanner(noticeText = strings.sampleDataNotice) }

        item {
            Text(strings.selectDate, style = MaterialTheme.typography.labelMedium, color = SlateMuted)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                items(availableDates) { dateIso ->
                    FilterChip(
                        selected = dateIso == selectedDate,
                        onClick = { onSelectDate(dateIso) },
                        label = { Text(dateIso) }
                    )
                }
            }
        }

        if (isPeriodFinalized) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFFEF3C7))
                        .border(1.dp, StatusAmber, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Text(strings.payrollLockedWarning, style = MaterialTheme.typography.bodySmall, color = StatusAmber)
                }
            }
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(strings.searchWorkersPlaceholder) },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Text("${strings.totalDutyUnits}: ${String.format(Locale.US, "%.1f", totalUnits)}", color = EngineeringBlue, fontWeight = FontWeight.SemiBold)
                    Text("${strings.earnedAmountLabel}: ৳$totalDayEarned", color = StatusGreen, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        items(filteredWorkers, key = { it.id }) { worker ->
            val existing = dateMap[worker.id]
            val displayName = if (language == AppLanguage.BENGALI) worker.fullNameBn else worker.fullNameEn

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            WorkerAvatar(name = displayName, photoPath = worker.photoPath, size = 40.dp)
                            Column {
                                Text(displayName, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                                Text("${worker.id} · ৳${worker.dailyWage}/day", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                            }
                        }
                        Text(
                            text = if (existing != null) "৳${existing.earnedAmount}" else strings.notRecordedLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (existing != null) EngineeringBlue else SlateMuted
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        DutyType.entries.forEach { dutyType ->
                            val label = if (language == AppLanguage.BENGALI) dutyType.labelBn else dutyType.labelEn
                            val mult = dutyConfig.multiplierFor(dutyType)
                            val isSelected = existing?.dutyType == dutyType
                            FilterChip(
                                selected = isSelected,
                                enabled = canEdit,
                                onClick = {
                                    pendingNote = existing?.note ?: ""
                                    pendingConfirm = Triple(worker, dutyType, existing)
                                },
                                label = { Text("$label (${mult}x)") }
                            )
                        }
                    }
                }
            }
        }
    }

    pendingConfirm?.let { (worker, dutyType, existing) ->
        val wageBase = existing?.dailyWageSnapshot ?: worker.dailyWage
        val mult = dutyConfig.multiplierFor(dutyType)
        val previewEarned = WageCalculator.calculateDailyEarnedTaka(wageBase, mult)
        val dutyLabel = if (language == AppLanguage.BENGALI) dutyType.labelBn else dutyType.labelEn

        AlertDialog(
            onDismissRequest = { pendingConfirm = null },
            title = { Text("${if (language == AppLanguage.BENGALI) worker.fullNameBn else worker.fullNameEn} · $selectedDate") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        DutyType.entries.forEach { option ->
                            val optionLabel = if (language == AppLanguage.BENGALI) option.labelBn else option.labelEn
                            val optionMult = dutyConfig.multiplierFor(option)
                            FilterChip(
                                selected = option == dutyType,
                                onClick = { pendingConfirm = Triple(worker, option, existing) },
                                label = { Text("$optionLabel (${optionMult}x)") }
                            )
                        }
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                        border = BorderStroke(1.dp, EngineeringBlue)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("${strings.dutyTypeLabel}: $dutyLabel", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                            Text("${strings.dutyMultiplierLabel}: ${mult}x", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                            Text("${strings.savedDailyWageLabel}: ৳$wageBase", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                            Text(
                                text = "${strings.earnedAmountLabel}: ৳$wageBase × $mult = ৳$previewEarned",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = EngineeringBlue
                            )
                        }
                    }
                    OutlinedTextField(
                        value = pendingNote,
                        onValueChange = { pendingNote = it },
                        label = { Text(strings.notesLabel) },
                        singleLine = true
                    )
                    if (existing != null) {
                        Text(strings.confirmEditAttendanceMsg, style = MaterialTheme.typography.bodySmall, color = StatusAmber)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onMarkDuty(worker, dutyType, pendingNote, if (existing != null) "Daily sheet update" else "Initial")
                    pendingConfirm = null
                }) {
                    Text(strings.confirmAction)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingConfirm = null }) { Text(strings.cancel) }
            }
        )
    }
}
