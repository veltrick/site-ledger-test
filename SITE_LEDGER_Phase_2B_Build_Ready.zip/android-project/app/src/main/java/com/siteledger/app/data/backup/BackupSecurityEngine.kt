package com.siteledger.app.data.backup

import com.siteledger.app.data.local.SiteLedgerDatabaseContract
import com.siteledger.app.data.local.WorkerPhotoStorage
import com.siteledger.app.domain.model.BackupHistoryRecord
import com.siteledger.app.domain.model.BackupProgress
import com.siteledger.app.domain.model.BackupRecordCounts
import com.siteledger.app.domain.model.BackupValidationResult
import com.siteledger.app.domain.model.RestoreJournalStatus
import com.siteledger.app.domain.model.RestoreRecoveryReport
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class WalCheckpointResult(
    val success: Boolean,
    val busy: Int = 0,
    val logPages: Int = -1,
    val checkpointedPages: Int = -1,
    val errorMessage: String? = null
)

data class SqliteInspectionResult(
    val integrityOk: Boolean,
    val missingTables: List<String>,
    val counts: BackupRecordCounts,
    val referencedWorkerPhotos: List<String>,
    val referencedReceiptImages: List<String>,
    val errorMessage: String? = null
)

interface BackupSqliteBridge {
    fun checkpointLiveDatabase(): WalCheckpointResult
    fun copyLiveDatabaseTo(destFile: File): Boolean
    fun inspectDatabaseFile(dbFile: File, expectedSchemaVersion: Int): SqliteInspectionResult
    fun closeDatabaseBeforeSwap()
    fun reopenAndVerifyDatabase(expectedSchemaVersion: Int): SqliteInspectionResult
    fun readLatestBackupTimestamp(): String?
}

class BackupRestoreException(
    val failedStage: String,
    val recoveryAttempted: Boolean,
    val recoverySucceeded: Boolean,
    val safetyBackupPath: String?,
    message: String,
    cause: Throwable? = null
) : IllegalStateException(message, cause)

data class RestoreFaultHooks(
    val failAtStage: String? = null,
    val simulateCrashAtJournalStatus: RestoreJournalStatus? = null
)

class SimulatedProcessCrashException(stage: String) :
    RuntimeException("Simulated process termination at $stage")

/**
 * Pure-JVM, crash-safe Backup Validation, Staged Restore, and Startup Recovery Engine.
 *
 * Restores execute through 9 verifiable stages using persistent directories under filesDir:
 *   Stage 1: Select backup ZIP (SAF in Android wrapper)
 *   Stage 2: Validate complete archive without modifying live data
 *   Stage 3: Extract validated payload into persistent staging directory
 *   Stage 4: Re-verify staged SQLite integrity, counts, referenced media, and checksums
 *   Stage 5: Create & verify pre-restore safety backup in safety_backups/
 *   Stage 6: Prepare rollback snapshot & replacement directories
 *   Stage 7: Replace live DB and media with persistent journal (SWAPPING)
 *   Stage 8: Reopen SQLite, run integrity_check, verify counts & media files on disk (VERIFYING)
 *   Stage 9: Mark journal COMPLETED & keep permanent safety backup intact
 */
class BackupSecurityEngine(
    private val workspaceRootDir: File,
    private val liveDbFile: File,
    private val livePhotosDir: File,
    private val liveReceiptsDir: File,
    private val safetyBackupsDir: File,
    private val sqliteBridge: BackupSqliteBridge,
    private val appVersionName: String = CURRENT_APP_VERSION,
    private val supportedDbSchemaVersion: Int = SiteLedgerDatabaseContract.DATABASE_VERSION
) {
    private val stagingRootDir: File
        get() = File(workspaceRootDir, "restore_staging").apply { mkdirs() }

    private val rollbackRootDir: File
        get() = File(workspaceRootDir, "restore_rollback").apply { mkdirs() }

    private val journalDir: File
        get() = File(workspaceRootDir, "restore_state").apply { mkdirs() }

    val journalFile: File
        get() = File(journalDir, "restore_journal.json")

    fun recoverInterruptedRestoreIfNeeded(
        onProgress: (BackupProgress) -> Unit = {}
    ): RestoreRecoveryReport {
        val journal = readJournal()
            ?: return RestoreRecoveryReport(recoveryNeeded = false)

        return when (journal.status) {
            RestoreJournalStatus.NONE,
            RestoreJournalStatus.COMPLETED,
            RestoreJournalStatus.ROLLED_BACK -> {
                cleanSafeTempDir(journal.stagingDirPath)
                cleanSafeTempDir(journal.rollbackDirPath)
                RestoreRecoveryReport(
                    recoveryNeeded = false,
                    recoveryAttempted = false,
                    recoverySucceeded = true,
                    previousStatus = journal.status,
                    safetyBackupPath = journal.safetyBackupPath
                )
            }

            RestoreJournalStatus.STAGING,
            RestoreJournalStatus.VALIDATED_STAGE,
            RestoreJournalStatus.SAFETY_BACKUP_CREATED -> {
                // Live DB and media were not modified yet before crash. Clean staging safely.
                cleanSafeTempDir(journal.stagingDirPath)
                cleanSafeTempDir(journal.rollbackDirPath)
                writeJournal(
                    journal.copy(
                        status = RestoreJournalStatus.ROLLED_BACK,
                        updatedAtIso = nowIso(),
                        lastError = "Cleaned interrupted pre-swap restore stage (${journal.status.name}). Live data untouched."
                    )
                )
                RestoreRecoveryReport(
                    recoveryNeeded = true,
                    recoveryAttempted = true,
                    recoverySucceeded = true,
                    previousStatus = journal.status,
                    safetyBackupPath = journal.safetyBackupPath,
                    message = "Cleaned interrupted pre-swap restore (${journal.status.name}). Live database preserved."
                )
            }

            RestoreJournalStatus.SWAPPING,
            RestoreJournalStatus.VERIFYING,
            RestoreJournalStatus.FAILED_NEEDS_RECOVERY -> {
                onProgress(BackupProgress(true, "RECOVERY", 25, "Interrupted restore detected; restoring previous data..."))
                val recoveredFromRollback = attemptRollbackDirRecovery(journal.rollbackDirPath)
                val recovered = if (recoveredFromRollback) {
                    true
                } else {
                    attemptSafetyZipRecovery(journal.safetyBackupPath)
                }

                if (recovered) {
                    val verifyLive = sqliteBridge.reopenAndVerifyDatabase(supportedDbSchemaVersion)
                    if (verifyLive.integrityOk && verifyLive.missingTables.isEmpty()) {
                        cleanSafeTempDir(journal.stagingDirPath)
                        cleanSafeTempDir(journal.rollbackDirPath)
                        writeJournal(
                            journal.copy(
                                status = RestoreJournalStatus.ROLLED_BACK,
                                updatedAtIso = nowIso(),
                                lastError = "Recovered safely from interrupted restore (${journal.status.name})"
                            )
                        )
                        onProgress(BackupProgress(false, "RECOVERY", 100, "Previous valid data recovered"))
                        RestoreRecoveryReport(
                            recoveryNeeded = true,
                            recoveryAttempted = true,
                            recoverySucceeded = true,
                            previousStatus = journal.status,
                            stillRequiresManualRecovery = false,
                            safetyBackupPath = journal.safetyBackupPath,
                            message = "Interrupted restore detected (${journal.status.name}). Previous valid database & photos recovered cleanly."
                        )
                    } else {
                        markRecoveryFailed(journal, "Recovered DB failed integrity check: ${verifyLive.errorMessage ?: "unknown"}")
                    }
                } else {
                    markRecoveryFailed(journal, "Rollback snapshot and safety backup could not be applied")
                }
            }
        }
    }

    private fun markRecoveryFailed(journal: RestoreJournalData, reason: String): RestoreRecoveryReport {
        writeJournal(
            journal.copy(
                status = RestoreJournalStatus.FAILED_NEEDS_RECOVERY,
                updatedAtIso = nowIso(),
                lastError = reason
            )
        )
        return RestoreRecoveryReport(
            recoveryNeeded = true,
            recoveryAttempted = true,
            recoverySucceeded = false,
            previousStatus = journal.status,
            stillRequiresManualRecovery = true,
            safetyBackupPath = journal.safetyBackupPath,
            message = "Recovery required: $reason"
        )
    }

    fun createBackupArchiveToFile(
        destZipFile: File,
        displayFileName: String = destZipFile.name,
        backupId: String = "BKP-${UUID.randomUUID().toString().take(8).uppercase()}",
        onProgress: (BackupProgress) -> Unit = {}
    ): Result<BackupHistoryRecord> = runCatching {
        onProgress(BackupProgress(true, "BACKUP", 5, "Backup creation started..."))
        val destinationParent = destZipFile.absoluteFile.parentFile
            ?: error("Backup destination directory is unavailable")
        check(destinationParent.exists() || destinationParent.mkdirs()) { "Unable to create backup destination directory" }
        check(safetyBackupsDir.exists() || safetyBackupsDir.mkdirs()) { "Unable to create safety backup directory" }

        onProgress(BackupProgress(true, "BACKUP", 15, "Running WAL checkpoint..."))
        val wal = sqliteBridge.checkpointLiveDatabase()
        check(wal.success && wal.busy == 0 && (wal.logPages <= 0 || wal.checkpointedPages >= wal.logPages)) {
            wal.errorMessage ?: "WAL checkpoint incomplete (busy=${wal.busy}, log=${wal.logPages}, checkpointed=${wal.checkpointedPages})"
        }

        val stagedDb = File(stagingRootDir, "backup_snap_${UUID.randomUUID()}.db")
        // Keep the temporary archive beside its destination so the final rename stays
        // on one filesystem and the old destination is never deleted before commit.
        val tmpZip = File(destinationParent, "${destZipFile.name}.tmp.${UUID.randomUUID()}.zip")
        val createdAtIso = nowIso()

        try {
            check(sqliteBridge.copyLiveDatabaseTo(stagedDb) && stagedDb.exists() && stagedDb.length() > 0L) {
                "Failed to snapshot live SQLite database"
            }

            onProgress(BackupProgress(true, "BACKUP", 35, "Checking live SQLite integrity & media references..."))
            val dbInspection = sqliteBridge.inspectDatabaseFile(stagedDb, supportedDbSchemaVersion)
            check(dbInspection.integrityOk) {
                dbInspection.errorMessage ?: "SQLite PRAGMA integrity_check failed before backup"
            }
            check(dbInspection.missingTables.isEmpty()) {
                "Missing required SQLite tables: ${dbInspection.missingTables.joinToString(", ")}"
            }

            // Collect and verify all media files referenced by the database exist on disk
            val workerPhotoFiles = collectReferencedAndExistingMediaFiles(
                mediaDir = livePhotosDir,
                folderPrefix = WorkerPhotoStorage.PHOTOS_FOLDER_NAME,
                referencedPaths = dbInspection.referencedWorkerPhotos
            )
            val receiptFiles = collectReferencedAndExistingMediaFiles(
                mediaDir = liveReceiptsDir,
                folderPrefix = WorkerPhotoStorage.RECEIPTS_FOLDER_NAME,
                referencedPaths = dbInspection.referencedReceiptImages
            )

            val finalCounts = dbInspection.counts.copy(
                workerPhotos = workerPhotoFiles.size,
                receiptImages = receiptFiles.size
            )

            val checksums = linkedMapOf<String, String>()
            val dbEntryPath = "database/${SiteLedgerDatabaseContract.DATABASE_NAME}"
            checksums[dbEntryPath] = sha256File(stagedDb)

            workerPhotoFiles.forEach { (entryPath, file) ->
                checksums[entryPath] = sha256File(file)
            }
            receiptFiles.forEach { (entryPath, file) ->
                checksums[entryPath] = sha256File(file)
            }

            val schemaMetaBytes = MiniJson.stringify(
                linkedMapOf(
                    "databaseName" to SiteLedgerDatabaseContract.DATABASE_NAME,
                    "schemaVersion" to supportedDbSchemaVersion,
                    "formatVersion" to CURRENT_BACKUP_FORMAT_VERSION,
                    "appName" to APP_SIGNATURE,
                    "createdAtIso" to createdAtIso,
                    "walCheckpointed" to true,
                    "walLogPages" to wal.logPages,
                    "walCheckpointedPages" to wal.checkpointedPages,
                    "containsSecrets" to false
                )
            ).toByteArray(Charsets.UTF_8)
            checksums[SCHEMA_SUMMARY_ENTRY] = sha256Bytes(schemaMetaBytes)

            val manifestJson = buildManifestJson(
                createdAtIso = createdAtIso,
                counts = finalCounts,
                checksums = checksums,
                referencedWorkerPhotos = dbInspection.referencedWorkerPhotos,
                referencedReceiptImages = dbInspection.referencedReceiptImages
            )
            val manifestBytes = manifestJson.toByteArray(Charsets.UTF_8)

            onProgress(BackupProgress(true, "BACKUP", 70, "Writing verified ZIP package..."))
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmpZip))).use { zos ->
                writeZipEntry(zos, MANIFEST_ENTRY, manifestBytes)
                writeZipEntry(zos, SCHEMA_SUMMARY_ENTRY, schemaMetaBytes)
                writeZipFileEntry(zos, dbEntryPath, stagedDb)
                workerPhotoFiles.forEach { (entryPath, file) ->
                    writeZipFileEntry(zos, entryPath, file)
                }
                receiptFiles.forEach { (entryPath, file) ->
                    writeZipFileEntry(zos, entryPath, file)
                }
            }
            syncFile(tmpZip)

            check(tmpZip.renameTo(destZipFile)) {
                "Unable to atomically commit the verified backup archive; the previous destination was preserved"
            }
            syncFile(destZipFile)

            onProgress(BackupProgress(true, "BACKUP", 90, "Validating written archive..."))
            val verify = validateArchiveFile(destZipFile, displayFileName)
            check(verify.isValid) {
                "Written backup failed validation: ${verify.errors.joinToString("; ")}"
            }

            val zipSha = sha256File(destZipFile)
            onProgress(BackupProgress(false, "BACKUP", 100, "Backup verified & saved"))
            BackupHistoryRecord(
                backupId = backupId,
                fileName = displayFileName,
                createdAtIso = createdAtIso,
                fileSizeBytes = destZipFile.length(),
                schemaVersion = supportedDbSchemaVersion,
                formatVersion = CURRENT_BACKUP_FORMAT_VERSION,
                counts = finalCounts,
                checksumSha256 = zipSha,
                verificationStatus = "VERIFIED",
                locationUriOrPath = destZipFile.absolutePath,
                fileExists = true
            )
        } finally {
            runCatching { stagedDb.delete() }
            runCatching { tmpZip.delete() }
        }
    }

    fun validateArchiveFile(zipFile: File, overrideName: String? = null): BackupValidationResult {
        val fileName = overrideName ?: zipFile.name
        val errors = mutableListOf<String>()
        val missingMedia = mutableListOf<String>()

        var createdAt = ""
        var appVersion = ""
        var schemaVersion = 0
        var formatVersion = 0
        var manifestCounts = BackupRecordCounts()
        var checksumOk = false
        var sqliteOk = false
        var countsMatched = false
        var mediaIntegrityOk = false
        var olderThanCurrent = false

        if (!zipFile.exists() || !zipFile.isFile || zipFile.length() == 0L) {
            return BackupValidationResult(
                isValid = false,
                fileName = fileName,
                createdAtIso = "",
                appVersion = "",
                schemaVersion = 0,
                formatVersion = 0,
                counts = manifestCounts,
                checksumVerified = false,
                sqliteIntegrityOk = false,
                isOlderThanCurrentData = false,
                missingMediaCount = 0,
                errors = listOf("Backup file missing or empty"),
                countsMatched = false,
                mediaIntegrityOk = false
            )
        }

        if (zipFile.length() > MAX_BACKUP_ARCHIVE_BYTES) {
            return BackupValidationResult(
                isValid = false, fileName = fileName, createdAtIso = "", appVersion = "",
                schemaVersion = 0, formatVersion = 0, counts = manifestCounts,
                checksumVerified = false, sqliteIntegrityOk = false, isOlderThanCurrentData = false,
                missingMediaCount = 0, errors = listOf("Backup archive exceeds the supported size limit"),
                countsMatched = false, mediaIntegrityOk = false
            )
        }

        val tempDbCheck = File(stagingRootDir, "verify_db_${UUID.randomUUID()}.db")
        try {
            ZipFile(zipFile).use { zf ->
                // Check 1 & 2: Ensure ZIP is readable, bounded, and reject Zip-Slip / duplicates.
                val entryMap = linkedMapOf<String, ZipEntry>()
                val entries = zf.entries()
                var entryCount = 0
                var totalExpandedBytes = 0L
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    entryCount++
                    if (entryCount > MAX_BACKUP_ENTRY_COUNT) {
                        errors.add("Backup archive contains too many entries")
                        break
                    }
                    if (!isSafeZipPath(entry.name)) {
                        errors.add("Unsafe ZIP entry path rejected: ${entry.name}")
                        continue
                    }
                    if (!entry.isDirectory) {
                        val declaredSize = entry.size
                        val compressedSize = entry.compressedSize
                        if (declaredSize < 0L || declaredSize > MAX_BACKUP_ENTRY_BYTES) {
                            errors.add("ZIP entry has an invalid or excessive uncompressed size: ${entry.name}")
                            continue
                        }
                        if (entry.name == MANIFEST_ENTRY && declaredSize > MAX_MANIFEST_BYTES) {
                            errors.add("Backup manifest exceeds the supported size limit")
                            continue
                        }
                        totalExpandedBytes += declaredSize
                        if (totalExpandedBytes > MAX_BACKUP_EXPANDED_BYTES) {
                            errors.add("Backup expands beyond the supported total size limit")
                            break
                        }
                        if (declaredSize > 0L && compressedSize == 0L) {
                            errors.add("ZIP entry has an invalid compressed size: ${entry.name}")
                            continue
                        }
                        if (compressedSize > 0L && declaredSize / compressedSize.coerceAtLeast(1L) > MAX_COMPRESSION_RATIO) {
                            errors.add("ZIP entry compression ratio is excessive: ${entry.name}")
                            continue
                        }
                        if (entryMap.containsKey(entry.name)) {
                            errors.add("Duplicate ZIP entry detected: ${entry.name}")
                        } else {
                            entryMap[entry.name] = entry
                        }
                    }
                }
                if (errors.isNotEmpty()) {
                    return BackupValidationResult(
                        isValid = false, fileName = fileName, createdAtIso = "", appVersion = "",
                        schemaVersion = 0, formatVersion = 0, counts = manifestCounts,
                        checksumVerified = false, sqliteIntegrityOk = false, isOlderThanCurrentData = false,
                        missingMediaCount = 0, errors = errors.toList(), countsMatched = false,
                        mediaIntegrityOk = false
                    )
                }

                // Mandatory manifest check
                val manifestEntry = entryMap[MANIFEST_ENTRY]
                if (manifestEntry == null) {
                    errors.add("Missing mandatory entry: $MANIFEST_ENTRY")
                    return BackupValidationResult(
                        isValid = false,
                        fileName = fileName,
                        createdAtIso = "",
                        appVersion = "",
                        schemaVersion = 0,
                        formatVersion = 0,
                        counts = manifestCounts,
                        checksumVerified = false,
                        sqliteIntegrityOk = false,
                        isOlderThanCurrentData = false,
                        missingMediaCount = 0,
                        errors = errors,
                        countsMatched = false,
                        mediaIntegrityOk = false
                    )
                }

                // Check 3: Valid JSON manifest
                val manifestText = zf.getInputStream(manifestEntry).bufferedReader(Charsets.UTF_8).use { it.readText() }
                val manifestMap = try {
                    @Suppress("UNCHECKED_CAST")
                    MiniJson.parse(manifestText) as? Map<String, Any?>
                        ?: throw IllegalArgumentException("Manifest root is not a JSON object")
                } catch (e: Exception) {
                    errors.add("Invalid backup_manifest.json: ${e.message ?: "malformed JSON"}")
                    return BackupValidationResult(
                        isValid = false,
                        fileName = fileName,
                        createdAtIso = "",
                        appVersion = "",
                        schemaVersion = 0,
                        formatVersion = 0,
                        counts = manifestCounts,
                        checksumVerified = false,
                        sqliteIntegrityOk = false,
                        isOlderThanCurrentData = false,
                        missingMediaCount = 0,
                        errors = errors,
                        countsMatched = false,
                        mediaIntegrityOk = false
                    )
                }

                // Check 4: App ID & format/schema version support
                val appName = manifestMap["appName"] as? String ?: ""
                if (appName != APP_SIGNATURE) {
                    errors.add("Unrecognized backup application signature: '$appName'")
                }
                createdAt = manifestMap["createdAtIso"] as? String ?: ""
                if (createdAt.isBlank()) {
                    errors.add("Manifest missing createdAtIso timestamp")
                }
                appVersion = manifestMap["appVersion"] as? String ?: ""
                formatVersion = (manifestMap["formatVersion"] as? Number)?.toInt() ?: 0
                schemaVersion = (manifestMap["schemaVersion"] as? Number)?.toInt() ?: 0

                if (formatVersion !in MIN_SUPPORTED_FORMAT_VERSION..CURRENT_BACKUP_FORMAT_VERSION) {
                    errors.add("Unsupported backup format version: $formatVersion (supported: $MIN_SUPPORTED_FORMAT_VERSION..$CURRENT_BACKUP_FORMAT_VERSION)")
                }
                if (schemaVersion !in 1..supportedDbSchemaVersion) {
                    errors.add("Unsupported SQLite schema version: $schemaVersion (supported: 1..$supportedDbSchemaVersion)")
                }

                // Check 2 (cont.): Mandatory entries based on formatVersion
                val dbEntryPath = "database/${SiteLedgerDatabaseContract.DATABASE_NAME}"
                val dbEntry = entryMap[dbEntryPath]
                if (dbEntry == null) {
                    errors.add("Missing mandatory SQLite database entry: $dbEntryPath")
                }
                if (formatVersion >= 2 && !entryMap.containsKey(SCHEMA_SUMMARY_ENTRY)) {
                    errors.add("Missing mandatory entry: $SCHEMA_SUMMARY_ENTRY")
                }

                // Counts parsing
                @Suppress("UNCHECKED_CAST")
                val countsMap = manifestMap["counts"] as? Map<String, Any?>
                if (countsMap == null) {
                    errors.add("Manifest missing counts section")
                } else {
                    manifestCounts = BackupRecordCounts(
                        sites = (countsMap["sites"] as? Number)?.toInt() ?: 0,
                        workers = (countsMap["workers"] as? Number)?.toInt() ?: 0,
                        attendanceRecords = (countsMap["attendanceRecords"] as? Number)?.toInt() ?: 0,
                        payments = (countsMap["payments"] as? Number)?.toInt() ?: 0,
                        advances = (countsMap["advances"] as? Number)?.toInt() ?: 0,
                        allocations = (countsMap["allocations"] as? Number)?.toInt() ?: 0,
                        expenses = (countsMap["expenses"] as? Number)?.toInt() ?: 0,
                        payrollPeriods = (countsMap["payrollPeriods"] as? Number)?.toInt() ?: 0,
                        workerPhotos = (countsMap["workerPhotos"] as? Number)?.toInt() ?: 0,
                        receiptImages = (countsMap["receiptImages"] as? Number)?.toInt() ?: 0
                    )
                }

                // Check 8: SHA-256 verification of all checksum entries AND mandatory payload coverage
                @Suppress("UNCHECKED_CAST")
                val checksumsRaw = manifestMap["checksums"] as? Map<String, Any?>
                val checksums = linkedMapOf<String, String>()
                if (checksumsRaw == null || checksumsRaw.isEmpty()) {
                    errors.add("Manifest missing checksums map")
                    checksumOk = false
                } else {
                    checksumsRaw.forEach { (k, v) ->
                        val hex = v as? String
                        if (!hex.isNullOrBlank()) checksums[k] = hex
                    }
                    checksumOk = true
                    if (!checksums.containsKey(dbEntryPath)) {
                        checksumOk = false
                        errors.add("Database checksum missing from manifest: $dbEntryPath")
                    }
                    if (formatVersion >= 2 && !checksums.containsKey(SCHEMA_SUMMARY_ENTRY)) {
                        checksumOk = false
                        errors.add("Schema summary checksum missing from manifest: $SCHEMA_SUMMARY_ENTRY")
                    }

                    checksums.forEach { (path, expectedSha) ->
                        val entry = entryMap[path]
                        if (entry == null) {
                            checksumOk = false
                            if (path.startsWith("${WorkerPhotoStorage.PHOTOS_FOLDER_NAME}/") ||
                                path.startsWith("${WorkerPhotoStorage.RECEIPTS_FOLDER_NAME}/")
                            ) {
                                missingMedia.add(path)
                            }
                            errors.add("Missing archive entry for checksum: $path")
                        } else {
                            val actualSha = sha256Stream(zf.getInputStream(entry))
                            if (!actualSha.equals(expectedSha, ignoreCase = true)) {
                                checksumOk = false
                                errors.add("SHA-256 checksum mismatch: $path")
                            }
                        }
                    }

                    // Format v3+: every packaged media entry must also appear in checksums map
                    if (formatVersion >= 3) {
                        entryMap.keys
                            .filter {
                                it.startsWith("${WorkerPhotoStorage.PHOTOS_FOLDER_NAME}/") ||
                                    it.startsWith("${WorkerPhotoStorage.RECEIPTS_FOLDER_NAME}/")
                            }
                            .forEach { mediaEntry ->
                                if (!checksums.containsKey(mediaEntry)) {
                                    checksumOk = false
                                    errors.add("Unverified media file missing checksum in manifest: $mediaEntry")
                                }
                            }
                    }
                }

                // Check 5 & 6: Extract SQLite DB and verify PRAGMA integrity_check + core tables
                var inspection: SqliteInspectionResult? = null
                if (dbEntry != null) {
                    zf.getInputStream(dbEntry).use { input ->
                        FileOutputStream(tempDbCheck).use { out -> input.copyTo(out) }
                    }
                    if (tempDbCheck.length() == 0L) {
                        errors.add("Extracted SQLite database is empty")
                    } else {
                        val effectiveSchema = if (schemaVersion > 0) schemaVersion else supportedDbSchemaVersion
                        val res = sqliteBridge.inspectDatabaseFile(tempDbCheck, effectiveSchema)
                        inspection = res
                        sqliteOk = res.integrityOk && res.missingTables.isEmpty()
                        if (!res.integrityOk) {
                            errors.add(res.errorMessage ?: "SQLite PRAGMA integrity_check failed")
                        }
                        if (res.missingTables.isNotEmpty()) {
                            errors.add("SQLite database missing required tables: ${res.missingTables.joinToString(", ")}")
                        }
                    }
                }

                // Check 9 & 10: Every DB-referenced worker photo & receipt exists in ZIP + checksums
                if (inspection != null) {
                    val ins = inspection!!
                    val photoFilesInZip = entryMap.keys.count { it.startsWith("${WorkerPhotoStorage.PHOTOS_FOLDER_NAME}/") }
                    val receiptFilesInZip = entryMap.keys.count { it.startsWith("${WorkerPhotoStorage.RECEIPTS_FOLDER_NAME}/") }

                    val mediaErrorsBefore = errors.size
                    ins.referencedWorkerPhotos.forEach { rawRef ->
                        val normalized = normalizeMediaPath(rawRef, WorkerPhotoStorage.PHOTOS_FOLDER_NAME)
                        if (normalized == null || !entryMap.containsKey(normalized)) {
                            missingMedia.add(rawRef)
                            errors.add("Missing referenced worker photo in archive: $rawRef")
                        } else if (entryMap[normalized]?.size == 0L) {
                            missingMedia.add(rawRef)
                            errors.add("Corrupted (empty) worker photo in archive: $rawRef")
                        } else if (!checksums.containsKey(normalized)) {
                            checksumOk = false
                            errors.add("Worker photo missing SHA-256 checksum in manifest: $normalized")
                        }
                    }

                    ins.referencedReceiptImages.forEach { rawRef ->
                        val normalized = normalizeMediaPath(rawRef, WorkerPhotoStorage.RECEIPTS_FOLDER_NAME)
                        if (normalized == null || !entryMap.containsKey(normalized)) {
                            missingMedia.add(rawRef)
                            errors.add("Missing referenced receipt image in archive: $rawRef")
                        } else if (entryMap[normalized]?.size == 0L) {
                            missingMedia.add(rawRef)
                            errors.add("Corrupted (empty) receipt image in archive: $rawRef")
                        } else if (!checksums.containsKey(normalized)) {
                            checksumOk = false
                            errors.add("Receipt image missing SHA-256 checksum in manifest: $normalized")
                        }
                    }
                    mediaIntegrityOk = errors.size == mediaErrorsBefore

                    // Check 11: Manifest record & media counts match database reality
                    if (countsMap != null) {
                        val countMismatches = verifyCountsMatch(
                            schemaVersion = schemaVersion,
                            formatVersion = formatVersion,
                            manifest = manifestCounts,
                            dbCounts = ins.counts,
                            zipPhotoCount = photoFilesInZip,
                            zipReceiptCount = receiptFilesInZip
                        )
                        if (countMismatches.isNotEmpty()) {
                            countsMatched = false
                            errors.addAll(countMismatches)
                        } else {
                            countsMatched = true
                        }
                    }
                }

                val latestHistoryIso = sqliteBridge.readLatestBackupTimestamp()
                if (latestHistoryIso != null && createdAt.isNotBlank() && createdAt < latestHistoryIso) {
                    olderThanCurrent = true
                }
            }
        } catch (ex: Exception) {
            errors.add("Corrupted or unreadable ZIP archive: ${ex.message ?: "parse error"}")
        } finally {
            runCatching { tempDbCheck.delete() }
        }

        val uniqueMissingMedia = missingMedia.distinct()
        return BackupValidationResult(
            isValid = errors.isEmpty() && checksumOk && sqliteOk && countsMatched && mediaIntegrityOk && uniqueMissingMedia.isEmpty(),
            fileName = fileName,
            createdAtIso = createdAt,
            appVersion = appVersion,
            schemaVersion = schemaVersion,
            formatVersion = formatVersion,
            counts = manifestCounts,
            checksumVerified = checksumOk,
            sqliteIntegrityOk = sqliteOk,
            isOlderThanCurrentData = olderThanCurrent,
            missingMediaCount = uniqueMissingMedia.size,
            errors = errors.distinct(),
            missingMediaFiles = uniqueMissingMedia,
            countsMatched = countsMatched,
            mediaIntegrityOk = mediaIntegrityOk
        )
    }

    fun executeStagedRestoreFromFile(
        zipFile: File,
        fileName: String = zipFile.name,
        onProgress: (BackupProgress) -> Unit = {},
        faultHooks: RestoreFaultHooks = RestoreFaultHooks()
    ): BackupValidationResult {
        val restoreId = "RST-${UUID.randomUUID().toString().take(8).uppercase()}"
        val stagingDir = File(stagingRootDir, restoreId).apply { mkdirs() }
        val stagedDb = File(stagingDir, SiteLedgerDatabaseContract.DATABASE_NAME)
        val stagedPhotosDir = File(stagingDir, WorkerPhotoStorage.PHOTOS_FOLDER_NAME).apply { mkdirs() }
        val stagedReceiptsDir = File(stagingDir, WorkerPhotoStorage.RECEIPTS_FOLDER_NAME).apply { mkdirs() }
        val rollbackDir = File(rollbackRootDir, restoreId).apply { mkdirs() }

        var safetyZipFile: File? = null
        var currentJournal = RestoreJournalData(
            restoreId = restoreId,
            sourceFileName = fileName,
            status = RestoreJournalStatus.STAGING,
            stagingDirPath = stagingDir.absolutePath,
            rollbackDirPath = rollbackDir.absolutePath,
            safetyBackupPath = null,
            startedAtIso = nowIso(),
            updatedAtIso = nowIso(),
            lastError = null
        )

        try {
            // Stage 2: Validate complete archive without modifying live data
            onProgress(BackupProgress(true, "RESTORE", 15, "Stage 2: Validating backup archive..."))
            val validation = validateArchiveFile(zipFile, fileName)
            if (!validation.isValid) {
                throw BackupRestoreException(
                    failedStage = STAGE_2_VALIDATION,
                    recoveryAttempted = false,
                    recoverySucceeded = true,
                    safetyBackupPath = null,
                    message = "Stage 2 (Archive validation) failed: ${validation.errors.joinToString("; ")}"
                )
            }
            if (faultHooks.failAtStage == STAGE_2_VALIDATION) {
                throw BackupRestoreException(STAGE_2_VALIDATION, false, true, null, "Simulated failure at $STAGE_2_VALIDATION")
            }

            // Stage 3: Extract into persistent staging directory
            onProgress(BackupProgress(true, "RESTORE", 30, "Stage 3: Extracting to staging directory..."))
            writeJournal(currentJournal)
            extractValidatedEntries(zipFile, stagedDb, stagedPhotosDir, stagedReceiptsDir)
            if (faultHooks.failAtStage == STAGE_3_EXTRACT) {
                throw IllegalStateException("Simulated failure at $STAGE_3_EXTRACT")
            }

            // Stage 4: Re-verify staged DB, counts, and extracted media files
            onProgress(BackupProgress(true, "RESTORE", 45, "Stage 4: Verifying staged DB & media..."))
            val stagedInspection = sqliteBridge.inspectDatabaseFile(stagedDb, validation.schemaVersion)
            if (!stagedInspection.integrityOk || stagedInspection.missingTables.isNotEmpty()) {
                throw BackupRestoreException(
                    failedStage = STAGE_4_STAGED_VERIFICATION,
                    recoveryAttempted = false,
                    recoverySucceeded = true,
                    safetyBackupPath = null,
                    message = "Stage 4 (Staged verification) failed: ${stagedInspection.errorMessage ?: "integrity/table check failed"}"
                )
            }
            verifyExtractedMediaOnDisk(stagedInspection, stagedPhotosDir, stagedReceiptsDir)
            currentJournal = currentJournal.copy(status = RestoreJournalStatus.VALIDATED_STAGE, updatedAtIso = nowIso())
            writeJournal(currentJournal)
            if (faultHooks.failAtStage == STAGE_4_STAGED_VERIFICATION) {
                throw BackupRestoreException(STAGE_4_STAGED_VERIFICATION, false, true, null, "Simulated failure at $STAGE_4_STAGED_VERIFICATION")
            }

            // Stage 5: Create & verify pre-restore safety backup BEFORE touching live DB/media
            onProgress(BackupProgress(true, "RESTORE", 60, "Stage 5: Saving pre-restore safety backup..."))
            val safetyStamp = SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.US).format(Date())
            safetyZipFile = File(safetyBackupsDir, "SAFETY_PRE_RESTORE_${safetyStamp}_${restoreId}.zip")
            val safetyResult = createBackupArchiveToFile(safetyZipFile, safetyZipFile.name) {}
            if (safetyResult.isFailure || faultHooks.failAtStage == STAGE_5_SAFETY_BACKUP) {
                val err = safetyResult.exceptionOrNull()
                throw BackupRestoreException(
                    failedStage = STAGE_5_SAFETY_BACKUP,
                    recoveryAttempted = false,
                    recoverySucceeded = true,
                    safetyBackupPath = safetyZipFile.takeIf { it.exists() }?.absolutePath,
                    message = "Stage 5 (Safety backup) failed: ${err?.message ?: "unable to create safety archive"}",
                    cause = err
                )
            }

            currentJournal = currentJournal.copy(
                status = RestoreJournalStatus.SAFETY_BACKUP_CREATED,
                safetyBackupPath = safetyZipFile.absolutePath,
                updatedAtIso = nowIso()
            )
            writeJournal(currentJournal)

            // Stage 6: Prepare local rollback mirror of live DB & media
            onProgress(BackupProgress(true, "RESTORE", 72, "Stage 6: Preparing rollback snapshot..."))
            val rollbackCheckpoint = sqliteBridge.checkpointLiveDatabase()
            check(
                rollbackCheckpoint.success &&
                    rollbackCheckpoint.busy == 0 &&
                    (rollbackCheckpoint.logPages <= 0 || rollbackCheckpoint.checkpointedPages >= rollbackCheckpoint.logPages)
            ) {
                rollbackCheckpoint.errorMessage
                    ?: "Cannot create a consistent rollback snapshot: WAL checkpoint incomplete (busy=${rollbackCheckpoint.busy}, log=${rollbackCheckpoint.logPages}, checkpointed=${rollbackCheckpoint.checkpointedPages})"
            }
            sqliteBridge.closeDatabaseBeforeSwap()

            val rollbackDb = File(rollbackDir, "old.db")
            val rollbackPhotos = File(rollbackDir, WorkerPhotoStorage.PHOTOS_FOLDER_NAME).apply { mkdirs() }
            val rollbackReceipts = File(rollbackDir, WorkerPhotoStorage.RECEIPTS_FOLDER_NAME).apply { mkdirs() }
            if (liveDbFile.exists()) {
                liveDbFile.copyTo(rollbackDb, overwrite = true)
                syncFile(rollbackDb)
            }
            copyDirectoryContents(livePhotosDir, rollbackPhotos)
            copyDirectoryContents(liveReceiptsDir, rollbackReceipts)
            if (faultHooks.failAtStage == STAGE_6_PREPARE_ROLLBACK) {
                throw BackupRestoreException(STAGE_6_PREPARE_ROLLBACK, false, true, safetyZipFile.absolutePath, "Simulated failure at $STAGE_6_PREPARE_ROLLBACK")
            }

            // Stage 7: Recoverable replacement of live DB and media (journal = SWAPPING)
            onProgress(BackupProgress(true, "RESTORE", 82, "Stage 7: Replacing live database & media..."))
            currentJournal = currentJournal.copy(status = RestoreJournalStatus.SWAPPING, updatedAtIso = nowIso())
            writeJournal(currentJournal)

            if (faultHooks.simulateCrashAtJournalStatus == RestoreJournalStatus.SWAPPING) {
                // Simulate mid-swap partial overwrite before crash!
                deleteSqliteSidecars(liveDbFile)
                stagedDb.copyTo(liveDbFile, overwrite = true)
                livePhotosDir.listFiles()?.forEach { it.delete() }
                throw SimulatedProcessCrashException("STAGE_7_SWAPPING")
            }
            if (faultHooks.failAtStage == STAGE_7_LIVE_REPLACEMENT) {
                // Partially mutate live DB first to test rollback!
                deleteSqliteSidecars(liveDbFile)
                stagedDb.copyTo(liveDbFile, overwrite = true)
                throw IllegalStateException("Simulated I/O failure during live replacement")
            }

            replaceLiveDatabaseAtomically(stagedDb)
            replaceDirectoryContents(livePhotosDir, stagedPhotosDir)
            replaceDirectoryContents(liveReceiptsDir, stagedReceiptsDir)

            // Stage 8: Post-swap verification of reopened SQLite & media files on disk
            onProgress(BackupProgress(true, "RESTORE", 92, "Stage 8: Verifying restored database & photos..."))
            currentJournal = currentJournal.copy(status = RestoreJournalStatus.VERIFYING, updatedAtIso = nowIso())
            writeJournal(currentJournal)

            if (faultHooks.simulateCrashAtJournalStatus == RestoreJournalStatus.VERIFYING) {
                throw SimulatedProcessCrashException("STAGE_8_VERIFYING")
            }
            if (faultHooks.failAtStage == STAGE_8_POST_VERIFY) {
                throw IllegalStateException("Simulated verification failure at $STAGE_8_POST_VERIFY")
            }

            val postCheck = sqliteBridge.reopenAndVerifyDatabase(supportedDbSchemaVersion)
            check(postCheck.integrityOk && postCheck.missingTables.isEmpty()) {
                "Post-restore database check failed: ${postCheck.errorMessage ?: "missing tables ${postCheck.missingTables}"}"
            }
            verifyPostRestoreCounts(validation.schemaVersion, validation.counts, postCheck.counts)
            verifyExtractedMediaOnDisk(postCheck, livePhotosDir, liveReceiptsDir)

            // Stage 9: Mark complete, clean temp staging/rollback (keep safety backup permanently)
            currentJournal = currentJournal.copy(status = RestoreJournalStatus.COMPLETED, updatedAtIso = nowIso())
            writeJournal(currentJournal)
            cleanSafeTempDir(stagingDir.absolutePath)
            cleanSafeTempDir(rollbackDir.absolutePath)

            onProgress(BackupProgress(false, "RESTORE", 100, "Restore successful ($fileName)"))
            return validation.copy(safetyBackupPath = safetyZipFile.absolutePath)
        } catch (crash: SimulatedProcessCrashException) {
            throw crash
        } catch (err: Throwable) {
            if (err is BackupRestoreException && !err.recoveryAttempted) {
                cleanSafeTempDir(stagingDir.absolutePath)
                cleanSafeTempDir(rollbackDir.absolutePath)
                writeJournal(
                    currentJournal.copy(
                        status = RestoreJournalStatus.ROLLED_BACK,
                        updatedAtIso = nowIso(),
                        lastError = err.message
                    )
                )
                throw err
            }

            val failedStage = when (currentJournal.status) {
                RestoreJournalStatus.VERIFYING -> STAGE_8_POST_VERIFY
                RestoreJournalStatus.SWAPPING -> STAGE_7_LIVE_REPLACEMENT
                else -> STAGE_7_LIVE_REPLACEMENT
            }

            val rollbackRecovered = attemptRollbackDirRecovery(rollbackDir.absolutePath) ||
                attemptSafetyZipRecovery(safetyZipFile?.absolutePath)

            val postRollbackOk = if (rollbackRecovered) {
                val postRb = sqliteBridge.reopenAndVerifyDatabase(supportedDbSchemaVersion)
                postRb.integrityOk && postRb.missingTables.isEmpty()
            } else {
                false
            }

            if (postRollbackOk) {
                cleanSafeTempDir(stagingDir.absolutePath)
                cleanSafeTempDir(rollbackDir.absolutePath)
                writeJournal(
                    currentJournal.copy(
                        status = RestoreJournalStatus.ROLLED_BACK,
                        updatedAtIso = nowIso(),
                        lastError = "Rolled back after $failedStage failure: ${err.message}"
                    )
                )
            } else {
                writeJournal(
                    currentJournal.copy(
                        status = RestoreJournalStatus.FAILED_NEEDS_RECOVERY,
                        updatedAtIso = nowIso(),
                        lastError = "Recovery required ($failedStage): ${err.message}"
                    )
                )
            }

            throw BackupRestoreException(
                failedStage = failedStage,
                recoveryAttempted = true,
                recoverySucceeded = postRollbackOk,
                safetyBackupPath = safetyZipFile?.absolutePath,
                message = if (postRollbackOk) {
                    "Restore failed at $failedStage (${err.message}). Original data restored cleanly."
                } else {
                    "Restore failed at $failedStage (${err.message}). Recovery required from safety backup."
                },
                cause = err
            )
        }
    }

    private fun extractValidatedEntries(
        zipFile: File,
        stagedDb: File,
        stagedPhotosDir: File,
        stagedReceiptsDir: File
    ) {
        val dbEntryPath = "database/${SiteLedgerDatabaseContract.DATABASE_NAME}"
        ZipFile(zipFile).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (entry.isDirectory || !isSafeZipPath(entry.name)) continue
                val target: File? = when {
                    entry.name == dbEntryPath -> stagedDb
                    entry.name.startsWith("${WorkerPhotoStorage.PHOTOS_FOLDER_NAME}/") -> {
                        safeChild(stagedPhotosDir, entry.name.removePrefix("${WorkerPhotoStorage.PHOTOS_FOLDER_NAME}/"))
                    }
                    entry.name.startsWith("${WorkerPhotoStorage.RECEIPTS_FOLDER_NAME}/") -> {
                        safeChild(stagedReceiptsDir, entry.name.removePrefix("${WorkerPhotoStorage.RECEIPTS_FOLDER_NAME}/"))
                    }
                    else -> null
                }
                if (target != null) {
                    zf.getInputStream(entry).use { input ->
                        FileOutputStream(target).use { out ->
                            input.copyTo(out)
                            out.fd.sync()
                        }
                    }
                }
            }
        }
        check(stagedDb.exists() && stagedDb.length() > 0L) {
            "Staged SQLite database missing after extraction"
        }
    }

    private fun verifyExtractedMediaOnDisk(
        inspection: SqliteInspectionResult,
        photosDir: File,
        receiptsDir: File
    ) {
        val missing = mutableListOf<String>()
        inspection.referencedWorkerPhotos.forEach { raw ->
            val rel = normalizeMediaPath(raw, WorkerPhotoStorage.PHOTOS_FOLDER_NAME)
            val fileName = rel?.removePrefix("${WorkerPhotoStorage.PHOTOS_FOLDER_NAME}/")
            val file = fileName?.let { safeChild(photosDir, it) }
            if (file == null || !file.exists() || !file.isFile || file.length() == 0L) {
                missing.add(raw)
            }
        }
        inspection.referencedReceiptImages.forEach { raw ->
            val rel = normalizeMediaPath(raw, WorkerPhotoStorage.RECEIPTS_FOLDER_NAME)
            val fileName = rel?.removePrefix("${WorkerPhotoStorage.RECEIPTS_FOLDER_NAME}/")
            val file = fileName?.let { safeChild(receiptsDir, it) }
            if (file == null || !file.exists() || !file.isFile || file.length() == 0L) {
                missing.add(raw)
            }
        }
        check(missing.isEmpty()) {
            "Missing media files on disk: ${missing.joinToString(", ")}"
        }
    }

    /**
     * Replaces the SQLite file using same-directory renames. A copy-overwrite fallback is
     * deliberately avoided: it can leave a truncated live database after power loss.
     * The restore journal + rollback snapshot handle process interruption between renames.
     */
    private fun replaceLiveDatabaseAtomically(stagedDb: File) {
        val parent = liveDbFile.parentFile ?: error("Live database parent directory is unavailable")
        check(parent.exists() || parent.mkdirs()) { "Unable to create live database directory" }
        check(stagedDb.isFile && stagedDb.length() > 0L) { "Staged database is missing or empty" }

        val tempNext = File(parent, "${liveDbFile.name}.new.${UUID.randomUUID()}")
        val previous = File(parent, "${liveDbFile.name}.previous.${UUID.randomUUID()}")
        try {
            FileInputStream(stagedDb).use { input ->
                FileOutputStream(tempNext).use { out ->
                    input.copyTo(out)
                    out.fd.sync()
                }
            }
            check(tempNext.length() == stagedDb.length()) { "Staged database copy is incomplete" }
            deleteSqliteSidecars(liveDbFile)

            if (liveDbFile.exists()) {
                check(liveDbFile.renameTo(previous)) {
                    "Unable to move the current database to a temporary rollback name"
                }
            }
            try {
                check(tempNext.renameTo(liveDbFile)) {
                    "Unable to atomically install the staged database"
                }
                syncFile(liveDbFile)
                if (previous.exists()) check(previous.delete()) {
                    "New database installed, but temporary previous database could not be removed"
                }
            } catch (installError: Throwable) {
                if (!liveDbFile.exists() && previous.exists()) previous.renameTo(liveDbFile)
                throw installError
            }
        } finally {
            if (tempNext.exists()) tempNext.delete()
            // Keep a previous file if an interrupted/failed install left it behind.
        }
    }

    private fun attemptRollbackDirRecovery(rollbackDirPath: String?): Boolean {
        if (rollbackDirPath.isNullOrBlank()) return false
        val rbDir = File(rollbackDirPath)
        val rbDb = File(rbDir, "old.db")
        if (!rbDir.exists() || !rbDb.exists() || rbDb.length() == 0L) return false
        val rbCheck = sqliteBridge.inspectDatabaseFile(rbDb, supportedDbSchemaVersion)
        if (!rbCheck.integrityOk) return false

        return runCatching {
            sqliteBridge.closeDatabaseBeforeSwap()
            replaceLiveDatabaseAtomically(rbDb)
            val rbPhotos = File(rbDir, WorkerPhotoStorage.PHOTOS_FOLDER_NAME)
            val rbReceipts = File(rbDir, WorkerPhotoStorage.RECEIPTS_FOLDER_NAME)
            if (rbPhotos.exists()) replaceDirectoryContents(livePhotosDir, rbPhotos)
            if (rbReceipts.exists()) replaceDirectoryContents(liveReceiptsDir, rbReceipts)
            true
        }.getOrDefault(false)
    }

    private fun attemptSafetyZipRecovery(safetyZipPath: String?): Boolean {
        if (safetyZipPath.isNullOrBlank()) return false
        val safetyFile = File(safetyZipPath)
        if (!safetyFile.exists() || !safetyFile.isFile) return false
        val safetyValidation = validateArchiveFile(safetyFile, safetyFile.name)
        if (!safetyValidation.isValid) return false

        val recStaging = File(stagingRootDir, "recovery_${UUID.randomUUID().toString().take(6)}").apply { mkdirs() }
        val recDb = File(recStaging, SiteLedgerDatabaseContract.DATABASE_NAME)
        val recPhotos = File(recStaging, WorkerPhotoStorage.PHOTOS_FOLDER_NAME).apply { mkdirs() }
        val recReceipts = File(recStaging, WorkerPhotoStorage.RECEIPTS_FOLDER_NAME).apply { mkdirs() }
        return try {
            extractValidatedEntries(safetyFile, recDb, recPhotos, recReceipts)
            sqliteBridge.closeDatabaseBeforeSwap()
            replaceLiveDatabaseAtomically(recDb)
            replaceDirectoryContents(livePhotosDir, recPhotos)
            replaceDirectoryContents(liveReceiptsDir, recReceipts)
            true
        } catch (_: Throwable) {
            false
        } finally {
            cleanSafeTempDir(recStaging.absolutePath)
        }
    }

    private fun collectReferencedAndExistingMediaFiles(
        mediaDir: File,
        folderPrefix: String,
        referencedPaths: List<String>
    ): Map<String, File> {
        val result = linkedMapOf<String, File>()
        mediaDir.mkdirs()

        // Ensure every referenced file actually exists on disk
        val missingReferenced = mutableListOf<String>()
        referencedPaths.forEach { raw ->
            val normalized = normalizeMediaPath(raw, folderPrefix)
            val fileName = normalized?.removePrefix("$folderPrefix/")
            val file = fileName?.let { safeChild(mediaDir, it) }
            if (file == null || !file.exists() || !file.isFile || file.length() == 0L) {
                missingReferenced.add(raw)
            } else {
                result[normalized] = file
            }
        }
        check(missingReferenced.isEmpty()) {
            "Cannot create verified backup: referenced media missing on disk: ${missingReferenced.joinToString(", ")}"
        }

        // Also include any valid non-empty media files already in the directory
        mediaDir.listFiles()?.filter { it.isFile && it.length() > 0L }?.sortedBy { it.name }?.forEach { file ->
            val key = "$folderPrefix/${file.name}"
            result.putIfAbsent(key, file)
        }
        return result
    }

    private fun verifyCountsMatch(
        schemaVersion: Int,
        formatVersion: Int,
        manifest: BackupRecordCounts,
        dbCounts: BackupRecordCounts,
        zipPhotoCount: Int,
        zipReceiptCount: Int
    ): List<String> {
        val mismatches = mutableListOf<String>()
        if (manifest.workers != dbCounts.workers) {
            mismatches.add("Record count mismatch for workers: manifest=${manifest.workers}, database=${dbCounts.workers}")
        }
        if (manifest.attendanceRecords != dbCounts.attendanceRecords) {
            mismatches.add("Record count mismatch for attendance: manifest=${manifest.attendanceRecords}, database=${dbCounts.attendanceRecords}")
        }
        if (manifest.payments != dbCounts.payments) {
            mismatches.add("Record count mismatch for payments: manifest=${manifest.payments}, database=${dbCounts.payments}")
        }
        if (schemaVersion >= 4) {
            if (manifest.advances != dbCounts.advances) {
                mismatches.add("Record count mismatch for advances: manifest=${manifest.advances}, database=${dbCounts.advances}")
            }
            if (manifest.allocations != dbCounts.allocations) {
                mismatches.add("Record count mismatch for allocations: manifest=${manifest.allocations}, database=${dbCounts.allocations}")
            }
            if (manifest.payrollPeriods != dbCounts.payrollPeriods) {
                mismatches.add("Record count mismatch for payrollPeriods: manifest=${manifest.payrollPeriods}, database=${dbCounts.payrollPeriods}")
            }
        }
        if (schemaVersion >= 6) {
            if (manifest.sites != dbCounts.sites) {
                mismatches.add("Record count mismatch for sites: manifest=${manifest.sites}, database=${dbCounts.sites}")
            }
            if (manifest.expenses != dbCounts.expenses) {
                mismatches.add("Record count mismatch for expenses: manifest=${manifest.expenses}, database=${dbCounts.expenses}")
            }
        }
        if (formatVersion >= 2) {
            if (manifest.workerPhotos != zipPhotoCount) {
                mismatches.add("Media count mismatch for workerPhotos: manifest=${manifest.workerPhotos}, archive=$zipPhotoCount")
            }
            if (manifest.receiptImages != zipReceiptCount) {
                mismatches.add("Media count mismatch for receiptImages: manifest=${manifest.receiptImages}, archive=$zipReceiptCount")
            }
        }
        return mismatches
    }

    private fun verifyPostRestoreCounts(
        backupSchemaVersion: Int,
        expected: BackupRecordCounts,
        actual: BackupRecordCounts
    ) {
        check(actual.workers == expected.workers) {
            "Post-restore worker count mismatch: expected=${expected.workers}, actual=${actual.workers}"
        }
        check(actual.attendanceRecords == expected.attendanceRecords) {
            "Post-restore attendance count mismatch: expected=${expected.attendanceRecords}, actual=${actual.attendanceRecords}"
        }
        check(actual.payments == expected.payments) {
            "Post-restore payment count mismatch: expected=${expected.payments}, actual=${actual.payments}"
        }
        if (backupSchemaVersion >= 6) {
            check(actual.sites == expected.sites) {
                "Post-restore site count mismatch: expected=${expected.sites}, actual=${actual.sites}"
            }
            check(actual.expenses == expected.expenses) {
                "Post-restore expense count mismatch: expected=${expected.expenses}, actual=${actual.expenses}"
            }
        } else {
            check(actual.sites >= 1) { "Post-restore upgraded database must contain at least default site" }
        }
    }

    private fun buildManifestJson(
        createdAtIso: String,
        counts: BackupRecordCounts,
        checksums: Map<String, String>,
        referencedWorkerPhotos: List<String>,
        referencedReceiptImages: List<String>
    ): String {
        val countsObj = linkedMapOf<String, Any?>(
            "sites" to counts.sites,
            "workers" to counts.workers,
            "attendanceRecords" to counts.attendanceRecords,
            "payments" to counts.payments,
            "advances" to counts.advances,
            "allocations" to counts.allocations,
            "expenses" to counts.expenses,
            "payrollPeriods" to counts.payrollPeriods,
            "workerPhotos" to counts.workerPhotos,
            "receiptImages" to counts.receiptImages
        )
        val root = linkedMapOf<String, Any?>(
            "appName" to APP_SIGNATURE,
            "appVersion" to appVersionName,
            "formatVersion" to CURRENT_BACKUP_FORMAT_VERSION,
            "schemaVersion" to supportedDbSchemaVersion,
            "createdAtIso" to createdAtIso,
            "offlineOnly" to true,
            "digestAlgorithm" to "SHA-256",
            "counts" to countsObj,
            "referencedWorkerPhotos" to referencedWorkerPhotos,
            "referencedReceiptImages" to referencedReceiptImages,
            "checksums" to checksums
        )
        return MiniJson.stringify(root)
    }

    private fun readJournal(): RestoreJournalData? {
        val backupJournal = File(journalDir, "restore_journal.json.bak")

        fun parse(file: File): RestoreJournalData? = runCatching {
            if (!file.isFile || file.length() <= 0L || file.length() > MAX_JOURNAL_BYTES) return@runCatching null
            val raw = file.readText(Charsets.UTF_8)
            @Suppress("UNCHECKED_CAST")
            val m = MiniJson.parse(raw) as? Map<String, Any?> ?: return@runCatching null
            val statusStr = m["status"] as? String ?: RestoreJournalStatus.NONE.name
            val status = RestoreJournalStatus.entries.find { it.name == statusStr }
                ?: RestoreJournalStatus.FAILED_NEEDS_RECOVERY
            RestoreJournalData(
                restoreId = m["restoreId"] as? String ?: "",
                sourceFileName = m["sourceFileName"] as? String ?: "",
                status = status,
                stagingDirPath = m["stagingDirPath"] as? String,
                rollbackDirPath = m["rollbackDirPath"] as? String,
                safetyBackupPath = m["safetyBackupPath"] as? String,
                startedAtIso = m["startedAtIso"] as? String ?: "",
                updatedAtIso = m["updatedAtIso"] as? String ?: "",
                lastError = m["lastError"] as? String
            )
        }.getOrNull()

        // Primary journal wins when valid. The previous copy covers a crash during replacement.
        parse(journalFile)?.let { return it }
        parse(backupJournal)?.let { return it }
        if (!journalFile.exists() && !backupJournal.exists()) return null

        return RestoreJournalData(
            restoreId = "CORRUPTED_JOURNAL",
            sourceFileName = "",
            status = RestoreJournalStatus.FAILED_NEEDS_RECOVERY,
            stagingDirPath = null,
            rollbackDirPath = null,
            safetyBackupPath = findLatestSafetyBackupPath(),
            startedAtIso = "",
            updatedAtIso = nowIso(),
            lastError = "Restore journal and its previous copy are unreadable"
        )
    }

    private fun findLatestSafetyBackupPath(): String? =
        safetyBackupsDir.listFiles()
            ?.filter { it.isFile && it.name.startsWith("SAFETY_PRE_RESTORE_") && it.name.endsWith(".zip") }
            ?.maxByOrNull { it.lastModified() }
            ?.absolutePath

    private fun writeJournal(journal: RestoreJournalData) {
        check(journalDir.exists() || journalDir.mkdirs()) { "Unable to create restore journal directory" }
        val tmp = File(journalDir, "restore_journal.json.tmp")
        val previous = File(journalDir, "restore_journal.json.bak")
        val content = MiniJson.stringify(
            linkedMapOf(
                "restoreId" to journal.restoreId,
                "sourceFileName" to journal.sourceFileName,
                "status" to journal.status.name,
                "stagingDirPath" to journal.stagingDirPath,
                "rollbackDirPath" to journal.rollbackDirPath,
                "safetyBackupPath" to journal.safetyBackupPath,
                "startedAtIso" to journal.startedAtIso,
                "updatedAtIso" to journal.updatedAtIso,
                "lastError" to journal.lastError
            )
        )
        FileOutputStream(tmp).use { out ->
            out.write(content.toByteArray(Charsets.UTF_8))
            out.fd.sync()
        }
        if (previous.exists()) check(previous.delete()) { "Unable to clear previous journal backup" }
        if (journalFile.exists()) {
            check(journalFile.renameTo(previous)) { "Unable to preserve previous restore journal" }
        }
        if (!tmp.renameTo(journalFile)) {
            if (!journalFile.exists() && previous.exists()) previous.renameTo(journalFile)
            throw IllegalStateException("Unable to atomically replace restore journal")
        }
        syncFile(journalFile)
        if (previous.exists()) previous.delete()
    }

    private fun deleteSqliteSidecars(dbFile: File) {
        File(dbFile.absolutePath + "-wal").delete()
        File(dbFile.absolutePath + "-shm").delete()
        File(dbFile.absolutePath + "-journal").delete()
    }

    private fun copyDirectoryContents(src: File, dst: File) {
        dst.mkdirs()
        src.listFiles()?.filter { it.isFile }?.forEach { file ->
            FileInputStream(file).use { input ->
                FileOutputStream(File(dst, file.name)).use { out ->
                    input.copyTo(out)
                    out.fd.sync()
                }
            }
        }
    }

    /**
     * Builds the replacement beside the live directory and swaps directory names on the
     * same filesystem. This avoids deleting the live media tree file-by-file. If the second
     * rename fails, the old directory is restored immediately; if the process is killed in
     * between, the persistent restore journal drives rollback on next startup.
     */
    private fun replaceDirectoryContents(target: File, newContents: File) {
        val parent = target.parentFile ?: workspaceRootDir
        check(newContents.isDirectory) { "Replacement media directory is missing: ${newContents.name}" }
        check(parent.exists() || parent.mkdirs()) { "Unable to create media parent directory" }

        val nextTemp = File(parent, "${target.name}_next_${UUID.randomUUID()}")
        val previous = File(parent, "${target.name}_previous_${UUID.randomUUID()}")
        try {
            copyDirectoryContents(newContents, nextTemp)
            if (target.exists()) {
                check(target.renameTo(previous)) { "Unable to move current media directory aside: ${target.name}" }
            }
            try {
                check(nextTemp.renameTo(target)) { "Unable to install replacement media directory: ${target.name}" }
                if (previous.exists()) check(previous.deleteRecursively()) {
                    "Replacement installed, but previous media directory cleanup failed"
                }
            } catch (installError: Throwable) {
                if (!target.exists() && previous.exists()) previous.renameTo(target)
                throw installError
            }
        } finally {
            if (nextTemp.exists()) nextTemp.deleteRecursively()
            // Preserve a previous directory if the swap failed; recovery may need it.
        }
    }

    private fun cleanSafeTempDir(path: String?) {
        if (path.isNullOrBlank()) return
        val dir = File(path)
        val rootCanonical = workspaceRootDir.canonicalPath + File.separator
        val dirCanonical = runCatching { dir.canonicalPath }.getOrNull() ?: return
        if (dirCanonical.startsWith(rootCanonical) && dir.exists()) {
            dir.deleteRecursively()
        }
    }

    private fun isSafeZipPath(entryName: String): Boolean {
        if (entryName.isBlank()) return false
        if (entryName.startsWith("/") || entryName.startsWith("\\")) return false
        if (entryName.contains("\\") || entryName.contains("\u0000")) return false
        val segments = entryName.split("/")
        return segments.none { it == ".." || it == "." }
    }

    private fun safeChild(dir: File, childName: String): File? {
        if (childName.isBlank() || childName.contains("..") || childName.contains("/") || childName.contains("\\")) {
            return null
        }
        val candidate = File(dir, childName)
        val baseCanonical = dir.canonicalPath + File.separator
        val targetCanonical = runCatching { candidate.canonicalPath }.getOrNull() ?: return null
        return if (targetCanonical.startsWith(baseCanonical)) candidate else null
    }

    private fun normalizeMediaPath(rawPath: String, expectedFolder: String): String? {
        val cleaned = rawPath.trim().replace('\\', '/')
        if (cleaned.isBlank() || cleaned.contains("..") || cleaned.startsWith("/")) return null
        return if (cleaned.startsWith("$expectedFolder/")) cleaned else "$expectedFolder/${cleaned.trimStart('/')}"
    }

    private fun writeZipEntry(zos: ZipOutputStream, entryName: String, bytes: ByteArray) {
        zos.putNextEntry(ZipEntry(entryName))
        zos.write(bytes)
        zos.closeEntry()
    }

    private fun writeZipFileEntry(zos: ZipOutputStream, entryName: String, file: File) {
        zos.putNextEntry(ZipEntry(entryName))
        BufferedInputStream(FileInputStream(file)).use { it.copyTo(zos) }
        zos.closeEntry()
    }

    private fun syncFile(file: File) {
        check(file.isFile) { "Cannot sync missing file: ${file.absolutePath}" }
        java.io.RandomAccessFile(file, "rw").use { it.fd.sync() }
    }

    private fun nowIso(): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date())

    data class RestoreJournalData(
        val restoreId: String,
        val sourceFileName: String,
        val status: RestoreJournalStatus,
        val stagingDirPath: String?,
        val rollbackDirPath: String?,
        val safetyBackupPath: String?,
        val startedAtIso: String,
        val updatedAtIso: String,
        val lastError: String?
    )

    companion object {
        const val APP_SIGNATURE = "SITE LEDGER"
        const val CURRENT_APP_VERSION = "3.1.0"
        const val MIN_SUPPORTED_FORMAT_VERSION = 1
        const val CURRENT_BACKUP_FORMAT_VERSION = 3
        private const val MAX_JOURNAL_BYTES = 64L * 1024L
        private const val MAX_BACKUP_ARCHIVE_BYTES = 2L * 1024L * 1024L * 1024L
        private const val MAX_BACKUP_EXPANDED_BYTES = 4L * 1024L * 1024L * 1024L
        private const val MAX_BACKUP_ENTRY_BYTES = 512L * 1024L * 1024L
        private const val MAX_MANIFEST_BYTES = 2L * 1024L * 1024L
        private const val MAX_BACKUP_ENTRY_COUNT = 20_000
        private const val MAX_COMPRESSION_RATIO = 1_000L

        const val MANIFEST_ENTRY = "backup_manifest.json"
        const val SCHEMA_SUMMARY_ENTRY = "metadata/schema_summary.json"

        const val STAGE_2_VALIDATION = "STAGE_2_ARCHIVE_VALIDATION"
        const val STAGE_3_EXTRACT = "STAGE_3_EXTRACT_STAGING"
        const val STAGE_4_STAGED_VERIFICATION = "STAGE_4_STAGED_VERIFICATION"
        const val STAGE_5_SAFETY_BACKUP = "STAGE_5_SAFETY_BACKUP"
        const val STAGE_6_PREPARE_ROLLBACK = "STAGE_6_PREPARE_ROLLBACK"
        const val STAGE_7_LIVE_REPLACEMENT = "STAGE_7_LIVE_REPLACEMENT"
        const val STAGE_8_POST_VERIFY = "STAGE_8_POST_RESTORE_VERIFICATION"

        fun sha256File(file: File): String = FileInputStream(file).use { sha256Stream(it) }

        fun sha256Stream(input: InputStream): String {
            val md = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(8192)
            var n: Int
            while (input.read(buf).also { n = it } > 0) {
                md.update(buf, 0, n)
            }
            return md.digest().joinToString("") { "%02x".format(it) }
        }

        fun sha256Bytes(bytes: ByteArray): String =
            MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

        fun requiredTablesForSchema(schemaVersion: Int): List<String> = when {
            schemaVersion >= 6 -> listOf(
                SiteLedgerDatabaseContract.SitesTable.TABLE_NAME,
                SiteLedgerDatabaseContract.WorkersTable.TABLE_NAME,
                SiteLedgerDatabaseContract.AttendanceTable.TABLE_NAME,
                SiteLedgerDatabaseContract.PaymentsTable.TABLE_NAME,
                SiteLedgerDatabaseContract.AdvancesTable.TABLE_NAME,
                SiteLedgerDatabaseContract.PaymentAllocationsTable.TABLE_NAME,
                SiteLedgerDatabaseContract.PayrollPeriodsTable.TABLE_NAME,
                SiteLedgerDatabaseContract.DutySettingsTable.TABLE_NAME,
                SiteLedgerDatabaseContract.ExpenseCategoriesTable.TABLE_NAME,
                SiteLedgerDatabaseContract.ExpensesTable.TABLE_NAME,
                SiteLedgerDatabaseContract.UserSiteAssignmentsTable.TABLE_NAME
            )
            schemaVersion >= 4 -> listOf(
                SiteLedgerDatabaseContract.WorkersTable.TABLE_NAME,
                SiteLedgerDatabaseContract.AttendanceTable.TABLE_NAME,
                SiteLedgerDatabaseContract.PaymentsTable.TABLE_NAME,
                SiteLedgerDatabaseContract.AdvancesTable.TABLE_NAME,
                SiteLedgerDatabaseContract.PaymentAllocationsTable.TABLE_NAME,
                SiteLedgerDatabaseContract.PayrollPeriodsTable.TABLE_NAME
            )
            else -> listOf(
                SiteLedgerDatabaseContract.WorkersTable.TABLE_NAME,
                SiteLedgerDatabaseContract.AttendanceTable.TABLE_NAME,
                SiteLedgerDatabaseContract.PaymentsTable.TABLE_NAME
            )
        }
    }
}

/**
 * Dependency-free JSON serializer & recursive-descent parser for backup manifests and restore journals.
 */
object MiniJson {
    fun stringify(value: Any?, indentLevel: Int = 0): String {
        val sb = StringBuilder()
        writeValue(sb, value, indentLevel)
        return sb.toString()
    }

    private fun writeValue(sb: StringBuilder, value: Any?, indent: Int) {
        when (value) {
            null -> sb.append("null")
            is Boolean -> sb.append(if (value) "true" else "false")
            is Number -> sb.append(value.toString())
            is String -> writeEscapedString(sb, value)
            is Map<*, *> -> {
                if (value.isEmpty()) {
                    sb.append("{}")
                } else {
                    sb.append("{\n")
                    val pad = "  ".repeat(indent + 1)
                    val endPad = "  ".repeat(indent)
                    val entries = value.entries.toList()
                    entries.forEachIndexed { idx, (k, v) ->
                        sb.append(pad)
                        writeEscapedString(sb, k.toString())
                        sb.append(": ")
                        writeValue(sb, v, indent + 1)
                        if (idx < entries.lastIndex) sb.append(",")
                        sb.append("\n")
                    }
                    sb.append(endPad).append("}")
                }
            }
            is Iterable<*> -> {
                val items = value.toList()
                if (items.isEmpty()) {
                    sb.append("[]")
                } else {
                    sb.append("[\n")
                    val pad = "  ".repeat(indent + 1)
                    val endPad = "  ".repeat(indent)
                    items.forEachIndexed { idx, item ->
                        sb.append(pad)
                        writeValue(sb, item, indent + 1)
                        if (idx < items.lastIndex) sb.append(",")
                        sb.append("\n")
                    }
                    sb.append(endPad).append("]")
                }
            }
            else -> writeEscapedString(sb, value.toString())
        }
    }

    private fun writeEscapedString(sb: StringBuilder, s: String) {
        sb.append('"')
        for (ch in s) {
            when (ch) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (ch.code < 0x20) {
                    sb.append("\\u%04x".format(ch.code))
                } else {
                    sb.append(ch)
                }
            }
        }
        sb.append('"')
    }

    fun parse(text: String): Any? = Parser(text).parseRoot()

    private class Parser(private val src: String) {
        private var pos = 0

        fun parseRoot(): Any? {
            skipWhitespace()
            val v = parseValue()
            skipWhitespace()
            require(pos == src.length) { "Unexpected trailing characters at index $pos" }
            return v
        }

        private fun parseValue(): Any? {
            skipWhitespace()
            require(pos < src.length) { "Unexpected end of JSON input" }
            return when (val c = src[pos]) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> parseString()
                't', 'f' -> parseBoolean()
                'n' -> parseNull()
                '-', in '0'..'9' -> parseNumber()
                else -> throw IllegalArgumentException("Unexpected char '$c' at $pos")
            }
        }

        private fun parseObject(): Map<String, Any?> {
            pos++ // '{'
            skipWhitespace()
            val map = linkedMapOf<String, Any?>()
            if (pos < src.length && src[pos] == '}') {
                pos++
                return map
            }
            while (true) {
                skipWhitespace()
                require(pos < src.length && src[pos] == '"') { "Expected string key at $pos" }
                val key = parseString()
                skipWhitespace()
                require(pos < src.length && src[pos] == ':') { "Expected ':' at $pos" }
                pos++
                map[key] = parseValue()
                skipWhitespace()
                require(pos < src.length) { "Unterminated JSON object" }
                when (src[pos]) {
                    ',' -> pos++
                    '}' -> {
                        pos++
                        return map
                    }
                    else -> throw IllegalArgumentException("Expected ',' or '}' at $pos")
                }
            }
        }

        private fun parseArray(): List<Any?> {
            pos++ // '['
            skipWhitespace()
            val list = mutableListOf<Any?>()
            if (pos < src.length && src[pos] == ']') {
                pos++
                return list
            }
            while (true) {
                list.add(parseValue())
                skipWhitespace()
                require(pos < src.length) { "Unterminated JSON array" }
                when (src[pos]) {
                    ',' -> pos++
                    ']' -> {
                        pos++
                        return list
                    }
                    else -> throw IllegalArgumentException("Expected ',' or ']' at $pos")
                }
            }
        }

        private fun parseString(): String {
            pos++ // '"'
            val sb = StringBuilder()
            while (pos < src.length) {
                val ch = src[pos++]
                when (ch) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        require(pos < src.length) { "Unterminated escape sequence" }
                        when (val esc = src[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                require(pos + 4 <= src.length) { "Invalid unicode escape" }
                                val code = src.substring(pos, pos + 4).toInt(16)
                                sb.append(code.toChar())
                                pos += 4
                            }
                            else -> throw IllegalArgumentException("Invalid escape '\\$esc'")
                        }
                    }
                    else -> sb.append(ch)
                }
            }
            throw IllegalArgumentException("Unterminated string")
        }

        private fun parseBoolean(): Boolean =
            if (src.startsWith("true", pos)) {
                pos += 4
                true
            } else if (src.startsWith("false", pos)) {
                pos += 5
                false
            } else {
                throw IllegalArgumentException("Invalid boolean at $pos")
            }

        private fun parseNull(): Any? {
            require(src.startsWith("null", pos)) { "Invalid null literal at $pos" }
            pos += 4
            return null
        }

        private fun parseNumber(): Number {
            val start = pos
            if (src[pos] == '-') pos++
            while (pos < src.length && (src[pos].isDigit() || src[pos] in ".eE+-")) {
                pos++
            }
            val numStr = src.substring(start, pos)
            return if (numStr.contains('.') || numStr.contains('e', true)) {
                numStr.toDouble()
            } else {
                numStr.toLong()
            }
        }

        private fun skipWhitespace() {
            while (pos < src.length && src[pos].isWhitespace()) pos++
        }
    }
}
