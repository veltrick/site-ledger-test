package com.siteledger.app.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apartment
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.EventAvailable
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TableChart
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.siteledger.app.data.sample.SampleSiteData
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.NavDestination
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.service.WageCalculator
import com.siteledger.app.ui.SiteLedgerViewModel
import com.siteledger.app.ui.i18n.BilingualStrings
import com.siteledger.app.ui.screens.AttendanceScreen
import com.siteledger.app.ui.screens.DashboardScreen
import com.siteledger.app.ui.screens.ExpensesScreen
import com.siteledger.app.ui.screens.PaymentsScreen
import com.siteledger.app.ui.screens.PayrollSpreadsheetScreen
import com.siteledger.app.ui.screens.ReportsScreen
import com.siteledger.app.ui.screens.SettingsScreen
import com.siteledger.app.ui.screens.SitesManagementScreen
import com.siteledger.app.ui.screens.WorkersScreen
import com.siteledger.app.ui.theme.CanvasGrey
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.DeepNavyBlue
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.SubtleBorderGrey
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SiteLedgerApp(viewModel: SiteLedgerViewModel = viewModel()) {
    val language by viewModel.currentLanguage.collectAsState()
    val destination by viewModel.currentDestination.collectAsState()
    val sites by viewModel.sites.collectAsState()
    val selectedSiteId by viewModel.selectedSiteId.collectAsState()
    val workers by viewModel.workers.collectAsState()
    val workerTransfers by viewModel.workerTransfers.collectAsState()
    val attendance by viewModel.attendanceRecords.collectAsState()
    val attendanceAudits by viewModel.attendanceAudits.collectAsState()
    val payments by viewModel.payments.collectAsState()
    val advances by viewModel.advances.collectAsState()
    val paymentAllocations by viewModel.paymentAllocations.collectAsState()
    val paymentAudits by viewModel.paymentAudits.collectAsState()
    val payrollPeriods by viewModel.payrollPeriods.collectAsState()
    val expenseCategories by viewModel.expenseCategories.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val userSiteAccounts by viewModel.userSiteAccounts.collectAsState()
    val backupHistory by viewModel.backupHistory.collectAsState()
    val backupProgress by viewModel.backupProgress.collectAsState()
    val pendingRestore by viewModel.pendingRestoreInspectUri.collectAsState()
    val lastBackupValidation by viewModel.lastBackupValidation.collectAsState()
    val restoreRecoveryReport by viewModel.restoreRecoveryReport.collectAsState()
    val backupStatusDetail by viewModel.backupStatusDetail.collectAsState()
    val statusBanner by viewModel.statusBannerMessage.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()
    val activeRole by viewModel.activeRole.collectAsState()

    var pendingProfileWorkerId by remember { mutableStateOf<String?>(null) }
    var siteDropdownExpanded by remember { mutableStateOf(false) }

    val strings = BilingualStrings.forLanguage(language)
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val accessibleSiteIds = remember(activeRole, sites, userSiteAccounts) {
        viewModel.getAccessibleSiteIds()
    }
    val visibleSites = remember(sites, accessibleSiteIds) {
        sites.filter { it.id in accessibleSiteIds }
    }
    val activeSite = remember(sites, selectedSiteId) {
        sites.find { it.id == selectedSiteId } ?: sites.first()
    }

    // Strict per-site data isolation
    val siteWorkers = remember(workers, activeSite.id) { workers.filter { it.siteId == activeSite.id } }
    val siteAttendance = remember(attendance, activeSite.id) { attendance.filter { it.siteId == activeSite.id } }
    val siteAttendanceAudits = remember(attendanceAudits, activeSite.id) { attendanceAudits.filter { it.siteId == activeSite.id } }
    val sitePayments = remember(payments, activeSite.id) { payments.filter { it.siteId == activeSite.id } }
    val siteAdvances = remember(advances, activeSite.id) { advances.filter { it.siteId == activeSite.id } }
    val siteAllocations = remember(paymentAllocations, activeSite.id) { paymentAllocations.filter { it.siteId == activeSite.id } }
    val sitePaymentAudits = remember(paymentAudits, activeSite.id) { paymentAudits.filter { it.siteId == activeSite.id } }
    val sitePayrollPeriods = remember(payrollPeriods, activeSite.id) { payrollPeriods.filter { it.siteId == activeSite.id } }
    val siteExpenses = remember(expenses, activeSite.id) { expenses.filter { it.siteId == activeSite.id } }
    val siteDutyConfig = remember(activeSite.id) { viewModel.getDutyConfigForSelectedSite() }

    val todayIso = SampleSiteData.availableDates.first()
    val todayAttendance = siteAttendance.filter { it.dateIso == todayIso }
    val presentToday = todayAttendance.count { it.dutyType != DutyType.ABSENT && it.dutyType != DutyType.LEAVE }
    val absentToday = todayAttendance.count { it.dutyType == DutyType.ABSENT }
    val todaysPaymentsTotal = sitePayments.filter { !it.isVoided && it.dateIso == todayIso }.sumOf { it.paidAmount }
    val siteFinancials = remember(activeSite, workers, attendance, paymentAllocations, expenses) {
        WageCalculator.computeSiteFinancialSummary(
            site = activeSite,
            workers = workers,
            attendance = attendance,
            allocations = paymentAllocations,
            expenses = expenses,
            periodIsoFilter = "2026-11"
        )
    }

    val drawerItems = listOf(
        Triple(NavDestination.DASHBOARD, strings.navDashboard, Icons.Outlined.Dashboard),
        Triple(NavDestination.WORKERS, strings.navWorkers, Icons.Outlined.Groups),
        Triple(NavDestination.ATTENDANCE, strings.navAttendance, Icons.Outlined.EventAvailable),
        Triple(NavDestination.SPREADSHEET, strings.navSpreadsheet, Icons.Outlined.TableChart),
        Triple(NavDestination.PAYMENTS, strings.navPayments, Icons.Outlined.Payments),
        Triple(NavDestination.EXPENSES, strings.navExpenses, Icons.Outlined.ReceiptLong),
        Triple(NavDestination.REPORTS, strings.navReports, Icons.Outlined.Assessment),
        Triple(NavDestination.SITES, strings.navSites, Icons.Outlined.Apartment),
        Triple(NavDestination.SETTINGS, strings.navSettings, Icons.Outlined.Settings)
    )

    val bottomNavItems = listOf(
        Triple(NavDestination.DASHBOARD, strings.navDashboard, Icons.Outlined.Dashboard),
        Triple(NavDestination.WORKERS, strings.navWorkers, Icons.Outlined.Groups),
        Triple(NavDestination.ATTENDANCE, strings.navAttendance, Icons.Outlined.EventAvailable),
        Triple(NavDestination.EXPENSES, strings.navExpenses, Icons.Outlined.ReceiptLong),
        Triple(NavDestination.SPREADSHEET, strings.navSpreadsheet, Icons.Outlined.TableChart)
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(strings.appName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = DeepNavyBlue)
                    Text(strings.appSubtitle, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                }
                Spacer(modifier = Modifier.height(4.dp))
                drawerItems.forEach { (nav, label, icon) ->
                    NavigationDrawerItem(
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        selected = destination == nav,
                        onClick = {
                            viewModel.navigateTo(nav)
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = CanvasGrey,
            topBar = {
                Column(modifier = Modifier.background(CrispWhite)) {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = CrispWhite),
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Outlined.Menu, contentDescription = "Menu")
                            }
                        },
                        title = {
                            Column {
                                Text(strings.appName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(strings.appSubtitle, style = MaterialTheme.typography.bodySmall, color = SlateMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        },
                        actions = {
                            IconButton(onClick = { viewModel.navigateTo(NavDestination.SETTINGS) }) {
                                Icon(Icons.Outlined.Settings, contentDescription = strings.navSettings)
                            }
                        }
                    )
                    // Persistent Active Construction Site Switcher
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { siteDropdownExpanded = true },
                            shape = RoundedCornerShape(10.dp),
                            color = CanvasGrey
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.Apartment, contentDescription = null, tint = EngineeringBlue)
                                    Column {
                                        Text(
                                            text = "${strings.activeSiteLabel}: ${activeSite.siteName}",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.SemiBold,
                                            color = SlateInk,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${activeSite.siteCode} · ${siteWorkers.size} ${strings.navWorkers} · ${activeSite.siteManager}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = SlateMuted
                                        )
                                    }
                                }
                                Icon(Icons.Outlined.ExpandMore, contentDescription = null, tint = SlateMuted)
                            }
                        }
                        DropdownMenu(
                            expanded = siteDropdownExpanded,
                            onDismissRequest = { siteDropdownExpanded = false }
                        ) {
                            visibleSites.forEach { site ->
                                DropdownMenuItem(
                                    text = { Text("${site.siteCode} — ${site.siteName}") },
                                    onClick = {
                                        viewModel.selectSite(site.id)
                                        siteDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    HorizontalDivider(color = SubtleBorderGrey)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = CrispWhite) {
                    bottomNavItems.forEach { (nav, label, icon) ->
                        NavigationBarItem(
                            selected = destination == nav,
                            onClick = { viewModel.navigateTo(nav) },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(modifier = Modifier.padding(innerPadding)) {
                statusBanner?.let { banner ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CrispWhite)
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(banner, style = MaterialTheme.typography.bodySmall, color = EngineeringBlue, modifier = Modifier.weight(1f))
                        TextButton(onClick = viewModel::clearStatusBanner) { Text(strings.close) }
                    }
                }

                when (destination) {
                    NavDestination.DASHBOARD -> DashboardScreen(
                        strings = strings,
                        activeSite = activeSite,
                        totalWorkers = siteWorkers.size,
                        presentToday = presentToday,
                        absentToday = absentToday,
                        todaysPaymentsTotal = todaysPaymentsTotal,
                        earnedPayrollTotal = siteFinancials.totalEarnedPayroll,
                        paidPayrollTotal = siteFinancials.totalPaidPayroll,
                        generalExpensesTotal = siteFinancials.totalGeneralExpenses,
                        outstandingPayrollTotal = siteFinancials.totalOutstandingPayroll,
                        onNavigate = viewModel::navigateTo
                    )

                    NavDestination.WORKERS -> WorkersScreen(
                        strings = strings,
                        language = language,
                        activeSite = activeSite,
                        allSites = sites,
                        workers = siteWorkers,
                        allWorkersAcrossSites = workers,
                        workerTransfers = workerTransfers,
                        activeRole = activeRole,
                        dutyConfig = siteDutyConfig,
                        allAttendance = attendance,
                        attendanceAudits = siteAttendanceAudits,
                        allPayments = payments,
                        advances = advances,
                        paymentAllocations = paymentAllocations,
                        paymentAudits = sitePaymentAudits,
                        payrollPeriods = payrollPeriods,
                        initialProfileWorkerId = pendingProfileWorkerId,
                        onConsumeInitialProfileWorker = { pendingProfileWorkerId = null },
                        onAddWorker = { name, code, phone, cat, join, wage, food, uri ->
                            viewModel.addWorker(name, code, phone, cat, join, wage, food, uri, activeSite.id)
                        },
                        onEditWorker = viewModel::updateWorker,
                        onTransferWorker = viewModel::transferWorker,
                        onSaveAttendance = { w, d, duty, note, reason ->
                            viewModel.recordAttendance(d, w, duty, note, reason, activeSite.id)
                        },
                        onRecordPayment = { wId, pDate, period, amt, ref, note, token ->
                            viewModel.recordPayment(wId, pDate, period, amt, ref, note, token, activeSite.id)
                        },
                        onRecordAdvance = { wId, aDate, amt, ref, note, token ->
                            viewModel.recordAdvance(wId, aDate, amt, ref, note, token, activeSite.id)
                        },
                        onAllocateAdvance = viewModel::allocateAdvanceToPeriod,
                        onVoidPayment = viewModel::voidPayment
                    )

                    NavDestination.ATTENDANCE -> AttendanceScreen(
                        strings = strings,
                        language = language,
                        activeRole = activeRole,
                        dutyConfig = siteDutyConfig,
                        availableDates = SampleSiteData.availableDates,
                        selectedDate = selectedDate,
                        onSelectDate = viewModel::selectDate,
                        workers = siteWorkers,
                        records = siteAttendance,
                        payrollPeriods = sitePayrollPeriods,
                        onMarkDuty = { w, duty, note, reason ->
                            viewModel.recordAttendance(selectedDate, w, duty, note, reason, activeSite.id)
                        }
                    )

                    NavDestination.SPREADSHEET -> PayrollSpreadsheetScreen(
                        strings = strings,
                        language = language,
                        activeRole = activeRole,
                        activeSite = activeSite,
                        sites = visibleSites,
                        workers = workers,
                        attendance = attendance,
                        allocations = paymentAllocations,
                        payrollPeriods = payrollPeriods,
                        onWorkerClick = { workerId ->
                            pendingProfileWorkerId = workerId
                            viewModel.navigateTo(NavDestination.WORKERS)
                        },
                        onFinalizePeriod = { periodIso, reason ->
                            viewModel.finalizePayrollPeriod(periodIso, reason, activeSite.id)
                        },
                        onReopenPeriod = { periodIso, reason ->
                            viewModel.reopenPayrollPeriod(periodIso, reason, activeSite.id)
                        }
                    )

                    NavDestination.PAYMENTS -> PaymentsScreen(
                        strings = strings,
                        language = language,
                        activeRole = activeRole,
                        workers = siteWorkers,
                        attendance = siteAttendance,
                        payments = sitePayments,
                        advances = siteAdvances,
                        allocations = siteAllocations,
                        payrollPeriods = sitePayrollPeriods,
                        onRecordPayment = { wId, pDate, period, amt, ref, note, token ->
                            viewModel.recordPayment(wId, pDate, period, amt, ref, note, token, activeSite.id)
                        },
                        onRecordAdvance = { wId, aDate, amt, ref, note, token ->
                            viewModel.recordAdvance(wId, aDate, amt, ref, note, token, activeSite.id)
                        },
                        onAllocateAdvance = viewModel::allocateAdvanceToPeriod,
                        onVoidPayment = viewModel::voidPayment
                    )

                    NavDestination.EXPENSES -> ExpensesScreen(
                        strings = strings,
                        language = language,
                        activeRole = activeRole,
                        activeSite = activeSite,
                        categories = expenseCategories,
                        expenses = siteExpenses,
                        onSaveExpense = viewModel::addOrUpdateExpense,
                        onVoidExpense = viewModel::voidExpense,
                        onAddCategory = viewModel::addCustomExpenseCategory
                    )

                    NavDestination.REPORTS -> ReportsScreen(
                        strings = strings,
                        language = language,
                        activeSite = activeSite,
                        sites = visibleSites,
                        workers = siteWorkers,
                        attendance = siteAttendance,
                        allocations = siteAllocations,
                        payrollPeriods = sitePayrollPeriods,
                        siteExpenses = siteExpenses,
                        allWorkers = workers,
                        allAttendance = attendance,
                        allAllocations = paymentAllocations,
                        allExpenses = expenses
                    )

                    NavDestination.SITES -> SitesManagementScreen(
                        strings = strings,
                        language = language,
                        activeRole = activeRole,
                        sites = visibleSites,
                        workers = workers,
                        attendance = attendance,
                        allocations = paymentAllocations,
                        expenses = expenses,
                        userSiteAccounts = userSiteAccounts,
                        onSelectSite = { siteId ->
                            viewModel.selectSite(siteId)
                            viewModel.navigateTo(NavDestination.DASHBOARD)
                        },
                        onSaveSite = viewModel::addOrUpdateSite,
                        onUpdateSiteStatus = viewModel::updateSiteStatus,
                        onUpdateRoleSiteAccess = viewModel::updateUserSiteAssignments
                    )

                    NavDestination.SETTINGS -> SettingsScreen(
                        strings = strings,
                        currentLanguage = language,
                        activeRole = activeRole,
                        dutyConfig = siteDutyConfig,
                        backupHistory = backupHistory,
                        backupProgress = backupProgress,
                        pendingRestoreValidation = pendingRestore?.second,
                        lastValidationResult = lastBackupValidation,
                        recoveryReport = restoreRecoveryReport,
                        backupStatusDetail = backupStatusDetail,
                        suggestedBackupFileName = viewModel.suggestedBackupFileName(),
                        onSelectLanguage = viewModel::setLanguage,
                        onSelectRole = viewModel::setActiveRole,
                        onSaveMultipliers = viewModel::updateDutyMultipliers,
                        onCreateBackupToUri = viewModel::createFullBackup,
                        onInspectBackupUri = viewModel::inspectBackupForVerifyOrRestore,
                        onConfirmRestore = viewModel::confirmRestoreFromPendingUri,
                        onDismissPendingRestore = viewModel::dismissPendingRestore,
                        onRetryRecovery = viewModel::runStartupRecoveryCheck,
                        onRefreshBackupHistory = viewModel::refreshBackupHistory,
                        onResetSampleData = viewModel::resetSampleData
                    )
                }
            }
        }
    }
}
