package com.siteledger.app.ui.screens

import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.BackupHistoryRecord
import com.siteledger.app.domain.model.BackupProgress
import com.siteledger.app.domain.model.BackupValidationResult
import com.siteledger.app.domain.model.DutyMultiplierConfig
import com.siteledger.app.domain.model.RestoreRecoveryReport
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.ui.components.BackupRestoreSection
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusAmber
import com.siteledger.app.ui.theme.SubtleBorderGrey

@Composable
fun SettingsScreen(
    strings: AppStrings,
    currentLanguage: AppLanguage,
    activeRole: UserRole,
    dutyConfig: DutyMultiplierConfig,
    backupHistory: List<BackupHistoryRecord>,
    backupProgress: BackupProgress,
    pendingRestoreValidation: BackupValidationResult?,
    lastValidationResult: BackupValidationResult?,
    recoveryReport: RestoreRecoveryReport?,
    backupStatusDetail: String?,
    suggestedBackupFileName: String,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectRole: (UserRole) -> Unit,
    onSaveMultipliers: (DutyMultiplierConfig) -> Unit,
    onCreateBackupToUri: (Uri) -> Unit,
    onInspectBackupUri: (Uri, Boolean) -> Unit,
    onConfirmRestore: () -> Unit,
    onDismissPendingRestore: () -> Unit,
    onRetryRecovery: () -> Unit,
    onRefreshBackupHistory: () -> Unit,
    onResetSampleData: () -> Unit
) {
    var halfText by remember(dutyConfig) { mutableStateOf(dutyConfig.halfDutyMultiplier.toString()) }
    var fullText by remember(dutyConfig) { mutableStateOf(dutyConfig.fullDutyMultiplier.toString()) }
    var oneAndHalfText by remember(dutyConfig) { mutableStateOf(dutyConfig.oneAndHalfDutyMultiplier.toString()) }
    var doubleText by remember(dutyConfig) { mutableStateOf(dutyConfig.doubleDutyMultiplier.toString()) }
    var twoAndHalfText by remember(dutyConfig) { mutableStateOf(dutyConfig.twoAndHalfDutyMultiplier.toString()) }
    var tripleText by remember(dutyConfig) { mutableStateOf(dutyConfig.tripleDutyMultiplier.toString()) }
    var absentText by remember(dutyConfig) { mutableStateOf(dutyConfig.absentMultiplier.toString()) }
    var leaveText by remember(dutyConfig) { mutableStateOf(dutyConfig.leaveMultiplier.toString()) }

    val isAdmin = activeRole == UserRole.ADMIN

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.languageSettingTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = SlateInk)
                    Text(strings.languageSettingDesc, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppLanguage.entries.forEach { language ->
                            FilterChip(
                                selected = currentLanguage == language,
                                onClick = { onSelectLanguage(language) },
                                label = { Text(language.displayLabel) }
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.roleSettingTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = SlateInk)
                    Text(strings.roleSettingDesc, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        UserRole.entries.forEach { role ->
                            FilterChip(
                                selected = activeRole == role,
                                onClick = { onSelectRole(role) },
                                label = { Text(if (currentLanguage == AppLanguage.BENGALI) role.labelBn else role.labelEn) }
                            )
                        }
                    }
                }
            }
        }

        item {
            BackupRestoreSection(
                strings = strings,
                backupHistory = backupHistory,
                backupProgress = backupProgress,
                pendingRestoreValidation = pendingRestoreValidation,
                lastValidationResult = lastValidationResult,
                recoveryReport = recoveryReport,
                backupStatusDetail = backupStatusDetail,
                suggestedBackupFileName = suggestedBackupFileName,
                onCreateBackupToUri = onCreateBackupToUri,
                onInspectBackupUri = onInspectBackupUri,
                onConfirmRestore = onConfirmRestore,
                onDismissPendingRestore = onDismissPendingRestore,
                onRetryRecovery = onRetryRecovery,
                onRefreshHistory = onRefreshBackupHistory
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.dutyMultiplierSettingTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = SlateInk)
                    Text(strings.dutyMultiplierSettingDesc, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = halfText, onValueChange = { halfText = it }, enabled = isAdmin, label = { Text(strings.halfDutyLabel) }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = fullText, onValueChange = { fullText = it }, enabled = isAdmin, label = { Text(strings.fullDutyLabel) }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = oneAndHalfText, onValueChange = { oneAndHalfText = it }, enabled = isAdmin, label = { Text(strings.oneAndHalfDutyLabel) }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = doubleText, onValueChange = { doubleText = it }, enabled = isAdmin, label = { Text(strings.doubleDutyLabel) }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = twoAndHalfText, onValueChange = { twoAndHalfText = it }, enabled = isAdmin, label = { Text(strings.twoAndHalfDutyLabel) }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = tripleText, onValueChange = { tripleText = it }, enabled = isAdmin, label = { Text(strings.tripleDutyLabel) }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = absentText, onValueChange = { absentText = it }, enabled = isAdmin, label = { Text(strings.absentLabel) }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = leaveText, onValueChange = { leaveText = it }, enabled = isAdmin, label = { Text(strings.leaveLabel) }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    if (!isAdmin) {
                        Text(strings.adminOnlyWarning, style = MaterialTheme.typography.bodySmall, color = StatusAmber)
                    } else {
                        Button(onClick = {
                            onSaveMultipliers(
                                DutyMultiplierConfig(
                                    halfDutyMultiplier = halfText.toDoubleOrNull() ?: 0.5,
                                    fullDutyMultiplier = fullText.toDoubleOrNull() ?: 1.0,
                                    oneAndHalfDutyMultiplier = oneAndHalfText.toDoubleOrNull() ?: 1.5,
                                    doubleDutyMultiplier = doubleText.toDoubleOrNull() ?: 2.0,
                                    twoAndHalfDutyMultiplier = twoAndHalfText.toDoubleOrNull() ?: 2.5,
                                    tripleDutyMultiplier = tripleText.toDoubleOrNull() ?: 3.0,
                                    absentMultiplier = absentText.toDoubleOrNull() ?: 0.0,
                                    leaveMultiplier = leaveText.toDoubleOrNull() ?: 0.0
                                )
                            )
                        }) {
                            Text(strings.saveMultipliers)
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.dataStageNoticeTitle, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                    Text(strings.dataStageNoticeBody, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                    OutlinedButton(onClick = onResetSampleData) { Text(strings.resetSampleData) }
                }
            }
        }
    }
}
