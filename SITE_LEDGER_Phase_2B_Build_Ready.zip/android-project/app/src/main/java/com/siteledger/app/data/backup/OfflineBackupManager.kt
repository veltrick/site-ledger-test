package com.siteledger.app.data.backup

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.provider.OpenableColumns
import com.siteledger.app.data.local.SiteLedgerDatabaseContract
import com.siteledger.app.data.local.SiteLedgerSqliteOpenHelper
import com.siteledger.app.data.local.WorkerPhotoStorage
import com.siteledger.app.domain.model.BackupHistoryRecord
import com.siteledger.app.domain.model.BackupProgress
import com.siteledger.app.domain.model.BackupRecordCounts
import com.siteledger.app.domain.model.BackupValidationResult
import com.siteledger.app.domain.model.RestoreRecoveryReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * 100% offline, crash-safe Backup & Restore manager for SITE LEDGER (Android SAF wrapper).
 *
 * Package structure (Format v3, backward compatible with valid Format v1 and v2):
 *   backup_manifest.json
 *   metadata/schema_summary.json
 *   database/site_ledger_offline.db
 *   worker_photos/...
 *   receipt_images/...
 *
 * Safeguards delegated to BackupSecurityEngine:
 * - Mutual-exclusion lock + verified PRAGMA wal_checkpoint(FULL) (busy == 0) before snapshotting DB
 * - 11-point validation (ZIP integrity, mandatory entries, JSON manifest, supported format/schema,
 *   SQLite PRAGMA integrity_check, all DB-referenced photos/receipts, exact record counts, SHA-256)
 * - Persistent crash-recovery journal under filesDir/backup_engine/restore_state/ (never cacheDir)
 * - 9-stage recoverable restore with permanent pre-restore safety backup in filesDir/safety_backups/
 * - Idempotent startup crash recovery if process exits mid-swap
 */
class OfflineBackupManager(
    context: Context,
    private val dbHelper: SiteLedgerSqliteOpenHelper,
    private val mediaStorage: WorkerPhotoStorage
) {
    private val appContext = context.applicationContext
    private val backupMutex = Mutex()

    private val sqliteBridge = AndroidBackupSqliteBridge(appContext, dbHelper)

    private val securityEngine = BackupSecurityEngine(
        workspaceRootDir = File(appContext.filesDir, "backup_engine").apply { mkdirs() },
        liveDbFile = appContext.getDatabasePath(SiteLedgerDatabaseContract.DATABASE_NAME),
        livePhotosDir = mediaStorage.photosDirectory,
        liveReceiptsDir = mediaStorage.receiptsDirectory,
        safetyBackupsDir = mediaStorage.safetyBackupsDirectory,
        sqliteBridge = sqliteBridge
    )

    fun suggestedBackupFileName(): String = Companion.suggestedBackupFileName()

    suspend fun recoverInterruptedRestoreIfNeeded(
        onProgress: (BackupProgress) -> Unit = {}
    ): RestoreRecoveryReport = backupMutex.withLock {
        withContext(Dispatchers.IO) {
            securityEngine.recoverInterruptedRestoreIfNeeded(onProgress)
        }
    }

    suspend fun createFullBackupToUri(
        targetUri: Uri,
        onProgress: (BackupProgress) -> Unit = {}
    ): Result<BackupHistoryRecord> = backupMutex.withLock {
        withContext(Dispatchers.IO) {
            runCatching {
                val fileName = queryDisplayName(targetUri) ?: suggestedBackupFileName()
                val tempOutFile = File(appContext.cacheDir, "tmp_backup_${UUID.randomUUID()}.zip")
                try {
                    val record = securityEngine.createBackupArchiveToFile(
                        destZipFile = tempOutFile,
                        displayFileName = fileName,
                        onProgress = onProgress
                    ).getOrThrow()

                    onProgress(BackupProgress(true, "BACKUP", 85, "Writing backup archive to selected folder..."))
                    appContext.contentResolver.openOutputStream(targetUri)?.use { dest ->
                        FileInputStream(tempOutFile).use { src -> src.copyTo(dest) }
                        if (dest is FileOutputStream) {
                            runCatching { dest.fd.sync() }
                        }
                    } ?: error("Unable to open destination file stream")

                    onProgress(BackupProgress(true, "BACKUP", 95, "Verifying saved SAF backup archive..."))
                    val verified = verifyArchiveFromUri(targetUri, fileName)
                    check(verified.isValid) {
                        "Post-write SAF backup verification failed: ${verified.errors.joinToString("; ")}"
                    }

                    val finalRecord = record.copy(
                        locationUriOrPath = targetUri.toString(),
                        fileExists = true
                    )
                    dbHelper.insertBackupHistory(finalRecord)
                    onProgress(BackupProgress(false, "BACKUP", 100, "Backup verified & saved"))
                    finalRecord
                } finally {
                    runCatching { tempOutFile.delete() }
                }
            }
        }
    }

    suspend fun createFullBackupToFile(
        targetFile: File,
        onProgress: (BackupProgress) -> Unit = {}
    ): Result<BackupHistoryRecord> = backupMutex.withLock {
        withContext(Dispatchers.IO) {
            securityEngine.createBackupArchiveToFile(targetFile, targetFile.name, onProgress = onProgress)
                .onSuccess { rec -> dbHelper.insertBackupHistory(rec) }
        }
    }

    suspend fun inspectAndVerifyBackupUri(
        sourceUri: Uri,
        onProgress: (BackupProgress) -> Unit = {}
    ): BackupValidationResult = backupMutex.withLock {
        withContext(Dispatchers.IO) {
            onProgress(BackupProgress(true, "VERIFY", 20, "Validating backup archive, database & media..."))
            val name = queryDisplayName(sourceUri) ?: "backup.zip"
            val res = verifyArchiveFromUri(sourceUri, name)
            onProgress(BackupProgress(false, "VERIFY", 100, if (res.isValid) "Validation passed" else "Validation failed"))
            res
        }
    }

    suspend fun inspectAndVerifyBackupFile(file: File): BackupValidationResult =
        withContext(Dispatchers.IO) { securityEngine.validateArchiveFile(file) }

    suspend fun restoreFromBackupUri(
        sourceUri: Uri,
        onProgress: (BackupProgress) -> Unit = {}
    ): Result<BackupValidationResult> = backupMutex.withLock {
        withContext(Dispatchers.IO) {
            runCatching {
                val stagedZip = File(appContext.cacheDir, "tmp_restore_${UUID.randomUUID()}.zip")
                try {
                    onProgress(BackupProgress(true, "RESTORE", 5, "Stage 1: Reading selected backup archive..."))
                    appContext.contentResolver.openInputStream(sourceUri)?.use { input ->
                        FileOutputStream(stagedZip).use { out ->
                            input.copyTo(out)
                            out.fd.sync()
                        }
                    } ?: throw BackupRestoreException(
                        failedStage = "STAGE_1_READ_URI",
                        recoveryAttempted = false,
                        recoverySucceeded = true,
                        safetyBackupPath = null,
                        message = "Stage 1 failed: Cannot open selected backup archive"
                    )
                    securityEngine.executeStagedRestoreFromFile(
                        zipFile = stagedZip,
                        fileName = queryDisplayName(sourceUri) ?: "backup.zip",
                        onProgress = onProgress
                    )
                } finally {
                    runCatching { stagedZip.delete() }
                }
            }
        }
    }

    suspend fun restoreFromBackupFile(
        sourceFile: File,
        onProgress: (BackupProgress) -> Unit = {}
    ): Result<BackupValidationResult> = backupMutex.withLock {
        withContext(Dispatchers.IO) {
            runCatching {
                securityEngine.executeStagedRestoreFromFile(
                    zipFile = sourceFile,
                    fileName = sourceFile.name,
                    onProgress = onProgress
                )
            }
        }
    }

    fun verifyArchiveFile(zipFile: File, overrideName: String? = null): BackupValidationResult =
        securityEngine.validateArchiveFile(zipFile, overrideName)

    fun isBackupLocationAvailable(locationUriOrPath: String): Boolean {
        if (locationUriOrPath.startsWith("content://")) {
            return runCatching {
                val uri = Uri.parse(locationUriOrPath)
                appContext.contentResolver.openInputStream(uri)?.use { true } ?: false
            }.getOrDefault(false)
        }
        val f = File(locationUriOrPath)
        return f.exists() && f.isFile
    }

    private fun verifyArchiveFromUri(uri: Uri, name: String): BackupValidationResult {
        val tempFile = File(appContext.cacheDir, "verify_${UUID.randomUUID()}.zip")
        return try {
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { out ->
                    input.copyTo(out)
                    out.fd.sync()
                }
            } ?: return BackupValidationResult(
                isValid = false,
                fileName = name,
                createdAtIso = "",
                appVersion = "",
                schemaVersion = 0,
                formatVersion = 0,
                counts = BackupRecordCounts(),
                checksumVerified = false,
                sqliteIntegrityOk = false,
                isOlderThanCurrentData = false,
                missingMediaCount = 0,
                errors = listOf("Unable to open selected backup archive"),
                countsMatched = false,
                mediaIntegrityOk = false
            )
            securityEngine.validateArchiveFile(tempFile, name)
        } finally {
            runCatching { tempFile.delete() }
        }
    }

    private fun queryDisplayName(uri: Uri): String? = runCatching {
        appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    private class AndroidBackupSqliteBridge(
        private val appContext: Context,
        private val dbHelper: SiteLedgerSqliteOpenHelper
    ) : BackupSqliteBridge {

        override fun checkpointLiveDatabase(): WalCheckpointResult = runCatching {
            val db = dbHelper.writableDatabase
            db.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { c ->
                if (!c.moveToFirst()) {
                    return@runCatching WalCheckpointResult(
                        success = false,
                        errorMessage = "PRAGMA wal_checkpoint(FULL) returned no result row"
                    )
                }
                val busy = c.getInt(0)
                val logPages = c.getInt(1)
                val checkpointed = c.getInt(2)
                val complete = (busy == 0) && (logPages <= 0 || checkpointed >= logPages)
                WalCheckpointResult(
                    success = complete,
                    busy = busy,
                    logPages = logPages,
                    checkpointedPages = checkpointed,
                    errorMessage = if (complete) null else "WAL checkpoint blocked or incomplete (busy=$busy, log=$logPages, checkpointed=$checkpointed)"
                )
            }
        }.getOrElse { err ->
            WalCheckpointResult(
                success = false,
                errorMessage = "WAL checkpoint error: ${err.message ?: "SQLite failure"}"
            )
        }

        override fun copyLiveDatabaseTo(destFile: File): Boolean = runCatching {
            val liveDbFile = appContext.getDatabasePath(SiteLedgerDatabaseContract.DATABASE_NAME)
            if (!liveDbFile.exists() || !liveDbFile.isFile) return@runCatching false
            destFile.parentFile?.mkdirs()
            FileInputStream(liveDbFile).use { input ->
                FileOutputStream(destFile).use { out ->
                    input.copyTo(out)
                    out.fd.sync()
                }
            }
            true
        }.getOrDefault(false)

        override fun closeDatabaseBeforeSwap() {
            dbHelper.close()
        }

        override fun reopenAndVerifyDatabase(expectedSchemaVersion: Int): SqliteInspectionResult {
            return runCatching {
                val db = dbHelper.writableDatabase
                inspectOpenDatabase(db, expectedSchemaVersion)
            }.getOrElse { err ->
                SqliteInspectionResult(
                    integrityOk = false,
                    missingTables = BackupSecurityEngine.requiredTablesForSchema(expectedSchemaVersion),
                    counts = BackupRecordCounts(),
                    referencedWorkerPhotos = emptyList(),
                    referencedReceiptImages = emptyList(),
                    errorMessage = "Unable to reopen restored SQLite DB: ${err.message}"
                )
            }
        }

        override fun inspectDatabaseFile(dbFile: File, expectedSchemaVersion: Int): SqliteInspectionResult {
            return runCatching {
                SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { db ->
                    inspectOpenDatabase(db, expectedSchemaVersion)
                }
            }.getOrElse { err ->
                SqliteInspectionResult(
                    integrityOk = false,
                    missingTables = BackupSecurityEngine.requiredTablesForSchema(expectedSchemaVersion),
                    counts = BackupRecordCounts(),
                    referencedWorkerPhotos = emptyList(),
                    referencedReceiptImages = emptyList(),
                    errorMessage = "SQLite file unreadable or corrupted: ${err.message}"
                )
            }
        }

        override fun readLatestBackupTimestamp(): String? =
            runCatching { dbHelper.readBackupHistory().firstOrNull()?.createdAtIso }.getOrNull()

        private fun inspectOpenDatabase(db: SQLiteDatabase, schemaVersion: Int): SqliteInspectionResult {
            val integrityOk = db.rawQuery("PRAGMA integrity_check", null).use { c ->
                c.moveToFirst() && c.getString(0).equals("ok", ignoreCase = true)
            }

            val existingTables = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                while (c.moveToNext()) {
                    existingTables.add(c.getString(0))
                }
            }

            val requiredTables = BackupSecurityEngine.requiredTablesForSchema(schemaVersion)
            val missingTables = requiredTables.filterNot { it in existingTables }

            fun countIfPresent(table: String): Int {
                if (table !in existingTables) return 0
                return runCatching {
                    db.rawQuery("SELECT COUNT(*) FROM $table", null).use { c ->
                        if (c.moveToFirst()) c.getInt(0) else 0
                    }
                }.getOrDefault(0)
            }

            val counts = BackupRecordCounts(
                sites = countIfPresent(SiteLedgerDatabaseContract.SitesTable.TABLE_NAME),
                workers = countIfPresent(SiteLedgerDatabaseContract.WorkersTable.TABLE_NAME),
                attendanceRecords = countIfPresent(SiteLedgerDatabaseContract.AttendanceTable.TABLE_NAME),
                payments = countIfPresent(SiteLedgerDatabaseContract.PaymentsTable.TABLE_NAME),
                advances = countIfPresent(SiteLedgerDatabaseContract.AdvancesTable.TABLE_NAME),
                allocations = countIfPresent(SiteLedgerDatabaseContract.PaymentAllocationsTable.TABLE_NAME),
                expenses = countIfPresent(SiteLedgerDatabaseContract.ExpensesTable.TABLE_NAME),
                payrollPeriods = countIfPresent(SiteLedgerDatabaseContract.PayrollPeriodsTable.TABLE_NAME)
            )

            val workerPhotos = mutableListOf<String>()
            if (SiteLedgerDatabaseContract.WorkersTable.TABLE_NAME in existingTables) {
                val col = SiteLedgerDatabaseContract.WorkersTable.COL_PHOTO_PATH
                val hasCol = hasColumn(db, SiteLedgerDatabaseContract.WorkersTable.TABLE_NAME, col)
                if (hasCol) {
                    db.rawQuery(
                        "SELECT DISTINCT $col FROM ${SiteLedgerDatabaseContract.WorkersTable.TABLE_NAME} WHERE $col IS NOT NULL AND TRIM($col) != ''",
                        null
                    ).use { c ->
                        while (c.moveToNext()) {
                            workerPhotos.add(c.getString(0))
                        }
                    }
                }
            }

            val receiptImages = mutableListOf<String>()
            if (SiteLedgerDatabaseContract.ExpensesTable.TABLE_NAME in existingTables) {
                val col = SiteLedgerDatabaseContract.ExpensesTable.COL_RECEIPT_PHOTO_PATH
                if (hasColumn(db, SiteLedgerDatabaseContract.ExpensesTable.TABLE_NAME, col)) {
                    db.rawQuery(
                        "SELECT DISTINCT $col FROM ${SiteLedgerDatabaseContract.ExpensesTable.TABLE_NAME} WHERE $col IS NOT NULL AND TRIM($col) != ''",
                        null
                    ).use { c ->
                        while (c.moveToNext()) {
                            receiptImages.add(c.getString(0))
                        }
                    }
                }
            }

            return SqliteInspectionResult(
                integrityOk = integrityOk,
                missingTables = missingTables,
                counts = counts,
                referencedWorkerPhotos = workerPhotos,
                referencedReceiptImages = receiptImages,
                errorMessage = if (!integrityOk) "SQLite PRAGMA integrity_check failed" else null
            )
        }

        private fun hasColumn(db: SQLiteDatabase, table: String, column: String): Boolean =
            db.rawQuery("PRAGMA table_info($table)", null).use { c ->
                val nameIdx = c.getColumnIndex("name")
                while (c.moveToNext()) {
                    if (nameIdx >= 0 && c.getString(nameIdx).equals(column, ignoreCase = true)) {
                        return@use true
                    }
                }
                false
            }
    }

    companion object {
        const val BACKUP_FORMAT_VERSION = BackupSecurityEngine.CURRENT_BACKUP_FORMAT_VERSION

        fun suggestedBackupFileName(): String {
            val stamp = SimpleDateFormat("yyyy_MM_dd_HH_mm", Locale.US).format(Date())
            return "SITE_LEDGER_BACKUP_${stamp}.zip"
        }

        fun sha256Hex(bytes: ByteArray): String = BackupSecurityEngine.sha256Bytes(bytes)
    }
}
