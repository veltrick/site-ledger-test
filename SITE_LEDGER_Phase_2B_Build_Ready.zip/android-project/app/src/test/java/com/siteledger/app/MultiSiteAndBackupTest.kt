package com.siteledger.app

import com.siteledger.app.data.backup.OfflineBackupManager
import com.siteledger.app.data.repository.InMemorySampleSiteLedgerRepository
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.ExpensePaymentMethod
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteExpense
import com.siteledger.app.domain.model.SiteStatus
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.WorkCategory
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.service.WageCalculator
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MultiSiteAndBackupTest {

    private val siteA = Site(
        id = "SITE-A",
        siteName = "Gulshan Foundation",
        siteCode = "GLS-01",
        address = "Gulshan, Dhaka",
        clientName = "Client A",
        siteManager = "Manager A",
        startDateIso = "2026-01-01",
        status = SiteStatus.ACTIVE
    )

    private val siteB = Site(
        id = "SITE-B",
        siteName = "Banani Annex",
        siteCode = "BNN-02",
        address = "Banani, Dhaka",
        clientName = "Client B",
        siteManager = "Manager B",
        startDateIso = "2026-06-01",
        status = SiteStatus.ACTIVE
    )

    @Test
    fun phase3_siteScopedDuplicateLocalWorkerCodeValidation() {
        val workers = listOf(
            Worker("GLB-1", "রহিম", "Rahim", WorkCategory.MASON, 650, siteId = siteA.id, localWorkerCode = "SL-101"),
            Worker("GLB-2", "করিম", "Karim", WorkCategory.HELPER, 300, siteId = siteB.id, localWorkerCode = "SL-101")
        )
        // Same code at Site A is blocked
        assertTrue(WageCalculator.isLocalWorkerCodeDuplicate(siteA.id, "sl-101", null, workers))
        // Editing self is allowed
        assertFalse(WageCalculator.isLocalWorkerCodeDuplicate(siteA.id, "SL-101", "GLB-1", workers))
        // Unique code in Site B is allowed even if Site A already uses SL-101
        assertFalse(WageCalculator.isLocalWorkerCodeDuplicate(siteB.id, "SL-102", null, workers))
    }

    @Test
    fun phase3_workerTransferPreservesPriorSiteEarningsAndBalancesWithoutDoubleCounting() = runBlocking {
        val repo = InMemorySampleSiteLedgerRepository()
        val worker = repo.workers.value.first { it.siteId == "SITE-MAIN" }
        val beforeMainEarned = WageCalculator.computeSiteFinancialSummary(
            site = repo.sites.value.first { it.id == "SITE-MAIN" },
            workers = repo.workers.value,
            attendance = repo.attendanceRecords.value,
            allocations = repo.paymentAllocations.value,
            expenses = repo.expenses.value,
            periodIsoFilter = "2026-11"
        ).totalEarnedPayroll

        // Transfer worker from SITE-MAIN to SITE-BANANI
        repo.transferWorker(worker.id, "SITE-BANANI", "BNN-99", "Needed for slab casting", UserRole.ADMIN)

        val transferred = repo.workers.value.first { it.id == worker.id }
        assertEquals("SITE-BANANI", transferred.siteId)
        assertEquals("BNN-99", transferred.localWorkerCode)
        assertTrue(repo.workerTransfers.value.any { it.workerId == worker.id && it.fromSiteId == "SITE-MAIN" && it.toSiteId == "SITE-BANANI" })

        // Prior earned payroll on SITE-MAIN remains intact!
        val afterMainEarned = WageCalculator.computeSiteFinancialSummary(
            site = repo.sites.value.first { it.id == "SITE-MAIN" },
            workers = repo.workers.value,
            attendance = repo.attendanceRecords.value,
            allocations = repo.paymentAllocations.value,
            expenses = repo.expenses.value,
            periodIsoFilter = "2026-11"
        ).totalEarnedPayroll
        assertEquals(beforeMainEarned, afterMainEarned)
    }

    @Test
    fun phase3_cleanSeparationOfEarnedPaidGeneralExpensesAndConsolidatedAllSitesParity() {
        val workers = listOf(
            Worker("W1", "A", "A", WorkCategory.MASON, 500, siteId = siteA.id, localWorkerCode = "A-01"),
            Worker("W2", "B", "B", WorkCategory.HELPER, 300, siteId = siteB.id, localWorkerCode = "B-01")
        )
        val attendance = listOf(
            DailyAttendanceRecord("2026-11-10", "W1", DutyType.DOUBLE_DUTY, 500, 2.0, 1000, siteId = siteA.id),
            DailyAttendanceRecord("2026-11-10", "W2", DutyType.FULL_DUTY, 300, 1.0, 300, siteId = siteB.id)
        )
        val allocations = listOf(
            PaymentAllocation("AL-1", "PAYMENT", "TX-1", "W1", "2026-11", 600, "2026-11-12", UserRole.ADMIN, siteId = siteA.id)
        )
        val expenses = listOf(
            SiteExpense("EXP-1", siteA.id, "2026-11-10", "CAT-CEMENT", "Cement", 4500, "Vendor X", ExpensePaymentMethod.CASH),
            SiteExpense("EXP-2", siteA.id, "2026-11-11", "CAT-STEEL", "Steel", 9000, "Vendor Y", ExpensePaymentMethod.BANK, isVoided = true),
            SiteExpense("EXP-3", siteB.id, "2026-11-12", "CAT-FUEL", "Fuel", 1200, "Pump", ExpensePaymentMethod.CASH)
        )

        val summaryA = WageCalculator.computeSiteFinancialSummary(siteA, workers, attendance, allocations, expenses, "2026-11")
        assertEquals(1000, summaryA.totalEarnedPayroll)
        assertEquals(600, summaryA.totalPaidPayroll)
        assertEquals(400, summaryA.totalOutstandingPayroll)
        // Voided EXP-2 must be excluded, payroll must NOT be double counted inside expenses
        assertEquals(4500, summaryA.totalGeneralExpenses)

        val consolidatedRows = WageCalculator.computeSpreadsheetRows(
            year = 2026,
            month = 11,
            selectedSiteId = siteA.id,
            allSitesMode = true,
            sites = listOf(siteA, siteB),
            workers = workers,
            allAttendance = attendance,
            allAllocations = allocations,
            periodRecords = emptyList()
        )
        val totals = WageCalculator.computeSpreadsheetTotals(consolidatedRows)
        val overview = WageCalculator.computeAllSitesOverview(listOf(siteA, siteB), workers, attendance, allocations, expenses, "2026-11")

        assertEquals(overview.combinedEarnedPayroll, totals.totalEarnedSalary)
        assertEquals(overview.combinedPaidPayroll, totals.totalPaidSalary)
        assertEquals(overview.combinedOutstandingPayroll, totals.totalOutstandingSalary)
        assertEquals(5700, overview.combinedGeneralExpenses)
    }

    @Test
    fun phase3_siteLevelRbacEnforcementAndMultiSite500Scale() = runBlocking {
        val repo = InMemorySampleSiteLedgerRepository()
        // Accountant has SITE-MAIN + SITE-BANANI by default; restrict ACCOUNTANT to SITE-MAIN only
        repo.updateUserSiteAssignments(UserRole.ACCOUNTANT, listOf("SITE-MAIN"), UserRole.ADMIN)
        assertFalse(repo.canRoleAccessSite(UserRole.ACCOUNTANT, "SITE-BANANI"))
        assertTrue(repo.canRoleAccessSite(UserRole.ADMIN, "SITE-BANANI"))

        // 500 workers split across 2 sites
        val workers = (1..500).map { i ->
            val sid = if (i <= 250) siteA.id else siteB.id
            Worker("W-$i", "W$i", "W$i", WorkCategory.HELPER, 300, siteId = sid, localWorkerCode = "SL-$i")
        }
        val attendance = workers.map { w ->
            DailyAttendanceRecord("2026-11-15", w.id, DutyType.FULL_DUTY, 300, 1.0, 300, siteId = w.siteId)
        }
        val rows = WageCalculator.computeSpreadsheetRows(2026, 11, siteA.id, allSitesMode = true, listOf(siteA, siteB), workers, attendance, emptyList(), emptyList())
        val totals = WageCalculator.computeSpreadsheetTotals(rows)
        assertEquals(500, totals.totalWorkers)
        assertEquals(150000, totals.totalEarnedSalary)
    }

    @Test
    fun phase2_sha256AndSuggestedBackupFileNamingContract() {
        val name = OfflineBackupManager.suggestedBackupFileName()
        assertTrue(name.startsWith("SITE_LEDGER_BACKUP_"))
        assertTrue(name.endsWith(".zip"))
        val digest = OfflineBackupManager.sha256Hex("site-ledger-offline".toByteArray())
        assertEquals(64, digest.length)
        assertNotNull(digest)
    }
}
