# SITE LEDGER — Native Android App (Kotlin + Jetpack Compose + Material 3)

**Subtitle:** Construction Workforce & Expense Management  
**SQLite Schema Version:** `4` (Non-destructive migrations `v1 -> v2 -> v3 -> v4`)

## Core Architecture
- `domain/model/Models.kt`: Domain models for Workers (including permanent `photoPath`), Daily Attendance Snapshots, Advances, Payment Allocations, Payroll Periods (`OPEN` / `FINALIZED`), and Payroll/Payment Audit Logs.
- `domain/service/WageCalculator.kt`: Integer-safe hundredths wage & duty unit engine, current month projection vs finalized earnings, and Master Payroll Spreadsheet totals verification.
- `data/local/SiteLedgerDatabaseContract.kt` & `SiteLedgerSqliteOpenHelper.kt`: Offline SQLite persistence preserving all existing worker records, photos, and financial history across upgrades.
- `data/export/PayrollExporter.kt`: 100% offline Excel (`.xls` SpreadsheetML), native Android `PdfDocument` (`.pdf`), and `PrintManager` HTML attendance reports.
- `ui/screens/`:
  - `DashboardScreen.kt`
  - `WorkersScreen.kt` & `WorkerProfileScreen.kt` (5 tabs: Overview, Attendance Calendar, Payroll History, Payment History & Advances, Personal Info)
  - `AttendanceScreen.kt` (enforces Finalized Period lock)
  - `PayrollSpreadsheetScreen.kt` (13-column spreadsheet with frozen Worker ID & Name columns, search/filter/sort, Totals row, Admin lock/reopen, offline Excel/PDF/Print exports)
  - `PaymentsScreen.kt` (separate payment date vs salary month period, Advances, and explicit Advance Allocation)
  - `ReportsScreen.kt` (monthly, yearly, and worker-wise comparison + offline exports)
  - `SettingsScreen.kt` (Bengali/English toggle, role switch, configurable duty multipliers)
