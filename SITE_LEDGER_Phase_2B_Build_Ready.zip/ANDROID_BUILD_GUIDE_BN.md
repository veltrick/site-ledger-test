# SITE LEDGER — Android Build Guide (Phase 2B)

## এই ধাপের লক্ষ্য

Android source project-কে repeatable build, unit-test এবং lint verification-এর জন্য প্রস্তুত করা। এই পর্যায়ে নতুন product feature বা database schema পরিবর্তন করা হয়নি।

## Android project কোথায়?

এই ZIP-এর মধ্যে Android Gradle project হলো `android-project/`। Root folder-এর React/Vite app আলাদা; সেটি Android APK build-এর input নয়।

## নির্ধারিত build toolchain

| Component | Pinned version |
|---|---:|
| JDK | 17 |
| Android Gradle Plugin | 8.7.2 |
| Gradle | 8.9 |
| Kotlin | 2.0.21 |
| Android compile SDK | 35 |
| Android build tools | 35.0.0 |
| Minimum Android SDK | 24 |

Gradle 8.9 is selected to match Android Gradle Plugin 8.7.2. Do not upgrade one independently without checking the official compatibility matrix.

## Automated build

Repository-টি GitHub-এ push করার পর `.github/workflows/android-build.yml` স্বয়ংক্রিয়ভাবে:
1. JDK 17 ও Android SDK প্রস্তুত করবে।
2. Gradle 8.9 ব্যবহার করবে।
3. `:app:assembleDebug` চালাবে।
4. `:app:testDebugUnitTest` চালাবে।
5. `:app:lintDebug` চালাবে।
6. সব ধাপ সফল হলে `app-debug.apk` artifact হিসেবে সংরক্ষণ করবে।

GitHub Actions-এ workflow run-এর Artifacts অংশ থেকে APK পাওয়া যাবে।

## Local build (যে কম্পিউটারে Android toolchain আছে)

প্রয়োজন: JDK 17, Android SDK Platform 35, Build Tools 35.0.0 এবং Gradle 8.9।

টার্মিনালে:

```bash
cd android-project
gradle --version
gradle --no-daemon :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
```

APK output:

```text
android-project/app/build/outputs/apk/debug/app-debug.apk
```

এই source archive-এ এখনো official Gradle Wrapper JAR/scripts নেই। তাই `gradle` command চালানোর মতো Gradle 8.9 installation ছাড়া এই নির্দিষ্ট local command চলবে না। কোনো নকল বা যাচাইবিহীন Wrapper binary যোগ করা হয়নি। CI workflow-তে Gradle 8.9 নির্দিষ্টভাবে provision করা হয়।

## গুরুত্বপূর্ণ নিরাপত্তা নির্দেশনা

- Debug APK-কে production release হিসেবে বিতরণ করা যাবে না।
- Release APK-এর জন্য আলাদা signing configuration ও key-management plan লাগবে; signing key কখনো source ZIP বা public repository-তে রাখা যাবে না।
- বিদ্যমান ইনস্টল করা অ্যাপের উপর test install করার আগে সম্পূর্ণ Backup তৈরি করতে হবে।
- একই `applicationId`-এর APK signature আলাদা হলে Android update install প্রত্যাখ্যান করতে পারে। সে ক্ষেত্রে পুরোনো app uninstall করবে না—আগে backup ও signing strategy যাচাই করতে হবে।
- Build-এর প্রথমবার dependency download-এর জন্য internet লাগতে পারে; ইনস্টল করা SITE LEDGER-এর মূল কাজ offline-first থাকবে।
- Android build, unit test, lint বা real-device test সফল হয়েছে—এমন দাবি কেবল সংশ্লিষ্ট CI/device run-এর প্রমাণ পাওয়ার পর করা যাবে।

## বর্তমান যাচাইয়ের সীমা

এই কাজের পরিবেশে JDK 21 পাওয়া গেছে, কিন্তু Android SDK এবং Gradle 8.9 executable পাওয়া যায়নি। তাই এখানে APK build বা Android Gradle test চালানো সম্ভব হয়নি। XML ও version-catalog TOML syntax staticভাবে যাচাই করা হয়েছে। প্রকৃত build ফলাফল CI run থেকে নিতে হবে।
