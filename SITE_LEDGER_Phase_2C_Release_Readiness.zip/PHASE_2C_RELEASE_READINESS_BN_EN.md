# SITE LEDGER — Phase 2C Release Readiness & Critical Fix Plan

## What this package changes
- Corrects the Android project README's schema-version reference to **v6**, matching `SiteLedgerDatabaseContract.DATABASE_VERSION`.
- Adds this release-readiness report.
- Does not delete or reset any existing database, worker, attendance, payroll, expense, photo, or backup data.
- Does not claim the APK or Android tests have passed.

## Critical blockers found in the supplied Phase 2B source

### 1. Role access is not production-secure
- Both repository implementations contain a default-allow path when a role has no site assignment.
- The Settings screen allows changing the active role directly.
- The ViewModel starts with `ADMIN`.
- There is no verified local sign-in/PIN identity that binds a person to a role.
**Consequence:** site scoping and role permissions are not a security boundary. Do not use this build for real payroll or sensitive workforce records until authentication and authorization are implemented.

### 2. Duplicate payment/advance submission protection is not persistent
- Submission tokens are tracked in an in-memory set.
- The token is not persisted with the payment/advance transaction in SQLite.
**Consequence:** after process restart, the same submission can be accepted again. A production fix requires a persistent unique idempotency key and inserting that key plus the financial record in the same SQLite transaction.

### 3. Backup tests do not prove real Android SQLite restore safety
- The backup hardening unit tests use a fake SQLite bridge.
- They do not establish that Android SQLite, filesystem rename/recovery, WAL handling, and process-death recovery work together on a device.
**Consequence:** add Android instrumentation tests using real SQLite databases and temporary app-private directories before relying on restore for business-critical data.

### 4. Build verification remains incomplete
- The supplied archive does not include Gradle Wrapper scripts/JAR.
- This environment has no Gradle executable or Android SDK.
- The Kotlin domain model and wage calculator compile independently, but this is not an Android APK build.
- JUnit/instrumentation tests, lint, APK installation, and device testing were not run.

### 5. Wi-Fi/Hotspot sync is not implemented
The current sync-related table/readiness code is not a working local network synchronization implementation.

## Required order before production use
1. Implement local authenticated accounts (PIN/password hash), with the active role derived from the authenticated account; remove role impersonation from ordinary Settings.
2. Change missing site assignment to deny access, not allow access.
3. Add a persistent `idempotency_keys` table (unique token + operation type + result reference); write key and payment/advance atomically.
4. Add real SQLite instrumentation tests for fresh install, v3→v4→v5→v6 migrations, backup validation, restore, rollback, and process interruption.
5. Add Gradle Wrapper and run CI with JDK 17, Android SDK, unit tests, lint, and APK assembly.
6. Implement and test local Wi-Fi/Hotspot sync separately; do not label the readiness table as sync.

## Verification performed on the supplied Phase 2B archive
- ZIP integrity: passed.
- XML parsing: passed.
- Gradle version catalog TOML parsing: passed.
- Standalone Kotlin compilation of `Models.kt` and `WageCalculator.kt`: passed.
- Android Gradle build / APK: not run.
- JUnit tests: not run.
- Android device/instrumentation tests: not run.

**Release decision: NOT READY FOR PRODUCTION.** This is an honest readiness package, not a claim that the critical security and financial-integrity defects have been fixed.
